#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { rgb }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing Statistical Region Merging segmentation...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's an rgb image */
 if ( !is_rgb_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be rgb !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Start the timer */
 start_time = start_timer (  );

 /* Segment the input image using Statistical Region Merging */
 out_img = srm ( in_img, 32.0, 0.001 );

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "SRM segmentation time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_srm.ppm", FMT_PPM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
