#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { color }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing Efficient Graph-Based Segmentation...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a color image */
 if ( !is_rgb_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be rgb !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 start_time = start_timer (  );

 /* Segment the input image using Efficient Graph-Based Segmentation algorithm */
 out_img = graph_segment ( in_img, 2., 300, 300, false );

 elapsed_time = stop_timer ( start_time );

 printf ( "Efficient Graph-Based Segmentation time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_graph_segment.bmp", FMT_BMP );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
