#include <image.h>

int
main ( int argc, char **argv )
{
 char out_file[17];
 char method_name[9][9] = { "huang", "iter", "kapur",
  "li", "moment", "otsu",
  "renyi", "shanbhag", "yen"
 };
 int i;
 int threshold;
 int ( *function[9] ) ( const Image * ) =
 {
 &threshold_huang, &threshold_iter, &threshold_kapur,
   &threshold_li, &threshold_moment, &threshold_otsu,
   &threshold_renyi, &threshold_shanbhag, &threshold_yen};
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { grayscale }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing various global thresholding algorithms...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a grayscale image */
 if ( !is_gray_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Print the header */
 printf ( "Method  \tThreshold\tTime\n" );
 printf ( "--------\t---------\t--------\n" );

 /* Perform thresholding using 9 different methods */
 for ( i = 0; i < 9; i++ )
  {
   /* Start the timer */
   start_time = start_timer (  );

   /* Determine the threshold value using method #i */
   threshold = function[i] ( in_img );

   /* Calculate the elapsed time */
   elapsed_time = stop_timer ( start_time );

   /* Determine the output file name */
   sprintf ( out_file, "out_%s.pbm", method_name[i] );

   /* Threshold the image */
   out_img = threshold_img ( in_img, threshold );

   /* Write the output image */
   write_img ( out_img, out_file, FMT_PBM );

   /* Deallocate the output image */
   free_img ( out_img );

   /* Display the threshold value and elapsed time */
   printf ( "%8s\t%d\t\t%f\n", method_name[i], threshold, elapsed_time );
  }

 /* Deallocate the input image */
 free_img ( in_img );

 return EXIT_SUCCESS;
}
