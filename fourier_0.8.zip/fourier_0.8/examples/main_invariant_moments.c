#include <image.h>

#define MAX_CHAIN_LEN 10000
#define MIN_CC_SIZE   500

int
main ( int argc, char **argv )
{
 int i;
 int num_cc;
 double elapsed_time;
 clock_t start_time;
 HuMoments *hm;
 AffineMoments *am;
 Image *in_img;
 Image *lab_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing invariant moments...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 /* Get the number of components */
 num_cc = get_num_cc ( lab_img );

 /* Remove the components smaller than MIN_CC_SIZE */
 if ( num_cc > 1 )
  {
   lab_img = remove_small_cc ( lab_img, MIN_CC_SIZE );
   num_cc = get_num_cc ( lab_img );
  }

 start_time = start_timer (  );
 for ( i = 1; i <= num_cc; i++ )
  {
   printf ( "Features for Object #%d\n", i );
   printf ( "----------------------\n" );

   hm = calc_hu_moments ( lab_img, i );

   am = calc_affine_moments ( lab_img, i );

   printf
    ( "Hu's RST invariant moments: phi1 = %g, phi2 = %g, phi3 = %g, phi4 = %g, phi5 = %g, phi6 = %g, phi7 = %g\n\n",
      hm->phi1, hm->phi2, hm->phi3, hm->phi4, hm->phi5, hm->phi6, hm->phi7 );

   printf
    ( "Flusser's affine invariant moments: I1 = %g, I2 = %g, I3 = %g, I4 = %g\n",
      am->I1, am->I2, am->I3, am->I4 );

   printf ( "\n" );
  }
 elapsed_time = stop_timer ( start_time );

 printf ( "Feature extraction time = %f\n", elapsed_time );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );

 return EXIT_SUCCESS;
}
