#include <image.h>

int
main ( int argc, char **argv )
{
 Image *in_img;
 Image *lab_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing region filling...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 fill_region ( 300, 500, 3, lab_img );

 /* Convert the label image to binary */
 out_img = label_to_bin ( lab_img );

 /* Write the binary image to a file */
 write_img ( out_img, "out_fill.pbm", FMT_PBM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
