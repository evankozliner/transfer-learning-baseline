#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing Rotation and Scaling...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 start_time = start_timer (  );

 /* Rotate the input image by 30.0 (counterclockwise) */
 out_img = rotate_img ( in_img, 30.0 );

 elapsed_time = stop_timer ( start_time );

 printf ( "Rotation time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_rotation.bmp", FMT_BMP );

 start_time = start_timer (  );

 /* Scale the input image by 50% */
 out_img =
  scale_img ( in_img, get_num_rows ( in_img ) / 2,
	      get_num_cols ( in_img ) / 2 );

 elapsed_time = stop_timer ( start_time );

 printf ( "Scaling time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_scaling.bmp", FMT_BMP );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
