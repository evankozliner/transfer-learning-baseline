#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *noisy_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { rgb }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing Peer Group Filter...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's an rgb image */
 if ( !is_rgb_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be rgb !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Inject 10% uncorrelated impulsive noise to the input image */
 noisy_img = add_uncorr_impulsive_noise ( in_img, 0.1, false );

 /* Write the noisy image to a file */
 write_img ( noisy_img, "out_pgf_noisy.ppm", FMT_PPM );

 /* Start the timer */
 start_time = start_timer (  );

 /* Filter the noisy image using PGF */
 /* Window size = 3, Distance threshold = 30 */
 out_img = filter_pgf ( noisy_img, 3, 30.0 );

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "PGF time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_pgf_filtered.ppm", FMT_PPM );

 /* Print the header */
 printf ( "\nMeasure\tInitial Val\tFinal Val\n" );
 printf ( "-------\t-----------\t----------\n" );

 /* Calculate and print various error measures */
 printf ( "MAE\t%f\t", calc_error ( EM_MAE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_MAE, in_img, out_img ) );

 printf ( "MSE\t%f\t", calc_error ( EM_MSE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_MSE, in_img, out_img ) );

 printf ( "RMSE\t%f\t", calc_error ( EM_RMSE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_RMSE, in_img, out_img ) );

 printf ( "PSNR\t%f\t", calc_error ( EM_PSNR, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_PSNR, in_img, out_img ) );

 printf ( "NMSE\t%f\t", calc_error ( EM_NMSE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_NMSE, in_img, out_img ) );

 printf ( "NCD\t%f\t", calc_error ( EM_NCD, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_NCD, in_img, out_img ) );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( noisy_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
