#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *noisy_img;
 Image *out_img;

 if ( argc != 4 )
  {
   fprintf ( stderr,
	     "Usage: %s <input image { grayscale }> <brightness threshold { (0, 255] }> <distance threshold>\n",
	     argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing SUSAN filtering...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a grayscale image */
 if ( !is_gray_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Add Gaussian noise with 0 mean and .1 stdev */
 noisy_img = add_gaussian_noise ( in_img, .0, .1 );

 /* Write the noisy image to a file */
 write_img ( noisy_img, "out_susan_noisy.pgm", FMT_PGM );

 /* Start the timer */
 start_time = start_timer (  );

 /* Perform SUSAN filtering */
 out_img = filter_susan ( noisy_img, atoi ( argv[2] ), atof ( argv[3] ) );

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "Susan filtering time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_susan_filtered.pgm", FMT_PGM );

 /* Print the header */
 printf ( "\nMeasure\tInitial Val\tFinal Val\n" );
 printf ( "-------\t-----------\t----------\n" );

 /* Calculate and print various error measures */
 printf ( "MAE\t%f\t", calc_error ( EM_MAE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_MAE, in_img, out_img ) );

 printf ( "MSE\t%f\t", calc_error ( EM_MSE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_MSE, in_img, out_img ) );

 printf ( "RMSE\t%f\t", calc_error ( EM_RMSE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_RMSE, in_img, out_img ) );

 printf ( "PSNR\t%f\t", calc_error ( EM_PSNR, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_PSNR, in_img, out_img ) );

 printf ( "NMSE\t%f\t", calc_error ( EM_NMSE, in_img, noisy_img ) );
 printf ( "%f\n", calc_error ( EM_NMSE, in_img, out_img ) );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( noisy_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
