#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *hsl_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { rgb }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's an rgb image */
 if ( !is_rgb_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be rgb !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing RGB <-> HSL color space conversion...\n" );

 /* Start the timer */
 start_time = start_timer (  );

 /* Convert the input RGB image to HSL space */
 hsl_img = rgb_to_hsl ( in_img, 0.0 );

 /* Convert the HSL image back to RGB space */
 out_img = hsl_to_rgb ( hsl_img );

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "RGB -> HSL -> RGB time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_rgb.ppm", FMT_PPM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( hsl_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
