#include <image.h>

#define MAX_CHAIN_LEN 10000
#define MIN_CC_SIZE   500

int
main ( int argc, char **argv )
{
 int i;
 int num_cc;
 double elapsed_time;
 clock_t start_time;
 Point *centroid;
 PointList *cont;
 PointList *hull;
 EllipseFeatures *ellipse;
 RadialDistFeatures *rdm;
 ChordLenStats *chord;
 Image *in_img;
 Image *lab_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing basic shape descriptors...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 /* Get the number of components */
 num_cc = get_num_cc ( lab_img );

 /* Remove the components smaller than MIN_CC_SIZE */
 if ( num_cc > 1 )
  {
   lab_img = remove_small_cc ( lab_img, MIN_CC_SIZE );
   num_cc = get_num_cc ( lab_img );
  }

 start_time = start_timer (  );
 for ( i = 1; i <= num_cc; i++ )
  {
   printf ( "Features for Object #%d\n", i );
   printf ( "----------------------\n" );
   printf ( "Pixel count = %d\n", count_obj_pixels ( lab_img, i ) );

   printf ( "Area = %f\n", calc_obj_area ( lab_img, i ) );

   printf ( "Aspect ratio = %f\n", calc_aspect_ratio ( lab_img, i ) );

   centroid = calc_obj_centroid ( lab_img, i );
   printf ( "Centroid = (%f, %f)\n", centroid->row, centroid->col );

   printf ( "Triangularity = %f\n", calc_triangularity ( lab_img, i ) );

   printf ( "Ellipticity = %f\n", calc_ellipticity ( lab_img, i ) );

   ellipse = calc_ellipse_feats ( lab_img, i );
   printf ( "Ellipse major axis length = %f\n", ellipse->maj_axis_len );
   printf ( "Ellipse minor axis length = %f\n", ellipse->min_axis_len );
   printf ( "Ellipse aspect ratio = %f\n", ellipse->aspect_ratio );
   printf ( "Ellipse eccentricity = %f\n", ellipse->eccentricity );
   printf ( "Ellipse orientation = %f\n", ellipse->orientation );

   printf ( "Equivalent diameter = %f\n", calc_equi_diameter ( lab_img, i ) );

   /* Get the object contour */
   cont = chain_to_point_list ( trace_contour ( lab_img, i, MAX_CHAIN_LEN ) );

   /* Calculate its convex hull */
   hull = calc_2d_convex_hull ( cont );

   printf ( "Maximum Diameter = %f\n", calc_max_diameter ( hull ) );

   printf ( "Solidity = %f\n", calc_solidity ( lab_img, i, hull ) );

   printf ( "Compactness = %f\n", calc_compactness ( lab_img, i, hull ) );

   printf ( "Elliptic variance = %f\n",
	    calc_elliptic_var ( lab_img, i, cont ) );

   printf ( "Circularity = %f\n", calc_circularity ( lab_img, i, cont ) );

   printf ( "Rectangularity = %f\n", calc_rectangularity ( lab_img, i, cont ) );

   rdm = calc_radial_dist_feats ( lab_img, i, cont );
   printf
    ( "Radial distance features: mean = %f, stdev = %f, entropy = %f, roughness = %f\n",
      rdm->mean, rdm->stdev, rdm->entropy, rdm->roughness );

   chord = calc_chord_len_stats ( cont );
   printf
    ( "Chord length statistics: mean = %f, variance = %f, skewness = %f, kurtosis = %f\n",
      chord->mean, chord->variance, chord->skewness, chord->kurtosis );

   printf ( "\n" );
  }
 elapsed_time = stop_timer ( start_time );

 printf ( "Feature extraction time = %f\n", elapsed_time );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );

 return EXIT_SUCCESS;
}
