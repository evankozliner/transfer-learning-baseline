
/** 
 * @file filter_snn.c
 * Routines for Symmetric Nearest Neighbor filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Symmetric Nearest Neighbor filter
 *
 * @param[in] in_img Image pointer { grayscale }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref 1) Harwood et al. (1987) "A New Class of Edge Preserving Smoothing Filters"
 *         Pattern Recognition Letters, 6(3):155-162
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_snn ( const Image * in_img )
{
 SET_FUNC_NAME ( "filter_snn" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int ir, ic;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int center_val;
 int out_val;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = 1;
 r_end = num_rows - 1;
 c_begin = 1;
 c_end = num_cols - 1;

 /* Note: Caching the values of ir +- 1 and ic +- 1 makes the filter slower ! */

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     out_val = 0;
     center_val = in_data[ir][ic];

     /* Choose between P1 & Q1 */
     if ( abs ( center_val - in_data[ir][ic - 1] ) <
	  abs ( center_val - in_data[ir][ic + 1] ) )
      {
       out_val += in_data[ir][ic - 1];
      }
     else
      {
       out_val += in_data[ir][ic + 1];
      }

     /* Choose between P2 & Q2 */
     if ( abs ( center_val - in_data[ir - 1][ic - 1] ) <
	  abs ( center_val - in_data[ir + 1][ic + 1] ) )
      {
       out_val += in_data[ir - 1][ic - 1];
      }
     else
      {
       out_val += in_data[ir + 1][ic + 1];
      }

     /* Choose between P3 & Q3 */
     if ( abs ( center_val - in_data[ir - 1][ic] ) <
	  abs ( center_val - in_data[ir + 1][ic] ) )
      {
       out_val += in_data[ir - 1][ic];
      }
     else
      {
       out_val += in_data[ir + 1][ic];
      }

     /* Choose between P4 & Q4 */
     if ( abs ( center_val - in_data[ir - 1][ic + 1] ) <
	  abs ( center_val - in_data[ir + 1][ic - 1] ) )
      {
       out_val += in_data[ir - 1][ic + 1];
      }
     else
      {
       out_val += in_data[ir + 1][ic - 1];
      }

     out_data[ir][ic] = out_val / 4;
    }
  }

 return out_img;
}
