
/** 
 * @file expand_histo.c
 * Routines for Histogram Expansion of a grayscale image
 */

#include <image.h>

/** 
 * @brief Expands the histogram of a grayscale image
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] percent_clip Percentage of pixels clipped at the low 
 *                         and high end of the histogram { [0,50] }
 *
 * @return Pointer to the histogram expanded image or NULL
 * @ref Umbaugh S.E. (2005) "Computer Imaging: Digital Image 
 *      Analysis and Processing" CRC Press
 *
 * @author M. Emre Celebi
 * @date 02.09.2008
 */

Image *
expand_histo ( const Image * in_img, const double percent_clip )
{
 SET_FUNC_NAME ( "expand_histo" );
 byte *in_data;
 byte *out_data;
 int ih, ik;
 int num_pixels;
 int threshold;
 int sum;
 int lower_limit, upper_limit;
 int *histo_data;
 Histo *histo;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( percent_clip < 0.0 || 50.0 < percent_clip )
  {
   ERROR ( "Clipping percentage ( %f ) must be in [0.0,50.0] !", percent_clip );
   return NULL;
  }

 histo = create_histo ( in_img );
 histo_data = get_histo_data ( histo );
 num_pixels = get_num_pixels ( histo );
 threshold = num_pixels * percent_clip / 100.0 + 0.5;	/* round */

 /* Determine the lower and upper limits based on the clipping amount */
 sum = 0;
 lower_limit = 0;
 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   sum += histo_data[ih];
   if ( threshold <= sum )
    {
     lower_limit = ih;
     break;
    }
  }

 sum = 0;
 upper_limit = MAX_GRAY;
 for ( ih = MAX_GRAY; ih >= 0; ih-- )
  {
   sum += histo_data[ih];
   if ( threshold <= sum )
    {
     upper_limit = ih;
     break;
    }
  }

 /* Allocate the output image */
 out_img =
  alloc_img ( PIX_GRAY, get_num_rows ( in_img ), get_num_cols ( in_img ) );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 in_data = get_img_data_1d ( in_img );
 out_data = get_img_data_1d ( out_img );

 if ( lower_limit != upper_limit )
  {
   byte *lut;
   double factor;

   factor = MAX_GRAY / ( double ) ( upper_limit - lower_limit );

   /* Allocate the lookup-table */
   lut = ( byte * ) malloc ( NUM_GRAY * sizeof ( byte ) );

   /* LUT entries between [0 .. LOWER_LIMIT] are set to 0 */
   memset ( lut, 0, ( lower_limit + 1 ) * sizeof ( byte ) );

   /* LUT entries between [UPPER_LIMIT .. MAX_GRAY] are set to MAX_GRAY */
   memset ( lut + upper_limit, MAX_GRAY,
	    ( MAX_GRAY - upper_limit + 1 ) * sizeof ( byte ) );

   /* LUT entries between (LOWER_LIMIT .. UPPER_LIMIT) are transformed */
   for ( ih = lower_limit + 1; ih < upper_limit; ih++ )
    {
     lut[ih] = factor * ( ih - lower_limit ) + 0.5;	/* round */
    }

   /* Apply the LUT to the input image */
   for ( ik = 0; ik < num_pixels; ik++ )
    {
     out_data[ik] = lut[in_data[ik]];
    }

   free ( lut );
  }
 else				/* Pathological Case: lower_limit == upper_limit */
  {
   /* Threshold the input image at LOWER_LIMIT */
   for ( ik = 0; ik < num_pixels; ik++ )
    {
     out_data[ik] = in_data[ik] <= lower_limit ? 0 : MAX_GRAY;
    }
  }

 free_histo ( histo );

 return out_img;
}
