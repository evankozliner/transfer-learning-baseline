
/** 
 * @file bin_morpho.c
 * Routines for various binary morphological operations
 */

#include <image.h>

typedef struct
{
 int top;
 int bottom;
 int left;
 int right;
} Limits;

static void
calc_limits ( const int se_num_rows, const int se_num_cols,
	      const int se_origin_row, const int se_origin_col,
	      Limits * limits )
{
 limits->top = se_origin_row;
 limits->bottom = se_num_rows - ( se_origin_row + 1 );
 limits->left = se_origin_col;
 limits->right = se_num_cols - ( se_origin_col + 1 );
}

static Bool
check_border ( byte ** in_data, const int num_rows, const int num_cols,
	       const int se_num_rows, const int se_num_cols,
	       const int se_origin_row, const int se_origin_col )
{
 int ir, ic;
 Limits limits;

 calc_limits ( se_num_rows, se_num_cols, se_origin_row, se_origin_col,
	       &limits );

 /* Check the top TOP rows */
 for ( ir = 0; ir < limits.top; ir++ )
  {
   for ( ic = 0; ic < num_cols; ic++ )
    {
     if ( in_data[ir][ic] == OBJECT )
      {
       return true;
      }
    }
  }

 /* Check the bottom BOTTOM rows */
 for ( ir = num_rows - limits.bottom; ir < num_rows; ir++ )
  {
   for ( ic = 0; ic < num_cols; ic++ )
    {
     if ( in_data[ir][ic] == OBJECT )
      {
       return true;
      }
    }
  }

 for ( ir = 0; ir < num_rows; ir++ )
  {
   /* Check the first LEFT columns */
   for ( ic = 0; ic < limits.left; ic++ )
    {
     if ( in_data[ir][ic] == OBJECT )
      {
       return true;
      }
    }

   /* Check the last RIGHT columns */
   for ( ic = num_cols - limits.right; ic < num_cols; ic++ )
    {
     if ( in_data[ir][ic] == OBJECT )
      {
       return true;
      }
    }
  }

 return false;
}

static void
pad_border ( byte ** in_data_2d, const int num_rows, const int num_cols,
	     const Limits * limits, const byte value, byte ** out_data_2d )
{
 byte *in_data_1d;
 byte *out_data_1d;
 int ir;
 int new_num_cols;

 new_num_cols = limits->left + num_cols + limits->right;

 in_data_1d = *in_data_2d;
 out_data_1d = *out_data_2d;

 if ( value == 0 )
  {
   /* 
      No need to pad the top TOP rows (they are already 0).
      Just advance the output data pointer. 
    */
   out_data_1d += limits->top * new_num_cols;

   for ( ir = 0; ir < num_rows; ir++ )
    {
     /* 
        Skip over the first LEFT columns (they are already 0).
        Copy the current input row to the output.
      */
     memcpy ( out_data_1d + limits->left, in_data_1d, num_cols );

     /* Advance the output data pointer */
     out_data_1d += new_num_cols;

     /* Advance the input data pointer */
     in_data_1d += num_cols;
    }

   /* No need to pad the bottom BOTTOM rows. They are already 0. */
  }
 else
  {
   /* Pad the top TOP rows with VALUE */
   memset ( out_data_1d, value, limits->top * new_num_cols );

   /* Advance the output data pointer */
   out_data_1d += limits->top * new_num_cols;

   for ( ir = 0; ir < num_rows; ir++ )
    {
     /* Pad the first LEFT columns in the current row with VALUE */
     memset ( out_data_1d, value, limits->left );

     /* Advance the output data pointer */
     out_data_1d += limits->left;

     /* Copy the current input row to the output */
     memcpy ( out_data_1d, in_data_1d, num_cols );

     /* Advance the output data pointer */
     out_data_1d += num_cols;

     /* Pad the last RIGHT columns in the current row with VALUE */
     memset ( out_data_1d, value, limits->right );

     /* Advance the output data pointer */
     out_data_1d += limits->right;

     /* Advance the input data pointer */
     in_data_1d += num_cols;
    }

   /* Pad the bottom BOTTOM rows with VALUE */
   memset ( out_data_1d, value, limits->bottom * new_num_cols );
  }
}

static void
strip_border ( byte ** in_data_2d, const int num_rows, const int num_cols,
	       const Limits * limits, byte ** out_data_2d )
{
 byte *in_data_1d;
 byte *out_data_1d;
 int ir;
 int new_num_cols;

 new_num_cols = limits->left + num_cols + limits->right;

 in_data_1d = *in_data_2d;
 out_data_1d = *out_data_2d;

 /* Skip the top TOP rows */
 in_data_1d += limits->top * new_num_cols;

 for ( ir = 0; ir < num_rows; ir++ )
  {
   /* Skip the first LEFT columns in the current row */
   in_data_1d += limits->left;

   /* Copy the current input row to the output */
   memcpy ( out_data_1d, in_data_1d, num_cols );

   /* Advance the input data pointer */
   in_data_1d += ( num_cols + limits->right );

   /* Advance the output data pointer */
   out_data_1d += num_cols;
  }
}

#define INIT_BIN_MORPH( VALUE )\
 byte **tmp_data;\
 byte **pad_data;\
 int ir, ic;\
 int r_begin, r_end;\
 int c_begin, c_end;\
 int wr_begin, wr_end;\
 int wc_begin, wc_end;\
 int se_index;\
 Bool need_padding;\
 Limits limits;\
 \
 calc_limits ( se_num_rows, se_num_cols, se_origin_row, se_origin_col, &limits );\
 \
 /* Initialize input & output data */\
 pad_data = in_data;\
 tmp_data = out_data;\
 \
 /* Check whether the input image needs to be padded */\
 need_padding = check_border ( in_data, num_rows, num_cols, se_num_rows, se_num_cols, se_origin_row, se_origin_col );\
 if ( need_padding )\
  {\
   int new_num_rows = limits.top + num_rows + limits.bottom;\
   int new_num_cols = limits.left + num_cols + limits.right;\
   \
   /* Allocate memory for padded input image data */\
   pad_data = alloc_nd ( sizeof ( byte ), 2, new_num_rows, new_num_cols );\
   if ( IS_NULL ( pad_data ) ) { return; }\
   \
   /* Pad the borders with VALUE */\
   pad_border ( in_data, num_rows, num_cols, &limits, VALUE, pad_data );\
   \
   /* Allocate memory for padded output image data */\
   tmp_data = alloc_nd ( sizeof ( byte ), 2, new_num_rows, new_num_cols );\
   if ( IS_NULL ( tmp_data ) ) { return; }\
  }\
 \
 /* Determine the limits of filtering */\
 r_begin = limits.top;\
 c_begin = limits.left;\
 \
 if ( need_padding )\
  {\
   r_end = limits.top + num_rows;\
   c_end = limits.left + num_cols;\
  }\
 else\
  {\
   r_end = num_rows - limits.bottom;\
   c_end = num_cols - limits.right;\
  }\
 \
 wr_begin = -se_origin_row;\
 wr_end = se_num_rows + wr_begin;\
 wc_begin = -se_origin_col;\
 wc_end = se_num_cols + wc_begin;\

static void
dilate_bin_horizontal ( byte ** in_data, const int num_rows, const int num_cols,
			const byte * se_data, const int se_num_rows,
			const int se_num_cols, const int se_origin_row,
			const int se_origin_col, byte ** out_data )
{
 int iwc;

 INIT_BIN_MORPH ( 0 );

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Strel origin coincides with an OBJECT pixel */
     if ( pad_data[ir][ic] == OBJECT )
      {
       /* Traverse the Strel neighborhood */
       se_index = 0;
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* 
	    The output pixel is an OBJECT pixel if either 
	    the Strel pixel OR the Input pixel is an OBJECT pixel
	  */
	 if ( se_data[se_index] | pad_data[ir][ic + iwc] )
	  {
	   tmp_data[ir][ic + iwc] = OBJECT;
	  }
	 se_index++;
	}
      }
    }
  }

 if ( need_padding )
  {
   /* Strip the padding from the border */
   strip_border ( tmp_data, num_rows, num_cols, &limits, out_data );
  }
}

static void
dilate_bin_vertical ( byte ** in_data, const int num_rows, const int num_cols,
		      const byte * se_data, const int se_num_rows,
		      const int se_num_cols, const int se_origin_row,
		      const int se_origin_col, byte ** out_data )
{
 int iwr;

 INIT_BIN_MORPH ( 0 );

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Strel origin coincides with an OBJECT pixel */
     if ( pad_data[ir][ic] == OBJECT )
      {
       /* Traverse the Strel neighborhood */
       se_index = 0;
       for ( iwr = wr_begin; iwr < wr_end; iwr++ )
	{
	 /* 
	    The output pixel is an OBJECT pixel if either 
	    the Strel pixel OR the Input pixel is an OBJECT pixel
	  */
	 if ( se_data[se_index] | pad_data[ir + iwr][ic] )
	  {
	   tmp_data[ir + iwr][ic] = OBJECT;
	  }
	 se_index++;
	}
      }
    }
  }

 if ( need_padding )
  {
   /* Strip the padding from the border */
   strip_border ( tmp_data, num_rows, num_cols, &limits, out_data );
  }
}

static void
dilate_bin_2d ( byte ** in_data, const int num_rows, const int num_cols,
		const byte * se_data, const int se_num_rows,
		const int se_num_cols, const int se_origin_row,
		const int se_origin_col, byte ** out_data )
{
 int iwr, iwc;

 INIT_BIN_MORPH ( 0 );

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Strel origin coincides with an OBJECT pixel */
     if ( pad_data[ir][ic] == OBJECT )
      {
       /* Traverse the Strel neighborhood */
       se_index = 0;
       for ( iwr = wr_begin; iwr < wr_end; iwr++ )
	{
	 for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	  {
	   /* 
	      The output pixel is an OBJECT pixel if either 
	      the Strel pixel OR the Input pixel is an OBJECT pixel
	    */
	   if ( se_data[se_index] | pad_data[ir + iwr][ic + iwc] )
	    {
	     tmp_data[ir + iwr][ic + iwc] = OBJECT;
	    }

	   se_index++;
	  }
	}
      }
    }
  }

 if ( need_padding )
  {
   /* Strip the padding from the border */
   strip_border ( tmp_data, num_rows, num_cols, &limits, out_data );
  }
}

static void
erode_bin_horizontal ( byte ** in_data, const int num_rows, const int num_cols,
		       const byte * se_data, const int se_num_rows,
		       const int se_num_cols, const int se_origin_row,
		       const int se_origin_col, byte ** out_data )
{
 int iwc;
 Bool contains;

 INIT_BIN_MORPH ( 1 );

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Strel origin coincides with an OBJECT pixel */
     if ( pad_data[ir][ic] == OBJECT )
      {
       se_index = 0;
       contains = true;
       /* Traverse the Strel neighborhood */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* 
	    Determine whether the Strel fits into the
	    neighborhood of the current input pixel 
	  */
	 if ( se_data[se_index] & !pad_data[ir][ic + iwc] )
	  {
	   contains = false;
	   break;
	  }
	 se_index++;
	}

       if ( contains )
	{
	 tmp_data[ir][ic] = OBJECT;
	}
      }
    }
  }

 if ( need_padding )
  {
   /* Strip the padding from the border */
   strip_border ( tmp_data, num_rows, num_cols, &limits, out_data );
  }
}

static void
erode_bin_vertical ( byte ** in_data, const int num_rows, const int num_cols,
		     const byte * se_data, const int se_num_rows,
		     const int se_num_cols, const int se_origin_row,
		     const int se_origin_col, byte ** out_data )
{
 int iwr;
 Bool contains;

 INIT_BIN_MORPH ( 1 );

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Strel origin coincides with an OBJECT pixel */
     if ( pad_data[ir][ic] == OBJECT )
      {
       se_index = 0;
       contains = true;
       /* Traverse the Strel neighborhood */
       for ( iwr = wr_begin; iwr < wr_end; iwr++ )
	{
	 /* 
	    Determine whether the Strel fits into the
	    neighborhood of the current input pixel 
	  */
	 if ( se_data[se_index] & !pad_data[ir + iwr][ic] )
	  {
	   contains = false;
	   break;
	  }
	 se_index++;
	}

       if ( contains )
	{
	 tmp_data[ir][ic] = OBJECT;
	}
      }
    }
  }

 if ( need_padding )
  {
   /* Strip the padding from the border */
   strip_border ( tmp_data, num_rows, num_cols, &limits, out_data );
  }
}

static void
erode_bin_2d ( byte ** in_data, const int num_rows, const int num_cols,
	       const byte * se_data, const int se_num_rows,
	       const int se_num_cols, const int se_origin_row,
	       const int se_origin_col, byte ** out_data )
{
 int iwr, iwc;
 Bool contains;

 INIT_BIN_MORPH ( 1 );

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Strel origin coincides with an OBJECT pixel */
     if ( pad_data[ir][ic] == OBJECT )
      {
       se_index = 0;
       contains = true;
       /* Traverse the Strel neighborhood */
       for ( iwr = wr_begin; iwr < wr_end; iwr++ )
	{
	 for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	  {
	   /* 
	      Determine whether the Strel fits into the
	      neighborhood of the current input pixel 
	    */
	   if ( se_data[se_index] & !pad_data[ir + iwr][ic + iwc] )
	    {
	     contains = false;
	     break;
	    }
	   se_index++;
	  }
	}

       if ( contains )
	{
	 tmp_data[ir][ic] = OBJECT;
	}
      }
    }
  }

 if ( need_padding )
  {
   /* Strip the padding from the border */
   strip_border ( tmp_data, num_rows, num_cols, &limits, out_data );
  }
}

#define BIN_MORPH_OP( OP )\
 byte **in_data;\
 byte **out_data;\
 int num_rows, num_cols;\
 Image *out_img;\
 \
 if ( !is_bin_img ( in_img ) )\
  {\
   ERROR_RET ( "Not a binary image !", NULL );\
  }\
 \
 if ( ! ( IS_ODD ( se->num_rows ) && IS_ODD ( se->num_cols ) ) )\
  {\
   ERROR ( "Structuring Element dimensions ( %d, %d ) must be odd !", se->num_rows, se->num_cols );\
   return NULL;\
  }\
 \
 num_rows = get_num_rows ( in_img );\
 num_cols = get_num_cols ( in_img );\
 in_data = get_img_data_nd ( in_img );\
 \
 out_img = alloc_img ( PIX_BIN, num_rows, num_cols );\
 if ( IS_NULL ( out_img ) )\
  {\
   ERROR_RET ( "Insufficient memory !", NULL );\
  }\
 \
 out_data = get_img_data_nd ( out_img );\
 \
 if ( se->type == STRL_LINE )\
  {\
   if ( se->num_rows == 1 )\
    {\
     OP##_bin_horizontal ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
    }\
   else if ( se->num_cols == 1 )\
    {\
     OP##_bin_vertical ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
    }\
   else\
    {\
     OP##_bin_2d ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
    }\
  }\
 else if ( se->type == STRL_RECT )\
  {\
   if ( se_origin_at_center ( se ) )\
    {\
     if ( se->num_rows == 1 )\
      {\
       OP##_bin_horizontal ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
      }\
     else if ( se->num_cols == 1 )\
      {\
       OP##_bin_vertical ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
      }\
     else\
      {\
       byte **tmp_data = alloc_nd ( sizeof ( byte ), 2, num_rows, num_cols );\
       OP##_bin_horizontal ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, tmp_data );\
       OP##_bin_vertical ( tmp_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
       free_nd ( tmp_data, 2 );\
      }\
    }\
   else\
    {\
     OP##_bin_2d ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
    }\
  }\
 else if ( se->type == STRL_DISK || se->type == STRL_FLAT )\
  {\
   OP##_bin_2d ( in_data, num_rows, num_cols, se->data_1d, se->num_rows, se->num_cols, se->origin_row, se->origin_col, out_data );\
  }\
 else if ( se->type == STRL_NONFLAT )\
  {\
   ERROR_RET ( "Non-flat structuring elements are currently not supported !", NULL );\
  }\
 else\
  {\
   ERROR_RET ( "Invalid structuring element type !", NULL );\
  }\
 \
 return out_img;\

Image *
dilate_bin ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "dilate_bin" );
 BIN_MORPH_OP ( dilate );
}

Image *
erode_bin ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "erode_bin" );
 BIN_MORPH_OP ( erode );
}

#undef BIN_MORPH_OP

Image *
close_bin ( const Image * in_img, const Strel * se )
{
 return erode_bin ( dilate_bin ( in_img, se ), se );
}

Image *
open_bin ( const Image * in_img, const Strel * se )
{
 return dilate_bin ( erode_bin ( in_img, se ), se );
}
