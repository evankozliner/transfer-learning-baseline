
/** 
 * @file filter_mmf.c
 * Routines for MMF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the MMF (Marginal, aka Component-Wise, Median Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 *
 * @ref 1) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 05.01.2008
 */

Image *
filter_mmf ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_mmf" );
 Image *in_red, *in_green, *in_blue;
 Image *out_red, *out_green, *out_blue;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 /* Get the individual color bands */
 get_rgb_bands ( in_img, &in_red, &in_green, &in_blue );

 /* Filter each color band separately */
 out_red = filter_running_median ( in_red, win_size );
 out_green = filter_running_median ( in_green, win_size );
 out_blue = filter_running_median ( in_blue, win_size );

 /* Combine the filtered color bands */
 out_img = combine_rgb_bands ( out_red, out_green, out_blue );

 free ( in_red );
 free ( in_green );
 free ( in_blue );
 free ( out_red );
 free ( out_green );
 free ( out_blue );

 return out_img;
}
