
/** 
 * @file filter_susan.c
 * Routines for Susan filtering of a grayscale image
 */

#include <image.h>

static int find_median_9 ( int *p );
static double *calc_bright_weights ( const int thresh );
static double **calc_dist_weights ( const int win_size, const double thresh );

/** @cond INTERNAL_FUNCTION */

static int
find_median_9 ( int *p )
{
 int tmp_var;

 SORT_INT ( p[1], p[2] );
 SORT_INT ( p[4], p[5] );
 SORT_INT ( p[7], p[8] );
 SORT_INT ( p[0], p[1] );
 SORT_INT ( p[3], p[4] );
 SORT_INT ( p[6], p[7] );
 SORT_INT ( p[1], p[2] );
 SORT_INT ( p[4], p[5] );
 SORT_INT ( p[7], p[8] );
 SORT_INT ( p[0], p[3] );
 SORT_INT ( p[5], p[8] );
 SORT_INT ( p[4], p[7] );
 SORT_INT ( p[3], p[6] );
 SORT_INT ( p[1], p[4] );
 SORT_INT ( p[2], p[5] );
 SORT_INT ( p[4], p[7] );
 SORT_INT ( p[4], p[2] );
 SORT_INT ( p[6], p[4] );
 SORT_INT ( p[4], p[2] );

 return p[4];
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

 /* 
    Weights corresponding to the following brightness differences:
    -255, -254, ..., -1, 0, 1, ..., 254, 255 
  */
static double *
calc_bright_weights ( const int thresh )
{
 int ik;
 double term;
 double *bright_weight;

 bright_weight =
  ( double * ) malloc ( ( 2 * MAX_GRAY + 1 ) * sizeof ( double ) );
 /* 
    Shift the array pointer so that negative indices make sense.
    Note that the array is symmetric about 0.
  */
 bright_weight += MAX_GRAY;

 term = -1.0 / ( thresh * thresh );
 bright_weight[0] = 1.0;
 for ( ik = 1; ik < NUM_GRAY; ik++ )
  {
   bright_weight[-ik] = bright_weight[ik] = exp ( ik * ik * term );
  }

 return bright_weight;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

static double **
calc_dist_weights ( const int win_size, const double thresh )
{
 int iwr, iwc;
 int half_win;
 double term;
 double **dist_weight;

 dist_weight = alloc_nd ( sizeof ( double ), 2, win_size, win_size );

 half_win = win_size / 2;
 term = -1.0 / ( thresh * thresh );
 for ( iwr = -half_win; iwr <= half_win; iwr++ )
  {
   for ( iwc = -half_win; iwc <= half_win; iwc++ )
    {
     dist_weight[iwr + half_win][iwc + half_win] =
      exp ( ( iwr * iwr + iwc * iwc ) * term );
    }
  }

 return dist_weight;
}

/** @endcond INTERNAL_FUNCTION */

/** 
 * @brief Implements the Susan filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] bright_thresh Brightness threshold { (0, 255] }
 * @param[in] dist_thresh Distance threshold { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Smith S.M. and Brady J.M. (1997 ) "SUSAN - A New Approach to Low Level 
 *      Image Processing" Int. Journal of Computer Vision, 23(1): 45-78
 *      http://www.fmrib.ox.ac.uk/~steve/susan/susan/susan.html
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_susan ( const Image * in_img, const int bright_thresh,
	       const double dist_thresh )
{
 SET_FUNC_NAME ( "filter_susan" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_size;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of a window */
 int wc_begin, wc_end;		/* horizontal limits of a window */
 int center_val;
 int win_data[9];		/* stores the 8-neighborhood of a pixel */
 double c_weight;		/* combined weight = (distance weight) * (brightness weight) */
 double weight_sum;		/* sum of combined weights in a window */
 double conv_sum;		/* convolution sum in a window */
 double *bright_weight;		/* stores the brightness weights */
 double **dist_weight;		/* stores the distance weights */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( bright_thresh <= 0 || bright_thresh > MAX_GRAY )
  {
   ERROR ( "Brightness threshold ( %d ) must be in (0, %d] range !",
	   bright_thresh, MAX_GRAY );
   return NULL;
  }

 if ( !IS_POS ( dist_thresh ) )
  {
   ERROR ( "Distance threshold ( %f ) must be positive !", dist_thresh );
   return NULL;
  }

 half_win = 1 + ( int ) ( 1.5 * dist_thresh );
 win_size = 2 * half_win + 1;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* Calculate the brightness and distance weights */
 bright_weight = calc_bright_weights ( bright_thresh );
 dist_weight = calc_dist_weights ( win_size, dist_thresh );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     center_val = in_data[ir][ic];

     /* 
        Offset the contribution of the center pixel to the convolution.
        Note that the weight of the center pixel is 1.0 
      */
     conv_sum = -center_val;
     weight_sum = -1.0;

     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 c_weight = dist_weight[iwr - wr_begin][iwc - wc_begin] *
	  bright_weight[in_data[iwr][iwc] - center_val];
	 conv_sum += c_weight * in_data[iwr][iwc];
	 weight_sum += c_weight;
	}
      }

     if ( !IS_ZERO ( weight_sum ) )
      {
       out_data[ir][ic] = conv_sum / weight_sum;
      }
     else
      {
       /* 
          If the the USAN area is zero (as it can be for impulse noise, 
          due to quantization of the brightness comparison function) then 
          the median of the 8 closest neighbours is used to estimate the
          pixel�s correct value. 
        */
       win_data[0] = in_data[ir - 1][ic - 1];
       win_data[1] = in_data[ir - 1][ic];
       win_data[2] = in_data[ir - 1][ic + 1];
       win_data[3] = in_data[ir][ic - 1];
       win_data[4] = center_val;
       win_data[5] = in_data[ir][ic + 1];
       win_data[6] = in_data[ir + 1][ic - 1];
       win_data[7] = in_data[ir + 1][ic];
       win_data[8] = in_data[ir + 1][ic + 1];

       out_data[ir][ic] = find_median_9 ( win_data );
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 /* BUG */
 /* free ( bright_weight ); */
 /* free_nd ( dist_weight, 2 ); */

 return out_img;
}
