
/** 
 * @file draw_line.c
 * Routines for line drawing
 */

/*
 * Digital Line Drawing by Paul Heckbert
 * from "Graphics Gems", Academic Press, 1990
 * 
 * Does no clipping. Uses Bresenham's algorithm.
 */

#include <image.h>

/** 
 * @brief Draws a line given its end points
 *
 * @param[in] point1 End point 1
 * @param[in] point2 End point 2
 * @param[in] pix_value Pixel value for the line pixels
 * @param[in,out] img Image pointer { binary or label }
 *
 * @return none
 *
 * @ref Bresenham J. (1965) "Algorithm for Computer Control 
 *      of a Digital Plotter" IBM Systems Journal, 4(1): 25-30.
 *
 * @author Paul Heckbert
 * @date 11.18.2007
 */

/** @cond INTERNAL_MACRO */

#define DRAW_LINE( )\
if ( ax > ay ) /* x dominant */\
 {\
  d = ay - ( ax >> 1 );\
  for ( ; ; )\
   {\
    data[y][x] = pix_value;\
    if ( x == x2 ) { return; }\
    if ( d >= 0 ) { y += sy; d -= ax; }\
    x += sx;\
    d += ay;\
   }\
 }\
else /* y dominant */\
 {\
  d = ax - ( ay >> 1 );\
  for ( ; ; )\
   {\
    data[y][x] = pix_value;\
    if ( y == y2 ) { return; }\
    if ( d >= 0 ) { x += sx; d -= ay; }\
    y += sy;\
    d += ax;\
   }\
 }\


/** @endcond INTERNAL_MACRO */

void
draw_line ( const Point * point1, const Point * point2, const int pix_value,
	    Image * img )
{
 SET_FUNC_NAME ( "draw_line" );
 int x1, y1, x2, y2;
 int d, x, y, ax, ay, sx, sy, dx, dy;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR ( "Not a binary or label image !" );
  }

 if ( is_bin_img ( img ) && pix_value < 0 )
  {
   ERROR ( "Pixel value ( %d ) must be non-negative !", pix_value );
  }

 x1 = point1->col;
 y1 = point1->row;
 x2 = point2->col;
 y2 = point2->row;

 dx = x2 - x1;
 ax = abs ( dx ) << 1;
 sx = ( dx < 0 ) ? -1 : 1;
 dy = y2 - y1;
 ay = abs ( dy ) << 1;
 sy = ( dy < 0 ) ? -1 : 1;

 x = x1;
 y = y1;

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   DRAW_LINE (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   DRAW_LINE (  );
  }
}
