
/** 
 * @file filter_acwvdf.c
 * Routines for ACWVDF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the ACWVDF (Adaptive Center-Weighted Vector Directional Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] lambda Lambda parameter of the algorithm { [1, WIN_SIZE^2 / 2 - 1] }
 * @param[in] tolerance Noise detection threshold { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco Lukac recommends LAMBDA = 2 and TOLERANCE = 0.19
 *
 * @ref 1) Lukac R. (2004) "Adaptive Color Image Filtering Based on Center-Weighted 
 *         Vector Directional Filters" Multidimensional Systems and Signal Processing, 
 *         15(2): 169-196
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
filter_acwvdf ( const Image * in_img, const int win_size,
		const int lambda, const double tolerance )
{
 SET_FUNC_NAME ( "filter_acwvdf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int ik;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int BVDF_index;
 int ik_start;
 int min_angle_index;
 int *red, *green, *blue;
 Bool is_weight_one;
 double min_angle;
 double acos_arg;
 double value;
 double *angle_sum;
 double *vec_len;
 double **angle_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( ( lambda < 1 ) || ( lambda > ( win_size * win_size ) / 2 - 1 ) )
  {
   ERROR ( "Lambda ( %d ) must be in [1, %d] range !", lambda,
	   ( win_size * win_size ) / 2 - 1 );
   return NULL;
  }

 if ( !IS_POS ( tolerance ) )
  {
   ERROR ( "Tolerance ( %f ) must be positive !", tolerance );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 if ( win_count - 2 * lambda - 2 == 1 )
  {
   is_weight_one = true;
   ik_start = lambda + 1;
  }
 else
  {
   is_weight_one = false;
   ik_start = lambda + 2;
  }

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 vec_len = ( double * ) malloc ( win_count * sizeof ( double ) );
 angle_sum = ( double * ) malloc ( win_count * sizeof ( double ) );

 angle_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the vector lengths */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       vec_len[iwr] = L2_NORM_3D ( red[iwr], blue[iwr], green[iwr] );
      }

     /* Calculate the angles between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   if ( vec_len[iwc] > 0.0 )
	    {
	     /* ( dot product ) / ( || vector1 || * || vector2 || ) */
	     acos_arg =
	      ( red[iwr] * red[iwc] + green[iwr] * green[iwc] +
		blue[iwr] * blue[iwc] ) / ( vec_len[iwr] * vec_len[iwc] );

	     /* Calculate the angle between the two color vectors */
	     angle_mat[iwr][iwc] = ACOS ( acos_arg );
	    }
	   else
	    {
	     /* Idempotent values */
	     angle_mat[iwr][iwc] = 0.0;
	    }
	  }
	}
      }

     /* 
        Calculate the cumulative angles for each pixel
        (assume that the center pixel weight is 1.0).
        Determine the BVDF output. 
      */

     memset ( angle_sum, 0, win_count * sizeof ( double ) );
     min_angle = DBL_MAX;
     BVDF_index = center_pix;

     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   angle_sum[iwr] += angle_mat[iwc][iwr];
	  }

	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   angle_sum[iwr] += angle_mat[iwr][iwc];
	  }

	 if ( angle_sum[iwr] < min_angle )
	  {
	   min_angle = angle_sum[iwr];
	   BVDF_index = iwr;
	  }
	}
      }

     /* 
        Determine the VALUE to be compared against the TOLERANCE. 
        Note that the contribution of the center pixel is still updated 
        at each iteration.
      */
     value = 0.0;

     /* 
        If the center pixel weight is 1.0 in the first iteration, we shouldn't
        double the contribution of the center pixel. Instead, we should only 
        consider the distance between the VMF output and the center pixel. In 
        the remaining 2 iterations, the contribution of the center pixel will 
        be doubled.
      */
     if ( is_weight_one )
      {
       if ( BVDF_index < center_pix )
	{
	 value = angle_mat[BVDF_index][center_pix];
	}
       else
	{
	 value = angle_mat[center_pix][BVDF_index];
	}
      }

     /*
        At each iteration, double the contribution of the center pixel. There 
        are either 2 or 3 iterations depending on the value of IS_WEIGHT_ONE.
      */
     for ( ik = ik_start; ik >= lambda; ik-- )
      {
       for ( iwr = 0; iwr < center_pix; iwr++ )
	{
	 angle_sum[iwr] += 2 * angle_mat[iwr][center_pix];
	}

       for ( iwr = center_pix + 1; iwr < win_count; iwr++ )
	{
	 angle_sum[iwr] += 2 * angle_mat[center_pix][iwr];
	}

       min_angle = DBL_MAX;
       min_angle_index = center_pix;
       for ( iwr = 0; iwr < win_count; iwr++ )
	{
	 if ( vec_len[iwr] > 0.0 )
	  {
	   if ( angle_sum[iwr] < min_angle )
	    {
	     min_angle = angle_sum[iwr];
	     min_angle_index = iwr;
	    }
	  }
	}

       /* Equation (28) */
       acos_arg = ( red[min_angle_index] * red[center_pix]
		    + green[min_angle_index] * green[center_pix]
		    + blue[min_angle_index] * blue[center_pix] )
	/ ( vec_len[min_angle_index] * vec_len[center_pix] );

       value += ACOS ( acos_arg );
      }

     /* Switching Condition (7) */
     if ( value <= tolerance )	/* Center pixel is noise-free */
      {
       out_data[ir][ic][0] = red[center_pix];
       out_data[ir][ic][1] = green[center_pix];
       out_data[ir][ic][2] = blue[center_pix];
      }
     else			/* Center pixel is noisy => Replace it with BVDF output */
      {
       out_data[ir][ic][0] = red[BVDF_index];
       out_data[ir][ic][1] = green[BVDF_index];
       out_data[ir][ic][2] = blue[BVDF_index];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( vec_len );
 free ( angle_sum );
 free_nd ( angle_mat, 2 );

 return out_img;
}
