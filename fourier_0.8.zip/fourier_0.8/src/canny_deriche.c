
/*
Software  Edges3D (c) INRIA 1999 in its version of the Dec 8 1999, 
hereinafter referred to as "THE SOFTWARE".

The SOFTWARE has been designed and produced by Gregoire Malandain, 
researcher of the project Epidaure, a research project of the National 
Computer and Automatics Institute (INRIA), Domaine de Voluceau, 
Rocquencourt, 78153 Le Chesnay Cedex.

INRIA holds all the patent rights concerning the   SOFTWARE
The SOFTWARE has been registered at the Agency for the Protection of
Programmes (APP) under the number          .
IDDN.FR.001.280037.00.R.P.1998.000.21000

Foreword

The SOFTWARE is currently being developed and INRIA wishes for it to be
used by the scientific world so as to test, evaluate and continually update
it.
To this end, INRIA has decided to distribute the prototype of the SOFTWARE
by FIP in a source form.

a) Extent of the rights granted by INRIA to the user of the SOFTWARE.

INRIA freely grants the right to use, modify and integrate the SOFTWARE in
another software.

b) Reproduction of the SOFTWARE

- Clauses 9 and 10 of the Berne agreement for the protection of literary
and artistic works (Union of Berne) respectively specify in their
paragraphs 2 and 3 authorizing only the reproduction and quoting of works
on the condition that :
-       "this reproduction does not adversely affect the normal
exploitation of the work or cause any unjustified prejudice to the
legitimate interests of the author".
-       that the quotations given by way of illustration and/or tuition
conform to the proper uses and that it mentions the source and name of the
author if this name features in the source",
any use or reproduction of  the software items and/or documents exclusively
owned by  INRIA and carried out to obtain profit  or for commercial ends
being subject to obtaining the prior express authorization of INRIA.
Any commercial use made without obtaining the prior express agreement of
the INRIA would therefore constitute a fraudulent imitation.

c) Return of information

Any user of the SOFTWARE shall send his comments on the use of the SOFTWARE
to  INRIA at (gregoire.malandain@sophia.inria.fr).

d) Guarantees

Note that the SOFTWARE is a research product currently being developed. 

INRIA disclaims any responsibility in any way in any
instance of being obliged to put right any possible direct or indirect
damage sustained by the user.
*/

#include <image.h>

typedef enum
{
 NODERIVATIVE = -1 /* no derivative (no filtering) */ ,
 DERIVATIVE_0 = 0 /* smoothing */ ,
 SMOOTHING = 0 /* smoothing */ ,
 DERIVATIVE_1 = 1 /* derivative of order 1 */ ,
 DERIVATIVE_2 = 2 /* derivative of order 2 */ ,
 DERIVATIVE_3 = 3 /* derivative of order 3 */ ,
 DERIVATIVE_1_CONTOURS = 11	/* derivative of order 1, normalization adapted to
				   contours. The response to a step-edge is the 
				   height of the step. */ ,
 DERIVATIVE_1_EDGES = 11	/* derivative of order 1, normalization adapted to
				   contours. The response to a step-edge is the 
				   height of the step. */
} derivativeOrder;

typedef char s8;
typedef unsigned char u8;
typedef short int s16;
typedef unsigned short int u16;
typedef int i32;
typedef int s32;
typedef unsigned long int u64;
typedef float r32;
typedef double r64;

static int _VERBOSE_ = 0;

#define EXIT_ON_FAILURE 0
#define EXIT_ON_SUCCESS 1

/*************************************************************************
 * convert.c - conversion between types
 *
 * $Id: convert.c,v 1.4 2000/02/24 11:25:09 greg Exp $
 *
 * Copyright�INRIA 1999
 *
 * AUTHOR:
 * Gregoire Malandain (greg@sophia.inria.fr)
 * 
 * CREATION DATE: 
 * June, 9 1998
 *
 * ADDITIONS, CHANGES
 *
 * - Tue Feb 22 11:25:39 MET 2000 (G. Malandain)
 *   add in ConvertBuffer():
 *       USHORT to UCHAR
 *       USHORT to SHORT
 *
 */

void
ConvertBuffer ( void *bufferIn,
		bufferType typeIn,
		void *bufferOut, bufferType typeOut, int bufferLength )
{
 char *proc = "ConvertBuffer";
 register int i, min, max;
 register u8 *u8buf;
 register s8 *s8buf;
 register u16 *u16buf;
 register s16 *s16buf;
 register s32 *s32buf;
 register r32 *r32buf;
 register r64 *r64buf;

 if ( ( typeOut == typeIn ) && ( bufferOut == bufferIn ) )
  return;

 if ( bufferLength <= 0 )
  {
   fprintf ( stderr, " Fatal error in %s: buffer length is negative or zero.\n",
	     proc );
   return;
  }
 if ( ( bufferIn == ( void * ) NULL ) || ( bufferOut == ( void * ) NULL ) )
  {
   fprintf ( stderr, " Fatal error in %s: NULL buffer(s).\n", proc );
   return;
  }

 switch ( typeOut )
  {
   case SCHAR:
    s8buf = ( s8 * ) bufferOut;
    min = -128;
    max = 127;
    switch ( typeIn )
     {
      case SCHAR:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( s8 ) );
       break;
      case FLOAT:
       r32buf = ( r32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s8buf++, r32buf++ )
	{
	 if ( *r32buf < min )
	  *s8buf = min;
	 else if ( *r32buf < 0.0 )
	  *s8buf = ( int ) ( *r32buf - 0.5 );
	 else if ( *r32buf < max )
	  *s8buf = ( int ) ( *r32buf + 0.5 );
	 else
	  *s8buf = max;
	}
       break;
      case DOUBLE:
       r64buf = ( r64 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s8buf++, r64buf++ )
	{
	 if ( *r64buf < min )
	  *s8buf = min;
	 else if ( *r64buf < 0.0 )
	  *s8buf = ( int ) ( *r64buf - 0.5 );
	 else if ( *r64buf < max )
	  *s8buf = ( int ) ( *r64buf + 0.5 );
	 else
	  *s8buf = max;
	}
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = SCHAR */

   case UCHAR:
    u8buf = ( u8 * ) bufferOut;
    min = 0;
    max = 255;
    switch ( typeIn )
     {
      case UCHAR:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( u8 ) );
       break;
      case USHORT:
       u16buf = ( u16 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, u8buf++, u16buf++ )
	{
	 if ( *u16buf < max )
	  *u8buf = ( u8 ) * u16buf;
	 else
	  *u8buf = max;
	}
       break;
      case FLOAT:
       r32buf = ( r32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, u8buf++, r32buf++ )
	{
	 if ( *r32buf < min )
	  *u8buf = min;
	 else if ( *r32buf < max )
	  *u8buf = ( int ) ( *r32buf + 0.5 );
	 else
	  *u8buf = max;
	}
       break;
      case DOUBLE:
       r64buf = ( r64 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, u8buf++, r64buf++ )
	{
	 if ( *r64buf < min )
	  *u8buf = min;
	 else if ( *r64buf < max )
	  *u8buf = ( int ) ( *r64buf + 0.5 );
	 else
	  *u8buf = max;
	}
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = UCHAR */

   case SSHORT:
    s16buf = ( s16 * ) bufferOut;
    min = -32768;
    max = 32767;
    switch ( typeIn )
     {
      case SSHORT:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( s16 ) );
       break;
      case USHORT:
       u16buf = ( u16 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s16buf++, u16buf++ )
	{
	 if ( *u16buf < max )
	  *s16buf = ( s16 ) * u16buf;
	 else
	  *s16buf = max;
	}
       break;
      case FLOAT:
       r32buf = ( r32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s16buf++, r32buf++ )
	{
	 if ( *r32buf < min )
	  *s16buf = min;
	 else if ( *r32buf < 0.0 )
	  *s16buf = ( int ) ( *r32buf - 0.5 );
	 else if ( *r32buf < max )
	  *s16buf = ( int ) ( *r32buf + 0.5 );
	 else
	  *s16buf = max;
	}
       break;
      case DOUBLE:
       r64buf = ( r64 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s16buf++, r64buf++ )
	{
	 if ( *r64buf < min )
	  *s16buf = min;
	 else if ( *r64buf < 0.0 )
	  *s16buf = ( int ) ( *r64buf - 0.5 );
	 else if ( *r64buf < max )
	  *s16buf = ( int ) ( *r64buf + 0.5 );
	 else
	  *s16buf = max;
	}
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = SSHORT */

   case USHORT:
    u16buf = ( u16 * ) bufferOut;
    min = 0;
    max = 65535;
    switch ( typeIn )
     {
      case USHORT:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( u16 ) );
       break;
      case FLOAT:
       r32buf = ( r32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, u16buf++, r32buf++ )
	{
	 if ( *r32buf < min )
	  *u16buf = min;
	 else if ( *r32buf < 0.0 )
	  *u16buf = ( int ) ( *r32buf - 0.5 );
	 else if ( *r32buf < max )
	  *u16buf = ( int ) ( *r32buf + 0.5 );
	 else
	  *u16buf = max;
	}
       break;
      case DOUBLE:
       r64buf = ( r64 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, u16buf++, r64buf++ )
	{
	 if ( *r64buf < min )
	  *u16buf = min;
	 else if ( *r64buf < 0.0 )
	  *u16buf = ( int ) ( *r64buf - 0.5 );
	 else if ( *r64buf < max )
	  *u16buf = ( int ) ( *r64buf + 0.5 );
	 else
	  *u16buf = max;
	}
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = USHORT */

   case INT:
    s32buf = ( s32 * ) bufferOut;
    switch ( typeIn )
     {
      case INT:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( s32 ) );
       break;
      case FLOAT:
       r32buf = ( r32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s32buf++, r32buf++ )
	{
	 *s32buf = ( int ) ( *r32buf );
	}
       break;
      case DOUBLE:
       r64buf = ( r64 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, s32buf++, r64buf++ )
	{
	 *s32buf = ( int ) ( *r64buf );
	}
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = INT */

   case FLOAT:
    r32buf = ( r32 * ) bufferOut;
    switch ( typeIn )
     {
      case UCHAR:
       u8buf = ( u8 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, u8buf++ )
	{
	 *r32buf = ( float ) ( *u8buf );
	}
       break;
      case SCHAR:
       s8buf = ( s8 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, s8buf++ )
	{
	 *r32buf = ( float ) ( *s8buf );
	}
       break;
      case USHORT:
       u16buf = ( u16 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, u16buf++ )
	{
	 *r32buf = ( float ) ( *u16buf );
	}
       break;
      case SSHORT:
       s16buf = ( s16 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, s16buf++ )
	{
	 *r32buf = ( float ) ( *s16buf );
	}
       break;
      case INT:
       s32buf = ( s32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, s32buf++ )
	{
	 *r32buf = ( float ) ( *s32buf );
	}
       break;
      case FLOAT:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( r32 ) );
       break;
      case DOUBLE:
       r64buf = ( r64 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, r64buf++ )
	{
	 *r32buf = ( float ) ( *r64buf );
	}
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = FLOAT */

   case DOUBLE:
    r64buf = ( r64 * ) bufferOut;
    switch ( typeIn )
     {
      case UCHAR:
       u8buf = ( u8 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r64buf++, u8buf++ )
	{
	 *r64buf = ( float ) ( *u8buf );
	}
       break;
      case SCHAR:
       s8buf = ( s8 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r64buf++, s8buf++ )
	{
	 *r64buf = ( float ) ( *s8buf );
	}
       break;
      case USHORT:
       u16buf = ( u16 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r64buf++, u16buf++ )
	{
	 *r64buf = ( float ) ( *u16buf );
	}
       break;
      case SSHORT:
       s16buf = ( s16 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r64buf++, s16buf++ )
	{
	 *r64buf = ( float ) ( *s16buf );
	}
       break;
      case INT:
       s32buf = ( s32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r64buf++, s32buf++ )
	{
	 *r64buf = ( float ) ( *s32buf );
	}
       break;
      case FLOAT:
       r32buf = ( r32 * ) bufferIn;
       for ( i = bufferLength; i > 0; i--, r32buf++, r64buf++ )
	{
	 *r64buf = ( double ) ( *r32buf );
	}
       break;
      case DOUBLE:
       if ( bufferOut == bufferIn )
	return;
       ( void ) memcpy ( bufferOut, bufferIn, bufferLength * sizeof ( r64 ) );
       break;
      default:
       fprintf ( stderr, " Error in %s: such conversion not yet implemented.\n",
		 proc );
       return;
     }
    break;			/* end case typeOut = DOUBLE */

   default:
    fprintf ( stderr, " Error in %s: such output type not yet handled.\n",
	      proc );
    return;
  }
}

/*************************************************************************
 * recline.c - tools for recursive filtering of 1D lines
 *
 * $Id: recline.c,v 1.3 1999/12/08 16:35:13 greg Exp $
 *
 * Copyright�INRIA 1999
 *
 * DESCRIPTION: 
 *
 * Recursive filtering of a line (a 1D array)
 * Filter coefficient are static variables.
 *
 *
 * AUTHOR:
 * Gregoire Malandain (greg@sophia.inria.fr)
 * 
 * CREATION DATE: 
 * June, 9 1998
 *
 * Copyright Gregoire Malandain, INRIA
 *
 * ADDITIONS, CHANGES
 *
 */

/*--- denominateur       ---*/
static double sd1 = 0.0, sd2 = 0.0, sd3 = 0.0, sd4 = 0.0;

/*--- numerateur positif ---*/
static double sp0 = 0.0, sp1 = 0.0, sp2 = 0.0, sp3 = 0.0;

/*--- numerateur negatif ---*/
static double sn0 = 0.0, sn1 = 0.0, sn2 = 0.0, sn3 = 0.0, sn4 = 0.0;

/*--- type de filtre en cours ---*/
static recursiveFilterType static_type_filter = UNKNOWN_FILTER;
static derivativeOrder static_derivative = NODERIVATIVE;

void
InitRecursiveCoefficients ( double x,
			    recursiveFilterType type_filter,
			    derivativeOrder derivative )
{
 char *proc = "InitRecursiveCoefficients";
 double ex, k1, k2;
 double a0, a1, c0, c1, omega0, omega1, b0, b1;
 double cos0, sin0, cos1, sin1;
 double sumA = 0.0, sumC = 0.0, aux;

 sd1 = sd2 = sd3 = sd4 = 0.0;
 sp0 = sp1 = sp2 = sp3 = 0.0;
 sn0 = sn1 = sn2 = sn3 = sn4 = 0.0;

 static_type_filter = UNKNOWN_FILTER;
 static_derivative = NODERIVATIVE;

 ex = k1 = k2 = 0.0;
 a0 = a1 = c0 = c1 = 0.0;
 b0 = b1 = omega0 = omega1 = 0.0;

  /*--- Selon le type de filtrage (filtres de Deriche,
    ou approximation de la gaussienne), x designe
    soit alpha, soit sigma                         ---*/

 switch ( type_filter )
  {

   case GAUSSIAN_DERICHE:

    if ( x < 0.1 )
     {
      if ( _VERBOSE_ != 0 )
       {
	fprintf ( stderr,
		  "%s: improper value of coefficient (should be >= 0.1).\n",
		  proc );
       }
      return;
     }

    switch ( derivative )
     {
      default:
       if ( _VERBOSE_ != 0 )
	{
	 fprintf ( stderr, "%s: switch to default coefficients (smoothing).\n",
		   proc );
	}
       derivative = DERIVATIVE_0;
      case DERIVATIVE_0:
       a0 = 1.68;
       omega0 = 0.6318;
       a1 = 3.735;
       b0 = 1.783;
       c0 = -0.6803;
       omega1 = 1.997;
       c1 = -0.2598;
       b1 = 1.723;
       break;
      case DERIVATIVE_1:
      case DERIVATIVE_1_CONTOURS:
       a0 = -0.6472;
       omega0 = 0.6719;
       a1 = -4.531;
       b0 = 1.527;
       c0 = 0.6494;
       omega1 = 2.072;
       c1 = 0.9557;
       b1 = 1.516;
       break;
      case DERIVATIVE_2:
       a0 = -1.331;
       omega0 = 0.748;
       a1 = 3.661;
       b0 = 1.24;
       c0 = 0.3225;
       omega1 = 2.166;
       c1 = -1.738;
       b1 = 1.314;
     }

    omega0 /= x;
    sin0 = sin ( omega0 );
    cos0 = cos ( omega0 );
    omega1 /= x;
    sin1 = sin ( omega1 );
    cos1 = cos ( omega1 );
    b0 /= x;
    b1 /= x;

    /*--- normalisation ---*/
    switch ( derivative )
     {
      default:
      case DERIVATIVE_0:
       sumA =
	2.0 * a1 * exp ( b0 ) * cos0 * cos0 - a0 * sin0 * exp ( 2.0 * b0 );
       sumA += a0 * sin0 - 2.0 * a1 * exp ( b0 );
       sumA /= ( 2.0 * cos0 * exp ( b0 ) - exp ( 2.0 * b0 ) - 1 ) * sin0;
       sumC =
	2.0 * c1 * exp ( b1 ) * cos1 * cos1 - c0 * sin1 * exp ( 2.0 * b1 );
       sumC += c0 * sin1 - 2.0 * c1 * exp ( b1 );
       sumC /= ( 2.0 * cos1 * exp ( b1 ) - exp ( 2.0 * b1 ) - 1 ) * sin1;
       break;
      case DERIVATIVE_1:
       aux = exp ( 4.0 * b0 ) - 4.0 * cos0 * exp ( 3.0 * b0 );
       aux += 2.0 * exp ( 2.0 * b0 ) + 4.0 * cos0 * cos0 * exp ( 2.0 * b0 );
       aux += 1.0 - 4.0 * cos0 * exp ( b0 );
       sumA = a0 * cos0 - a1 * sin0 + a1 * sin0 * exp ( 2.0 * b0 );
       sumA += a0 * cos0 * exp ( 2.0 * b0 ) - 2.0 * a0 * exp ( b0 );
       sumA *= exp ( b0 ) / aux;
       aux = exp ( 4.0 * b1 ) - 4.0 * cos1 * exp ( 3.0 * b1 );
       aux += 2.0 * exp ( 2.0 * b1 ) + 4.0 * cos1 * cos1 * exp ( 2.0 * b1 );
       aux += 1.0 - 4.0 * cos1 * exp ( b1 );
       sumC = c0 * cos1 - c1 * sin1 + c1 * sin1 * exp ( 2.0 * b1 );
       sumC += c0 * cos1 * exp ( 2.0 * b1 ) - 2.0 * c0 * exp ( b1 );
       sumC *= exp ( b1 ) / aux;

      /*--- on multiplie les sommes par 2 car on n'a calcule que des demi-sommes 
	et on change le signe car la somme doit etre egale a -1              ---*/
       sumA *= ( -2.0 );
       sumC *= ( -2.0 );
       break;
      case DERIVATIVE_1_CONTOURS:

      /*--- la somme de 1 a l'infini est egale a 1 : cela introduit
	un petit biais (reponse un rien superieur a la hauteur du step).
	Avec une somme de 0 a l'infini, c'est pire                       ---*/
       sumA = a1 * exp ( b0 ) - a1 * cos0 * cos0 * exp ( b0 );
       sumA += a0 * cos0 * sin0 * exp ( b0 ) - a0 * sin0;
       sumA /= sin0 * ( 2.0 * cos0 * exp ( b0 ) - exp ( 2.0 * b0 ) - 1 );
       sumC = c1 * exp ( b1 ) - c1 * cos1 * cos1 * exp ( b1 );
       sumC += c0 * cos1 * sin1 * exp ( b1 ) - c0 * sin1;
       sumC /= sin1 * ( 2.0 * cos1 * exp ( b1 ) - exp ( 2.0 * b1 ) - 1 );
       break;
      case DERIVATIVE_2:
       aux = 12.0 * cos0 * exp ( 3.0 * b0 ) - 3.0 * exp ( 2.0 * b0 );
       aux +=
	8.0 * cos0 * cos0 * cos0 * exp ( 3.0 * b0 ) -
	12.0 * cos0 * cos0 * exp ( 4.0 * b0 );
       aux -= 3.0 * exp ( 4.0 * b0 );
       aux +=
	6.0 * cos0 * exp ( 5.0 * b0 ) - exp ( 6.0 * b0 ) +
	6.0 * cos0 * exp ( b0 );
       aux -= ( 1.0 + 12.0 * cos0 * cos0 * exp ( 2.0 * b0 ) );
       sumA =
	4.0 * a0 * sin0 * exp ( 3.0 * b0 ) +
	a1 * cos0 * cos0 * exp ( 4.0 * b0 );
       sumA -=
	( 4.0 * a0 * sin0 * exp ( b0 ) +
	  6.0 * a1 * cos0 * cos0 * exp ( 2.0 * b0 ) );
       sumA +=
	2.0 * a1 * cos0 * cos0 * cos0 * exp ( b0 ) -
	2.0 * a1 * cos0 * exp ( b0 );
       sumA +=
	2.0 * a1 * cos0 * cos0 * cos0 * exp ( 3.0 * b0 ) -
	2.0 * a1 * cos0 * exp ( 3.0 * b0 );
       sumA += a1 * cos0 * cos0 - a1 * exp ( 4.0 * b0 );
       sumA +=
	2.0 * a0 * sin0 * cos0 * cos0 * exp ( b0 ) -
	2.0 * a0 * sin0 * cos0 * cos0 * exp ( 3.0 * b0 );
       sumA -= ( a0 * sin0 * cos0 * exp ( 4.0 * b0 ) + a1 );
       sumA += 6.0 * a1 * exp ( 2.0 * b0 ) + a0 * cos0 * sin0;
       sumA *= 2.0 * exp ( b0 ) / ( aux * sin0 );
       aux = 12.0 * cos1 * exp ( 3.0 * b1 ) - 3.0 * exp ( 2.0 * b1 );
       aux +=
	8.0 * cos1 * cos1 * cos1 * exp ( 3.0 * b1 ) -
	12.0 * cos1 * cos1 * exp ( 4.0 * b1 );
       aux -= 3.0 * exp ( 4.0 * b1 );
       aux +=
	6.0 * cos1 * exp ( 5.0 * b1 ) - exp ( 6.0 * b1 ) +
	6.0 * cos1 * exp ( b1 );
       aux -= ( 1.0 + 12.0 * cos1 * cos1 * exp ( 2.0 * b1 ) );
       sumC =
	4.0 * c0 * sin1 * exp ( 3.0 * b1 ) +
	c1 * cos1 * cos1 * exp ( 4.0 * b1 );
       sumC -=
	( 4.0 * c0 * sin1 * exp ( b1 ) +
	  6.0 * c1 * cos1 * cos1 * exp ( 2.0 * b1 ) );
       sumC +=
	2.0 * c1 * cos1 * cos1 * cos1 * exp ( b1 ) -
	2.0 * c1 * cos1 * exp ( b1 );
       sumC +=
	2.0 * c1 * cos1 * cos1 * cos1 * exp ( 3.0 * b1 ) -
	2.0 * c1 * cos1 * exp ( 3.0 * b1 );
       sumC += c1 * cos1 * cos1 - c1 * exp ( 4.0 * b1 );
       sumC +=
	2.0 * c0 * sin1 * cos1 * cos1 * exp ( b1 ) -
	2.0 * c0 * sin1 * cos1 * cos1 * exp ( 3.0 * b1 );
       sumC -= ( c0 * sin1 * cos1 * exp ( 4.0 * b1 ) + c1 );
       sumC += 6.0 * c1 * exp ( 2.0 * b1 ) + c0 * cos1 * sin1;
       sumC *= 2.0 * exp ( b1 ) / ( aux * sin1 );

      /*--- on divise les sommes par 2 (la somme doit etre egale a 2) ---*/
       sumA /= 2;
       sumC /= 2;
     }
    a0 /= ( sumA + sumC );
    a1 /= ( sumA + sumC );
    c0 /= ( sumA + sumC );
    c1 /= ( sumA + sumC );

    /*--- coefficients du calcul recursif ---*/
    sp0 = a0 + c0;
    sp1 = exp ( -b1 ) * ( c1 * sin1 - ( c0 + 2 * a0 ) * cos1 );
    sp1 += exp ( -b0 ) * ( a1 * sin0 - ( 2 * c0 + a0 ) * cos0 );
    sp2 =
     2.0 * exp ( -b0 - b1 ) * ( ( a0 + c0 ) * cos1 * cos0 - cos1 * a1 * sin0 -
				cos0 * c1 * sin1 );
    sp2 += c0 * exp ( -2.0 * b0 ) + a0 * exp ( -2.0 * b1 );
    sp3 = exp ( -b1 - 2.0 * b0 ) * ( c1 * sin1 - c0 * cos1 );
    sp3 += exp ( -b0 - 2.0 * b1 ) * ( a1 * sin0 - a0 * cos0 );

    sd1 = -2.0 * exp ( -b1 ) * cos1 - 2.0 * exp ( -b0 ) * cos0;
    sd2 =
     4.0 * cos1 * cos0 * exp ( -b0 - b1 ) + exp ( -2.0 * b1 ) +
     exp ( -2.0 * b0 );
    sd3 =
     -2.0 * cos0 * exp ( -b0 - 2.0 * b1 ) - 2.0 * cos1 * exp ( -b1 - 2.0 * b0 );
    sd4 = exp ( -2.0 * b0 - 2.0 * b1 );

    switch ( derivative )
     {
      default:
      case DERIVATIVE_0:
      case DERIVATIVE_2:
       sn1 = sp1 - sd1 * sp0;
       sn2 = sp2 - sd2 * sp0;
       sn3 = sp3 - sd3 * sp0;
       sn4 = -sd4 * sp0;
       break;
      case DERIVATIVE_1:
      case DERIVATIVE_1_CONTOURS:
      case DERIVATIVE_3:
       sn1 = -sp1 + sd1 * sp0;
       sn2 = -sp2 + sd2 * sp0;
       sn3 = -sp3 + sd3 * sp0;
       sn4 = sd4 * sp0;
     }

    static_type_filter = type_filter;
    static_derivative = derivative;
    break;

   default:
    if ( _VERBOSE_ != 0 )
     {
      fprintf ( stderr,
		"%s: switch to default recursive filter (Deriche's filters).\n",
		proc );
     }
    type_filter = ALPHA_DERICHE;
   case ALPHA_DERICHE:

    if ( ( x < 0.1 ) || ( x > 1.9 ) )
     {
      if ( _VERBOSE_ != 0 )
       {
	fprintf ( stderr,
		  "%s: improper value of coefficient (should be >= 0.1 and <= 1.9).\n",
		  proc );
       }
      return;
     }
    ex = exp ( ( -x ) );

    switch ( derivative )
     {
      default:
       if ( _VERBOSE_ != 0 )
	{
	 fprintf ( stderr, "%s: switch to default coefficients (smoothing).\n",
		   proc );
	}
       derivative = DERIVATIVE_0;
      case DERIVATIVE_0:
       sp0 = ( 1.0 - ex ) * ( 1.0 - ex ) / ( 1.0 + 2.0 * x * ex - ex * ex );
       sp1 = sp0 * ( x - 1.0 ) * ex;
       sn1 = sp0 * ( x + 1.0 ) * ex;
       sn2 = ( -sp0 ) * ex * ex;
       sd1 = ( -2.0 ) * ex;
       sd2 = ex * ex;
       break;
      case DERIVATIVE_1:
       sp1 =
	-( 1.0 - ex ) * ( 1.0 - ex ) * ( 1.0 - ex ) / ( 2.0 * ( 1.0 + ex ) );
       sn1 = ( -sp1 );
       sd1 = ( -2.0 ) * ex;
       sd2 = ex * ex;
       break;
      case DERIVATIVE_1_CONTOURS:
       sp1 = -( 1.0 - ex ) * ( 1.0 - ex );
       sn1 = ( -sp1 );
       sd1 = ( -2.0 ) * ex;
       sd2 = ex * ex;
       break;
      case DERIVATIVE_2:
       k1 = ( -2.0 ) * ( 1.0 - ex ) * ( 1.0 - ex ) * ( 1.0 - ex );
       k1 /= ( 1.0 + ex ) * ( 1.0 + ex ) * ( 1.0 + ex );
       k2 = ( 1.0 - ex * ex ) / ( 2.0 * ex );
       sp0 = k1;
       sp1 = ( -k1 ) * ( 1.0 + k2 ) * ex;
       sn1 = k1 * ( 1.0 - k2 ) * ex;
       sn2 = ( -k1 ) * ex * ex;
       sd1 = ( -2.0 ) * ex;
       sd2 = ex * ex;
       break;
      case DERIVATIVE_3:
       k1 = ( 1.0 + x ) * ex + ( x - 1.0 );
       k2 = ( 1.0 - ex ) / k1;
       k1 *= ( 1.0 - ex ) * ( 1.0 - ex ) * ( 1.0 - ex ) * ( 1.0 - ex );
       k1 /= 2.0 * x * x * ex * ex;
       k1 /= ex + 1.0;
       sp0 = k1 * x * ( k2 + 1.0 );
       sp1 = ( -k1 ) * x * ( 1.0 + k2 + k2 * x ) * ex;
       sn0 = ( -sp0 );
       sn1 = ( -sp1 );
       sd1 = ( -2.0 ) * ex;
       sd2 = ex * ex;
     }
    static_type_filter = type_filter;
    static_derivative = derivative;
  }
}

int
RecursiveFilter1D ( double *in,
		    double *out, double *work1, double *work2, int dim )
{
 char *proc = "RecursiveFilter1D";
 register double rp0, rp1, rp2, rp3;
 register double rd1, rd2, rd3, rd4;
 register double rn0, rn1, rn2, rn3, rn4;
 register int i;
 register double *w0, *w1, *w2, *w3, *w4;
 register double *d0, *d1, *d2, *d3, *d4;

 if ( static_type_filter == UNKNOWN_FILTER )
  {
   if ( _VERBOSE_ != 0 )
    fprintf ( stderr, "%s: unknown type of recursive filter.\n", proc );
   return ( EXIT_ON_FAILURE );
  }
 if ( static_derivative == NODERIVATIVE )
  {
   if ( _VERBOSE_ != 0 )
    fprintf ( stderr, "%s: unknown type of derivative.\n", proc );
   return ( EXIT_ON_FAILURE );
  }

 rd1 = rd2 = rd3 = rd4 = 0.0;
 rp0 = rp1 = rp2 = rp3 = 0.0;
 rn0 = rn1 = rn2 = rn3 = rn4 = 0.0;

 switch ( static_type_filter )
  {
   case GAUSSIAN_DERICHE:

    /*--- filtrage generique d'ordre 4 ---*/
    rp0 = sp0;
    rp1 = sp1;
    rp2 = sp2;
    rp3 = sp3;
    rd1 = sd1;
    rd2 = sd2;
    rd3 = sd3;
    rd4 = sd4;
    rn1 = sn1;
    rn2 = sn2;
    rn3 = sn3;
    rn4 = sn4;

    /* on positionne les pointeurs 
     */
    w4 = work1;
    w3 = w4 + 1;
    w2 = w3 + 1;
    w1 = w2 + 1;
    w0 = w1 + 1;
    d3 = in + 1;
    d2 = d3 + 1;
    d1 = d2 + 1;
    d0 = d1 + 1;

    /*--- calcul de y+ ---*/
    *( w4 ) = rp0 * *( in );
    *( w3 ) = rp0 * *( d3 ) + rp1 * *( in ) - rd1 * *( w4 );
    *( w2 ) = rp0 * *( d2 ) + rp1 * *( d3 ) + rp2 * *( in )
     - rd1 * *( w3 ) - rd2 * *( w4 );
    *( w1 ) = rp0 * *( d1 ) + rp1 * *( d2 ) + rp2 * *( d3 ) + rp3 * *( in )
     - rd1 * *( w2 ) - rd2 * *( w3 ) - rd3 * *( w4 );
    for ( i = 4; i < dim;
	  i++, w0++, w1++, w2++, w3++, w4++, d0++, d1++, d2++, d3++ )
     *( w0 ) =
      rp0 * *( d0 ) + rp1 * *( d1 ) + rp2 * *( d2 ) + rp3 * *( d3 ) -
      rd1 * *( w1 ) - rd2 * *( w2 ) - rd3 * *( w3 ) - rd4 * *( w4 );

    /* on positionne les pointeurs 
     */
    w4 = work2 + dim - 1;
    w3 = w4 - 1;
    w2 = w3 - 1;
    w1 = w2 - 1;
    w0 = w1 - 1;
    d4 = in + dim - 1;
    d3 = d4 - 1;
    d2 = d3 - 1;
    d1 = d2 - 1;

    /*--- calcul de y- ---*/
    *( w4 ) = 0;
    *( w3 ) = rn1 * *( d4 );
    *( w2 ) = rn1 * *( d3 ) + rn2 * *( d4 ) - rd1 * *( w3 );
    *( w1 ) = rn1 * *( d2 ) + rn2 * *( d3 ) + rn3 * *( d4 )
     - rd1 * *( w2 ) - rd2 * *( w3 );
    for ( i = dim - 5; i >= 0;
	  i--, w0--, w1--, w2--, w3--, w4--, d1--, d2--, d3--, d4-- )
     *( w0 ) =
      rn1 * *( d1 ) + rn2 * *( d2 ) + rn3 * *( d3 ) + rn4 * *( d4 ) -
      rd1 * *( w1 ) - rd2 * *( w2 ) - rd3 * *( w3 ) - rd4 * *( w4 );

    /*--- calcul final ---*/
    w1 = work1;
    w2 = work2;
    d0 = out;
    for ( i = 0; i < dim; i++, w1++, w2++, d0++ )
     *d0 = *w1 + *w2;

    break;

   default:
   case ALPHA_DERICHE:

    switch ( static_derivative )
     {
      default:
      case DERIVATIVE_0:
      case DERIVATIVE_2:

       rp0 = sp0;
       rp1 = sp1;
       rd1 = sd1;
       rd2 = sd2;
       rn1 = sn1;
       rn2 = sn2;

       /* on positionne les pointeurs 
        */
       w2 = work1;
       w1 = w2 + 1;
       w0 = w1 + 1;
       d1 = in + 1;
       d0 = d1 + 1;

      /*--- calcul de y+ ---*/
       *( w2 ) = rp0 * *( in );
       *( w1 ) = rp0 * *( d1 ) + rp1 * *( in ) - rd1 * *( w2 );
       for ( i = 2; i < dim; i++, w0++, w1++, w2++, d0++, d1++ )
	*( w0 ) = rp0 * *( d0 ) + rp1 * *( d1 ) - rd1 * *( w1 ) - rd2 * *( w2 );

       w2 = work2 + dim - 1;
       w1 = w2 - 1;
       w0 = w1 - 1;
       d2 = in + dim - 1;
       d1 = d2 - 1;

      /*--- calcul de y- ---*/
       *( w2 ) = 0.0;
       *( w1 ) = rn1 * *( d2 );
       for ( i = dim - 3; i >= 0; i--, w0--, w1--, w2--, d1--, d2-- )
	*( w0 ) = rn1 * *( d1 ) + rn2 * *( d2 ) - rd1 * *( w1 ) - rd2 * *( w2 );

      /*--- calcul final ---*/
       w1 = work1;
       w2 = work2;
       d0 = out;
       for ( i = 0; i < dim; i++, w1++, w2++, d0++ )
	*d0 = *w1 + *w2;

       break;

      case DERIVATIVE_1:
      case DERIVATIVE_1_CONTOURS:
       rp1 = sp1;
       rn1 = sn1;
       rd1 = sd1;
       rd2 = sd2;

       /* on positionne les pointeurs 
        */
       w2 = work1;
       w1 = w2 + 1;
       w0 = w1 + 1;
       d1 = in + 1;

      /*--- calcul de y+ ---*/
       *( w2 ) = 0.0;
       *( w1 ) = rp1 * *( in );
       for ( i = 2; i < dim; i++, w0++, w1++, w2++, d1++ )
	*( w0 ) = rp1 * *( d1 ) - rd1 * *( w1 ) - rd2 * *( w2 );

       w2 = work2 + dim - 1;
       w1 = w2 - 1;
       w0 = w1 - 1;
       d2 = in + dim - 1;
       d1 = d2 - 1;

      /*--- calcul de y- ---*/
       *( w2 ) = 0.0;
       *( w1 ) = rn1 * *( d2 );
       for ( i = dim - 3; i >= 0; i--, w0--, w1--, w2--, d1-- )
	*( w0 ) = rn1 * *( d1 ) - rd1 * *( w1 ) - rd2 * *( w2 );

      /*--- calcul final ---*/
       w1 = work1;
       w2 = work2;
       d0 = out;
       for ( i = 0; i < dim; i++, w1++, w2++, d0++ )
	*d0 = *w1 + *w2;

       break;

      case DERIVATIVE_3:
       rp0 = sp0;
       rp1 = sp1;
       rd1 = sd1;
       rd2 = sd2;
       rn0 = sn0;
       rn1 = sn1;

       w2 = work1;
       w1 = w2 + 1;
       w0 = w1 + 1;
       d1 = in + 1;
       d0 = d1 + 1;

      /*--- calcul de y+ ---*/
       *( w2 ) = rp0 * *( in );
       *( w1 ) = rp0 * *( d1 ) + rp1 * *( in ) - rd1 * *( w2 );
       for ( i = 2; i < dim; i++, w0++, w1++, w2++, d0++, d1++ )
	*( w0 ) = rp0 * *( d0 ) + rp1 * *( d1 ) - rd1 * *( w1 ) - rd2 * *( w2 );

       w2 = work2 + dim - 1;
       w1 = w2 - 1;
       w0 = w1 - 1;
       d2 = in + dim - 1;
       d1 = d2 - 1;
       d0 = d1 - 1;

      /*--- calcul de y- ---*/
       *( w2 ) = rn0 * *( d2 );
       *( w1 ) = rn0 * *( d1 ) + rn1 * *( d2 ) - rd1 * *( w2 );
       for ( i = dim - 3; i >= 0; i--, w0--, w1--, w2--, d0--, d1-- )
	*( w0 ) = rn0 * *( d0 ) + rn1 * *( d1 ) - rd1 * *( w1 ) - rd2 * *( w2 );

      /*--- calcul final ---*/
       w1 = work1;
       w2 = work2;
       d0 = out;
       for ( i = 0; i < dim; i++, w1++, w2++, d0++ )
	*d0 = *w1 + *w2;

     }
  }
 return ( EXIT_ON_SUCCESS );
}

/*************************************************************************
 * recbuffer.c - tools for recursive filtering of 3D and 2D image buffers
 *
 * $Id: recbuffer.c,v 1.7 2001/09/12 15:37:16 greg Exp $
 *
 * Copyright�INRIA 1999
 *
 * DESCRIPTION: 
 *
 * recursive filtering of a buffer (a [1,2,3]D array)
 * according that the filtering is separable
 *
 *
 *
 * AUTHOR:
 * Gregoire Malandain (greg@sophia.inria.fr)
 * 
 * CREATION DATE: 
 * June, 9 1998
 *
 * Copyright Gregoire Malandain, INRIA
 *
 * ADDITIONS, CHANGES
 *
 * * Jul 6 1999 (Gregoire Malandain)
 *   a bug in RecursiveFilterOnBuffer (*&%^@$^ cut and paste)
 *
 */

int
RecursiveFilterOnBuffer ( void *bufferIn,
			  bufferType typeIn,
			  void *bufferOut,
			  bufferType typeOut,
			  int *bufferDims,
			  int *borderLengths,
			  derivativeOrder * derivatives,
			  float *filterCoefs, recursiveFilterType filterType )
{
 char *proc = "RecursiveFilterOnBuffer";
 register int dimx, dimxXdimy;
 int dimy, dimz;
 register int x, y, z;

 /* 
  *obviously, we need to perform the computation 
  * with float or double values. For this reason,
  * we allocate an auxiliary buffer if the output buffer
  * is not of type float or double.
  */
 void *bufferToBeProcessed = ( void * ) NULL;
 bufferType typeToBeProcessed = TYPE_UNKNOWN;
 void *bufferResult = ( void * ) NULL;
 bufferType typeResult = TYPE_UNKNOWN;

 /*
  * lines' lengths
  */
 int lengthX = 0;
 int lengthY = 0;
 int lengthZ = 0;
 int maxLengthline = 0;
 int borderXlength = 0;
 int borderYlength = 0;
 int borderZlength = 0;

 /*
  * 1D arrays for computations.
  */
 double *theLine = ( double * ) NULL;
 double *resLine = ( double * ) NULL;
 double *tmpLine = ( double * ) NULL;

 /*
  * pointers for computations;
  */
 register r32 *r32firstPoint = ( r32 * ) NULL;
 register r64 *r64firstPoint = ( r64 * ) NULL;
 register r32 *r32_pt = ( r32 * ) NULL;
 register r64 *r64_pt = ( r64 * ) NULL;
 register double *dbl_pt1 = ( double * ) NULL;
 register double *dbl_pt2 = ( double * ) NULL;
 register double dbl_first = 0.0;
 register double dbl_last = 0.0;
 int offsetLastPoint = 0;
 int offsetNextFirstPoint = 0;
 register r32 *r32firstPointResult = ( r32 * ) NULL;
 register r64 *r64firstPointResult = ( r64 * ) NULL;
 double *theLinePlusBorder = ( double * ) NULL;
 double *resLinePlusBorder = ( double * ) NULL;

 /* 
  * We check the buffers' dimensions.
  */
 dimx = bufferDims[0];
 dimy = bufferDims[1];
 dimz = bufferDims[2];
 dimxXdimy = dimx * dimy;
 if ( ( dimx <= 0 ) || ( dimy <= 0 ) || ( dimz <= 0 ) )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr, " Fatal error in %s: improper buffer's dimension.\n",
	      proc );
   return ( EXIT_ON_FAILURE );
  }
 /*
  * We check the pointers.
  */
 if ( ( bufferIn == ( void * ) NULL ) || ( bufferOut == ( void * ) NULL ) )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr, " Fatal error in %s: NULL pointer on buffer.\n", proc );
   return ( EXIT_ON_FAILURE );
  }

 /* 
  * May we use the buffer bufferOut as the bufferResult?
  * If its type is FLOAT or DOUBLE, then yes.
  * If not, we have to allocate an auxiliary buffer.
  */
 if ( ( typeOut == FLOAT ) || ( typeOut == DOUBLE ) )
  {
   bufferResult = bufferOut;
   typeResult = typeOut;
  }
 else
  {
   bufferResult = ( void * ) malloc ( ( dimx * dimy * dimz ) * sizeof ( r32 ) );
   if ( bufferResult == ( void * ) NULL )
    {
     if ( _VERBOSE_ > 0 )
      fprintf ( stderr,
		" Fatal error in %s: unable to allocate auxiliary buffer.\n",
		proc );
     return ( EXIT_ON_FAILURE );
    }
   typeResult = FLOAT;
  }

 /* 
  * May we consider the buffer bufferIn as the bufferToBeProcessed?
  * If its type is FLOAT or DOUBLE, then yes.
  * If not, we convert it into the buffer bufferResult, and this
  * last buffer is the bufferToBeProcessed.
  */
 if ( ( typeIn == FLOAT ) || ( typeIn == DOUBLE ) )
  {
   bufferToBeProcessed = bufferIn;
   typeToBeProcessed = typeIn;
  }
 else
  {
   ConvertBuffer ( bufferIn, typeIn, bufferResult, typeResult,
		   ( dimx * dimy * dimz ) );
   bufferToBeProcessed = bufferResult;
   typeToBeProcessed = typeResult;
  }

 /*
  * Estimation of the lines' length along each direction.
  */
 if ( borderLengths != NULL )
  {
   borderXlength = borderLengths[0];
   borderYlength = borderLengths[1];
   borderZlength = borderLengths[2];
   if ( borderXlength < 0 )
    borderXlength = 0;
   if ( borderYlength < 0 )
    borderYlength = 0;
   if ( borderZlength < 0 )
    borderZlength = 0;
  }

 /*
  * Tue Jul  6 19:15:15 MET DST 1999 (gregoire Malandain)
  * changes 3 x dimx -> dimx, dimy, dimz
  */
 lengthX = dimx + 2 * borderXlength;
 lengthY = dimy + 2 * borderYlength;
 lengthZ = dimz + 2 * borderZlength;
 maxLengthline = lengthX;
 if ( maxLengthline < lengthY )
  maxLengthline = lengthY;
 if ( maxLengthline < lengthZ )
  maxLengthline = lengthZ;
 if ( maxLengthline <= 0 )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr, " Error in %s: unable to deal with dimensions = 0.\n",
	      proc );
   if ( ( typeOut != FLOAT ) && ( typeOut != DOUBLE ) )
    free ( bufferResult );
   return ( EXIT_ON_FAILURE );
  }
 /*
  * Allocations of work arrays. 
  * We will use them to process each line.
  */
 theLine = ( double * ) malloc ( 3 * maxLengthline * sizeof ( double ) );
 if ( theLine == ( double * ) NULL )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr,
	      " Fatal error in %s: unable to allocate auxiliary work arrays.\n",
	      proc );
   if ( ( typeOut != FLOAT ) && ( typeOut != DOUBLE ) )
    free ( bufferResult );
   return ( EXIT_ON_FAILURE );
  }
 resLine = theLine + maxLengthline;
 tmpLine = resLine + maxLengthline;

 /*
  * From now,
  * typeToBeProcessed is either FLOAT or DOUBLE
  * so is typeResult.
  */

 /*
  * Processing along X.
  */
 if ( dimx > 4 )
  if ( derivatives[0] != NODERIVATIVE )
   if ( filterCoefs[0] > 0.0 )
    {
     if ( _VERBOSE_ != 0 )
      fprintf ( stderr, " %s: processing along X.\n", proc );
     InitRecursiveCoefficients ( ( double ) filterCoefs[0], filterType,
				 derivatives[0] );

     r64firstPoint = ( r64 * ) bufferToBeProcessed;
     r32firstPoint = ( r32 * ) bufferToBeProcessed;

     r64firstPointResult = ( r64 * ) bufferResult;
     r32firstPointResult = ( r32 * ) bufferResult;

     offsetLastPoint = borderXlength + dimx - 1;

     theLinePlusBorder = theLine + borderXlength;
     resLinePlusBorder = resLine + borderXlength;

     /*
      * There are dimz*dimy X lines to be processed.
      */
     for ( z = 0; z < dimz; z++ )
      for ( y = 0; y < dimy; y++ )
       {
	/*
	 * Acquiring a X line.
	 */
	dbl_pt1 = theLinePlusBorder;
	switch ( typeToBeProcessed )
	 {
	  case DOUBLE:
	   ( void ) memcpy ( ( void * ) dbl_pt1, ( void * ) r64firstPoint,
			     dimx * sizeof ( r64 ) );
	   r64firstPoint += dimx;
	   break;
	  case FLOAT:
	  default:
	   for ( x = 0; x < dimx; x++, dbl_pt1++, r32firstPoint++ )
	    *dbl_pt1 = *r32firstPoint;
	 }
	/*
	 * Adding points at both ends of the line.
	 */
	if ( borderXlength > 0 )
	 {
	  dbl_pt1 = theLine + borderXlength;
	  dbl_first = *dbl_pt1;
	  dbl_pt2 = theLine + offsetLastPoint;
	  dbl_last = *dbl_pt2;
	  for ( x = 0; x < borderXlength; x++ )
	   {
	    *--dbl_pt1 = dbl_first;
	    *++dbl_pt2 = dbl_last;
	   }
	 }
	/*
	 * Processing the line.
	 */
	if ( RecursiveFilter1D ( theLine, resLine, tmpLine, resLine, lengthX )
	     == 0 )
	 {
	  if ( _VERBOSE_ != 0 )
	   fprintf ( stderr,
		     " Error in %s: unable to process X line (y=%d,z=%d).\n",
		     proc, y, z );
	  if ( ( typeOut != FLOAT ) && ( typeOut != DOUBLE ) )
	   free ( bufferResult );
	  free ( ( void * ) theLine );
	  return ( EXIT_ON_FAILURE );
	 }
	/*
	 * Copy the result into the buffer bufferResult.
	 */
	dbl_pt1 = resLinePlusBorder;
	switch ( typeResult )
	 {
	  case DOUBLE:
	   ( void ) memcpy ( ( void * ) r64firstPointResult, ( void * ) dbl_pt1,
			     dimx * sizeof ( r64 ) );
	   r64firstPointResult += dimx;
	   break;
	  case FLOAT:
	  default:
	   for ( x = 0; x < dimx; x++, dbl_pt1++, r32firstPointResult++ )
	    *r32firstPointResult = ( r32 ) ( *dbl_pt1 );
	 }
       }

     /*
      * The next buffer to be processed is the buffer
      * bufferResult.
      */
     bufferToBeProcessed = bufferResult;
     typeToBeProcessed = typeResult;

    }				/* end of Processing along X. */

 /*
  * Processing along Y.
  */
 if ( dimy > 4 )
  if ( derivatives[1] != NODERIVATIVE )
   if ( filterCoefs[1] > 0.0 )
    {
     if ( _VERBOSE_ != 0 )
      fprintf ( stderr, " %s: processing along Y.\n", proc );
     InitRecursiveCoefficients ( ( double ) filterCoefs[1], filterType,
				 derivatives[1] );

     r64firstPoint = ( r64 * ) bufferToBeProcessed;
     r32firstPoint = ( r32 * ) bufferToBeProcessed;

     r64firstPointResult = ( r64 * ) bufferResult;
     r32firstPointResult = ( r32 * ) bufferResult;

     offsetLastPoint = borderYlength + dimy - 1;
     offsetNextFirstPoint = dimx * dimy - dimx;

     theLinePlusBorder = theLine + borderYlength;
     resLinePlusBorder = resLine + borderYlength;

     /*
      * There are dimz*dimx Y lines to be processed.
      */
     for ( z = 0; z < dimz; z++ )
      {
       for ( x = 0; x < dimx; x++ )
	{
	 /*
	  * Acquiring a Y line.
	  */
	 dbl_pt1 = theLinePlusBorder;
	 switch ( typeToBeProcessed )
	  {
	   case DOUBLE:
	    r64_pt = r64firstPoint;
	    for ( y = 0; y < dimy; y++, dbl_pt1++, r64_pt += dimx )
	     *dbl_pt1 = *r64_pt;
	    /*
	     * Going to the first point of the next Y line
	     */
	    r64firstPoint++;
	    break;
	   case FLOAT:
	   default:
	    r32_pt = r32firstPoint;
	    for ( y = 0; y < dimy; y++, dbl_pt1++, r32_pt += dimx )
	     *dbl_pt1 = *r32_pt;
	    r32firstPoint++;
	  }
	 /*
	  * Adding points at both ends of the line.
	  */
	 if ( borderYlength > 0 )
	  {
	   dbl_pt1 = theLine + borderYlength;
	   dbl_first = *dbl_pt1;
	   dbl_pt2 = theLine + offsetLastPoint;
	   dbl_last = *dbl_pt2;
	   for ( y = 0; y < borderYlength; y++ )
	    {
	     *--dbl_pt1 = dbl_first;
	     *++dbl_pt2 = dbl_last;
	    }
	  }
	 /*
	  * Processing the line.
	  */
	 if ( RecursiveFilter1D ( theLine, resLine, tmpLine, resLine, lengthY )
	      == 0 )
	  {
	   if ( _VERBOSE_ != 0 )
	    fprintf ( stderr,
		      " Error in %s: unable to process Y line (x=%d,z=%d).\n",
		      proc, x, z );
	   if ( ( typeOut != FLOAT ) && ( typeOut != DOUBLE ) )
	    free ( bufferResult );
	   free ( ( void * ) theLine );
	   return ( EXIT_ON_FAILURE );
	  }
	 /*
	  * Copy the result into the buffer bufferResult.
	  */
	 dbl_pt1 = resLinePlusBorder;
	 switch ( typeResult )
	  {
	   case DOUBLE:
	    r64_pt = r64firstPointResult;
	    for ( y = 0; y < dimy; y++, dbl_pt1++, r64_pt += dimx )
	     *r64_pt = *dbl_pt1;
	    r64firstPointResult++;
	    break;
	   case FLOAT:
	   default:
	    r32_pt = r32firstPointResult;
	    for ( y = 0; y < dimy; y++, dbl_pt1++, r32_pt += dimx )
	     *r32_pt = *dbl_pt1;
	    r32firstPointResult++;
	  }
	}
       /*
        * Going to the first point of the next Y line
        * which is the first Y line of the next slice.
        *
        * The pointer r[32,64]firstPoint[Result] has
        * already been increased by dimx. To reach
        * the first point of the next slice, we
        * have to increase it by (dimx*dimy)-dimx.
        */
       switch ( typeToBeProcessed )
	{
	 case DOUBLE:
	  r64firstPoint += offsetNextFirstPoint;
	  break;
	 case FLOAT:
	 default:
	  r32firstPoint += offsetNextFirstPoint;
	}
       switch ( typeResult )
	{
	 case DOUBLE:
	  r64firstPointResult += offsetNextFirstPoint;
	  break;
	 case FLOAT:
	 default:
	  r32firstPointResult += offsetNextFirstPoint;
	}
      }

     /*
      * The next buffer to be processed is the buffer
      * bufferResult.
      */
     bufferToBeProcessed = bufferResult;
     typeToBeProcessed = typeResult;

    }				/* end of Processing along Y. */

 /*
  * Processing along Z.
  */
 if ( dimz > 4 )
  if ( derivatives[2] != NODERIVATIVE )
   if ( filterCoefs[2] > 0.0 )
    {
     if ( _VERBOSE_ != 0 )
      fprintf ( stderr, " %s: processing along Z.\n", proc );
     InitRecursiveCoefficients ( ( double ) filterCoefs[2], filterType,
				 derivatives[2] );

     r64firstPoint = ( r64 * ) bufferToBeProcessed;
     r32firstPoint = ( r32 * ) bufferToBeProcessed;

     offsetLastPoint = borderZlength + dimz - 1;

     r64firstPointResult = ( r64 * ) bufferResult;
     r32firstPointResult = ( r32 * ) bufferResult;

     offsetLastPoint = borderZlength + dimz - 1;

     theLinePlusBorder = theLine + borderYlength;
     resLinePlusBorder = resLine + borderYlength;

     /*
      * There are dimy*dimx Z lines to be processed.
      */
     for ( y = 0; y < dimy; y++ )
      for ( x = 0; x < dimx; x++ )
       {
	/*
	 * Acquiring a Z line.
	 */
	dbl_pt1 = theLinePlusBorder;
	switch ( typeToBeProcessed )
	 {
	  case DOUBLE:
	   r64_pt = r64firstPoint;
	   for ( z = 0; z < dimz; z++, dbl_pt1++, r64_pt += dimxXdimy )
	    *dbl_pt1 = *r64_pt;
	   /*
	    * Going to the first point of the next Z line
	    */
	   r64firstPoint++;
	   break;
	  case FLOAT:
	  default:
	   r32_pt = r32firstPoint;
	   for ( z = 0; z < dimz; z++, dbl_pt1++, r32_pt += dimxXdimy )
	    *dbl_pt1 = *r32_pt;
	   r32firstPoint++;
	 }
	/*
	 * Adding points at both ends of the line.
	 */
	if ( borderZlength > 0 )
	 {
	  dbl_pt1 = theLine + borderZlength;
	  dbl_first = *dbl_pt1;
	  dbl_pt2 = theLine + offsetLastPoint;
	  dbl_last = *dbl_pt2;
	  for ( z = 0; z < borderZlength; z++ )
	   {
	    *--dbl_pt1 = dbl_first;
	    *++dbl_pt2 = dbl_last;
	   }
	 }
	/*
	 * Processing the line.
	 */
	if ( RecursiveFilter1D ( theLine, resLine, tmpLine, resLine, lengthZ )
	     == 0 )
	 {
	  if ( _VERBOSE_ != 0 )
	   fprintf ( stderr,
		     " Error in %s: unable to process Z line (x=%d,y=%d).\n",
		     proc, x, y );
	  if ( ( typeOut != FLOAT ) && ( typeOut != DOUBLE ) )
	   free ( bufferResult );
	  free ( ( void * ) theLine );
	  return ( EXIT_ON_FAILURE );
	 }

	/*
	 * Copy the result into the buffer bufferResult.
	 */
	dbl_pt1 = resLinePlusBorder;
	switch ( typeResult )
	 {
	  case DOUBLE:
	   r64_pt = r64firstPointResult;
	   for ( z = 0; z < dimz; z++, dbl_pt1++, r64_pt += dimxXdimy )
	    *r64_pt = *dbl_pt1;
	   r64firstPointResult++;
	   break;
	  case FLOAT:
	  default:
	   r32_pt = r32firstPointResult;
	   for ( z = 0; z < dimz; z++, dbl_pt1++, r32_pt += dimxXdimy )
	    *r32_pt = *dbl_pt1;
	   r32firstPointResult++;
	 }
       }
    }				/* end of Processing along Z. */

 /*
  * From bufferResult to bufferOut
  */
 ConvertBuffer ( bufferResult, typeResult, bufferOut, typeOut,
		 ( dimx * dimy * dimz ) );

 /*
  * Releasing the buffers.
  */
 if ( ( typeOut != FLOAT ) && ( typeOut != DOUBLE ) )
  free ( bufferResult );
 free ( ( void * ) theLine );

 return ( EXIT_ON_SUCCESS );
}

/*************************************************************************
 * extrema.c - tools for non-maxima gradient point suppression
 *
 * $Id: extrema.c,v 1.4 2000/11/30 16:19:08 greg Exp $
 *
 * Copyright�INRIA 1999
 *
 * DESCRIPTION: 
 *
 *
 * AUTHOR:
 * Gregoire Malandain (greg@sophia.inria.fr)
 * 
 * CREATION DATE: 
 * June, 9 1998
 *
 * Copyright Gregoire Malandain, INRIA
 *
 * ADDITIONS, CHANGES
 *
 */

/* 
 * epsilon value to select gradient extrema candidates
 */
static double _EPSILON_NORM_ = 0.5;

/*
 * epsilon value to decide of the interpolation type.
 * If one derivative's absolute value is larger than this
 * epsilon (close to one), then we use the nearest value
 * else we perform a [bi,tri]linear interpolation.
 */
static double _EPSILON_DERIVATIVE_ = 0.95;

/* Compute the gradient modulus in 2-D.
 *
 * gradient_modulus = sqrt (
 * derivative_along_X*derivative_along_X +
 * derivative_along_Y*derivative_along_Y ).
 */

static void
GradientModulus2D ( float *gradient_modulus,
		    float *derivative_along_X,
		    float *derivative_along_Y, int length )
{
 register int i;
 register float *norme = gradient_modulus;
 register float *gx = derivative_along_X;
 register float *gy = derivative_along_Y;

 for ( i = 0; i < length; i++, norme++, gx++, gy++ )
  *norme = sqrt ( ( *gx ) * ( *gx ) + ( *gy ) * ( *gy ) );
}

void
Remove_Gradient_NonMaxima_Slice_2D ( float *maxima,
				     float *gx,
				     float *gy, float *norme, int *bufferDims )
{
 /* 
  * the buffer norme[0] contains the gradient modulus of the 
  * previous slice, the buffer norme[1] the ones of the
  * slice under study, while norme[2] containes the ones
  * of the next slice.
  */
 /*
  * dimensions
  */
 register int dimx = bufferDims[0];
 int dimy = bufferDims[1];
 int dimxMinusOne = dimx - 1;
 int dimxPlusOne = dimx + 1;
 int dimyMinusOne = dimy - 1;

 /* 
  * pointers
  */
 register float *fl_pt1 = ( float * ) NULL;
 register float *fl_pt2 = ( float * ) NULL;
 register float *fl_max = ( float * ) NULL;
 register float *fl_nor = ( float * ) NULL;
 register float *fl_upper_left = ( float * ) NULL;

 /*
  * coordinates and vector's components
  */
 register int x, y;
 register double normalized_gx;
 register double normalized_gy;
 register double x_point_to_be_interpolated;
 register double y_point_to_be_interpolated;
 int x_upper_left_corner;
 int y_upper_left_corner;

 /*
  * coefficients
  */
 register double dx, dy, dxdy;
 double c00, c01, c10, c11;

 /*
  * modulus
  */
 double interpolated_norme;

 /*
  * we set the image border to zero.
  * First the borders along X direction,
  * second, the borders along the Y direction.
  */
 fl_pt1 = maxima;
 fl_pt2 = maxima + ( dimy - 1 ) * dimx;
 for ( x = 0; x < dimx; x++, fl_pt1++, fl_pt2++ )
  *fl_pt1 = *fl_pt2 = 0.0;
 fl_pt1 = maxima + dimx;
 fl_pt2 = maxima + dimx + dimx - 1;
 for ( y = 1; y < dimy - 1; y++, fl_pt1 += dimx, fl_pt2 += dimx )
  *fl_pt1 = *fl_pt2 = 0.0;

 /*
  * We investigate the middle of the image.
  */
 /* 
  * Pointers are set to the first point
  * to be processed.
  */
 fl_max = maxima + dimx + 1;
 fl_pt1 = gx + dimx + 1;
 fl_pt2 = gy + dimx + 1;
 fl_nor = norme + dimx + 1;
 for ( y = 1; y < dimyMinusOne;
       y++, fl_max += 2, fl_pt1 += 2, fl_pt2 += 2, fl_nor += 2 )
  for ( x = 1; x < dimxMinusOne; x++, fl_max++, fl_pt1++, fl_pt2++, fl_nor++ )
   {
    /*
     * If the modulus is too small, go to the next point.
     */
    if ( *fl_nor < _EPSILON_NORM_ )
     {
      *fl_max = 0.0;
      continue;
     }
    /*
     * We normalize the vector gradient.
     */
    normalized_gx = *fl_pt1 / *fl_nor;
    normalized_gy = *fl_pt2 / *fl_nor;

    /*
     * May we use the nearest value?
     */
    if ( ( -normalized_gx > _EPSILON_DERIVATIVE_ ) ||
	 ( normalized_gx > _EPSILON_DERIVATIVE_ ) ||
	 ( -normalized_gy > _EPSILON_DERIVATIVE_ ) ||
	 ( normalized_gy > _EPSILON_DERIVATIVE_ ) )
     {
      /*
       * First point to be interpolated.
       */
      x_upper_left_corner = ( int ) ( ( double ) x + normalized_gx + 0.5 );
      y_upper_left_corner = ( int ) ( ( double ) y + normalized_gy + 0.5 );
      interpolated_norme =
       *( norme + ( x_upper_left_corner + y_upper_left_corner * dimx ) );
      if ( *fl_nor <= interpolated_norme )
       {
	*fl_max = 0.0;
	continue;
       }
      /*
       * Second point to be interpolated.
       */
      x_upper_left_corner = ( int ) ( ( double ) x - normalized_gx + 0.5 );
      y_upper_left_corner = ( int ) ( ( double ) y - normalized_gy + 0.5 );
      interpolated_norme =
       *( norme + ( x_upper_left_corner + y_upper_left_corner * dimx ) );
      if ( *fl_nor < interpolated_norme )
       {
	*fl_max = 0.0;
	continue;
       }
      /*
       * We found a gradient extrema.
       */
      *fl_max = *fl_nor;
      continue;
     }

    /*
     * From here we perform a bilinear interpolation
     */

    /*
     * First point to be interpolated.
     * It is the current point + an unitary vector
     * in the direction of the gradient.
     * It must be inside the image.
     */
    x_point_to_be_interpolated = ( double ) x + normalized_gx;
    y_point_to_be_interpolated = ( double ) y + normalized_gy;
    if ( ( x_point_to_be_interpolated < 0.0 ) ||
	 ( x_point_to_be_interpolated >= dimxMinusOne ) ||
	 ( y_point_to_be_interpolated < 0.0 ) ||
	 ( y_point_to_be_interpolated >= dimyMinusOne ) )
     {
      *fl_max = 0.0;
      continue;
     }
    /* 
     * Upper left corner,
     * coordinates of the point to be interpolated
     * with respect to this corner.
     */
    x_upper_left_corner = ( int ) x_point_to_be_interpolated;
    y_upper_left_corner = ( int ) y_point_to_be_interpolated;
    dx = x_point_to_be_interpolated - ( double ) x_upper_left_corner;
    dy = y_point_to_be_interpolated - ( double ) y_upper_left_corner;
    dxdy = dx * dy;
    /* 
     * bilinear interpolation of the gradient modulus 
     * norme[x_point_to_be_interpolated, y_point_to_be_interpolated] =
     *   norme[0,0] * ( 1 - dx) * ( 1 - dy ) +
     *   norme[1,0] * ( dx ) * ( 1 - dy ) +
     *   norme[0,1] * ( 1 - dx ) * ( dy ) +
     *   norme[1,1] * ( dx ) * ( dy )
     */
    c00 = 1.0 - dx - dy + dxdy;
    c10 = dx - dxdy;
    c01 = dy - dxdy;
    c11 = dxdy;
    fl_upper_left =
     norme + ( x_upper_left_corner + y_upper_left_corner * dimx );
    interpolated_norme =
     *( fl_upper_left ) * c00 + *( fl_upper_left + 1 ) * c10 +
     *( fl_upper_left + dimx ) * c01 + *( fl_upper_left + dimxPlusOne ) * c11;
    /*
     * We compare the modulus of the point with the
     * interpolated modulus. It must be larger to be
     * still considered as a potential gradient extrema.
     *
     * Here, we consider that it is strictly superior.
     * The next comparison will be superior or equal.
     * This way, the extrema is in the light part of the
     * image. 
     * By inverting both tests, we can put it in the
     * dark side of the image.
     */
    if ( *fl_nor <= interpolated_norme )
     {
      *fl_max = 0.0;
      continue;
     }
    /*
     * Second point to be interpolated.
     * It is the current point - an unitary vector
     * in the direction of the gradient.
     * It must be inside the image.
     */
    x_point_to_be_interpolated = ( double ) x - normalized_gx;
    y_point_to_be_interpolated = ( double ) y - normalized_gy;
    if ( ( x_point_to_be_interpolated < 0.0 ) ||
	 ( x_point_to_be_interpolated >= dimxMinusOne ) ||
	 ( y_point_to_be_interpolated < 0.0 ) ||
	 ( y_point_to_be_interpolated >= dimyMinusOne ) )
     {
      *fl_max = 0.0;
      continue;
     }
    /* 
     * Upper left corner.
     */
    x_upper_left_corner = ( int ) x_point_to_be_interpolated;
    y_upper_left_corner = ( int ) y_point_to_be_interpolated;
    /* we do not recompute the coefficients
       dx = x_point_to_be_interpolated - (double)x_upper_left_corner;
       dy = y_point_to_be_interpolated - (double)y_upper_left_corner;
       dxdy = dx * dy;
     */
    /*
     * We may use the previous coefficients.
     * norme[x_point_to_be_interpolated, y_point_to_be_interpolated] =
     *   norme[0,0] * c11 +
     *   norme[1,0] * c01 +
     *   norme[0,1] * c10 +
     *   norme[1,1] * c00
     *
     * WARNING: it works only if the cases where one derivative is close
     *          to -/+ 1 are already be independently processed, else
     *          it may lead to errors.
     */
    /* we do not recompute the coefficients
       c00 = 1.0 - dx - dy + dxdy;
       c10 = dx - dxdy;
       c01 = dy - dxdy;
       c11 = dxdy;
       fl_upper_left = norme + (x_upper_left_corner + y_upper_left_corner * dimx);
       interpolated_norme = *(fl_upper_left) * c00 +
       *(fl_upper_left + 1) * c10 +
       *(fl_upper_left + dimx) * c01 +
       *(fl_upper_left + dimxPlusOne) * c11;
     */
    fl_upper_left =
     norme + ( x_upper_left_corner + y_upper_left_corner * dimx );
    interpolated_norme =
     *( fl_upper_left ) * c11 + *( fl_upper_left + 1 ) * c01 +
     *( fl_upper_left + dimx ) * c10 + *( fl_upper_left + dimxPlusOne ) * c00;
    /*
     * Last test to decide whether or not we 
     * have an extrema
     */
    if ( *fl_nor < interpolated_norme )
     {
      *fl_max = 0.0;
      continue;
     }
    /*
     * We found a gradient extrema.
     */
    *fl_max = *fl_nor;
   }
}

int
Extract_Gradient_Maxima_2D ( void *bufferIn,
			     bufferType typeIn,
			     void *bufferOut,
			     bufferType typeOut,
			     int *bufferDims,
			     int *borderLengths,
			     float *filterCoefs,
			     recursiveFilterType filterType )
{
 char *proc = "Extract_Gradient_Maxima_2D";

 /*
  * auxiliary buffer
  */
 float *tmpBuffer = ( float * ) NULL;

 /*
  * Pointers
  */
 float *gx = ( float * ) NULL;
 float *gy = ( float * ) NULL;
 float *norme = ( float * ) NULL;
 void *sliceIn = ( void * ) NULL;
 void *sliceOut = ( void * ) NULL;

 /*
  * additional parameters for recursive filtering
  */
 derivativeOrder Xgradient[3] = { DERIVATIVE_1_EDGES, SMOOTHING, NODERIVATIVE };
 derivativeOrder Ygradient[3] = { SMOOTHING, DERIVATIVE_1_EDGES, NODERIVATIVE };
 int sliceDims[3];

 /*
  *
  */
 int z, dimxXdimy;

 /* 
  * We check the buffers' dimensions.
  */
 if ( ( bufferDims[0] <= 0 ) || ( bufferDims[1] <= 0 ) ||
      ( bufferDims[2] <= 0 ) )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr, " Fatal error in %s: improper buffer's dimension.\n",
	      proc );
   return ( EXIT_ON_FAILURE );
  }
 dimxXdimy = bufferDims[0] * bufferDims[1];
 sliceDims[0] = bufferDims[0];
 sliceDims[1] = bufferDims[1];
 sliceDims[2] = 1;

 /*
  * test of the coefficients
  */
 if ( ( filterCoefs[0] < 0.0 ) || ( filterCoefs[1] < 0.0 ) )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr, " Error in %s: negative coefficient's value.\n", proc );
   return ( EXIT_ON_FAILURE );
  }

 /* 
  * Allocation of auxiliary buffer.
  * We need a slice buffer for each gradients' component
  * plus one for the modulus.
  */
 tmpBuffer = ( float * ) malloc ( 3 * dimxXdimy * sizeof ( float ) );
 if ( tmpBuffer == ( float * ) NULL )
  {
   if ( _VERBOSE_ > 0 )
    fprintf ( stderr,
	      " Fatal error in %s: unable to allocate auxiliary buffer.\n",
	      proc );
   return ( EXIT_ON_FAILURE );
  }
 norme = tmpBuffer;
 gy = norme + dimxXdimy;
 gx = gy + dimxXdimy;

 /* 
  * slice by slice processing.
  *
  * For each slice, we compute both the X and Y
  * components of the gradient, its modulus,
  * and we suppress the non-maxima of the
  * gradient. Finally, we put the result
  * in the buffer bufferOut.
  *
  * An other solution may consist in computing
  * the  X and Y components of the gradient
  * for the whole 3D buffer, and performing 
  * the non-maxima suppression slice 
  * by slice.
  */
 for ( z = 0; z < bufferDims[2]; z++ )
  {
   if ( ( _VERBOSE_ > 0 ) && ( bufferDims[2] > 1 ) )
    {
     fprintf ( stderr, " %s: Processing slice #%d.\n", proc, z );
    }
   sliceIn = ( void * ) NULL;
   /*
    * sliceIn points towards the slice #z of
    * the buffer bufferIn.
    */
   switch ( typeIn )
    {
     case UCHAR:
      sliceIn = ( ( ( u8 * ) bufferIn ) + z * dimxXdimy );
      break;
     case SCHAR:
      sliceIn = ( ( ( s8 * ) bufferIn ) + z * dimxXdimy );
      break;
     case USHORT:
      sliceIn = ( ( ( u16 * ) bufferIn ) + z * dimxXdimy );
      break;
     case SSHORT:
      sliceIn = ( ( ( s16 * ) bufferIn ) + z * dimxXdimy );
      break;
     case INT:
      sliceIn = ( ( ( i32 * ) bufferIn ) + z * dimxXdimy );
      break;
     case FLOAT:
      sliceIn = ( ( ( r32 * ) bufferIn ) + z * dimxXdimy );
      break;
     case DOUBLE:
      sliceIn = ( ( ( r64 * ) bufferIn ) + z * dimxXdimy );
      break;
     default:
      if ( _VERBOSE_ > 0 )
       fprintf ( stderr, " Error in %s: such input type not handled.\n", proc );
      free ( tmpBuffer );
      return ( EXIT_ON_FAILURE );
    }
   /*
    * computing the X and Y component
    * of the gradient.
    */
   if ( RecursiveFilterOnBuffer ( sliceIn, typeIn, gx, FLOAT,
				  sliceDims, borderLengths,
				  Xgradient, filterCoefs, filterType ) == 0 )
    {
     if ( _VERBOSE_ > 0 )
      {
       fprintf ( stderr, " Fatal error in %s:", proc );
       fprintf ( stderr, " unable to compute X gradient for slice #%d.\n", z );
      }
     free ( tmpBuffer );
     return ( EXIT_ON_FAILURE );
    }
   if ( RecursiveFilterOnBuffer ( sliceIn, typeIn, gy, FLOAT,
				  sliceDims, borderLengths,
				  Ygradient, filterCoefs, filterType ) == 0 )
    {
     if ( _VERBOSE_ > 0 )
      {
       fprintf ( stderr, " Fatal error in %s:", proc );
       fprintf ( stderr, " unable to compute Y gradient for slice #%d.\n", z );
      }
     free ( tmpBuffer );
     return ( EXIT_ON_FAILURE );
    }
   /*
    * Modulus of the gradient
    */
   GradientModulus2D ( norme, gx, gy, dimxXdimy );

   /*
    * Suppression of the non maxima of the gradient
    * in the direction of the gradient.
    *
    * If the type of the result buffer bufferOut is
    * FLOAT, then we compute directly the result
    * into the slice #z of the result buffer.
    * Else, we compute the suppression of the
    * non maxima into the gx buffer, and we 
    * convert it into the result buffer type.
    */
   if ( typeOut == FLOAT )
    {
     sliceOut = ( ( ( float * ) bufferOut ) + z * dimxXdimy );
     Remove_Gradient_NonMaxima_Slice_2D ( sliceOut, gx, gy, norme, sliceDims );
    }
   else
    {
     Remove_Gradient_NonMaxima_Slice_2D ( gx, gx, gy, norme, sliceDims );
     switch ( typeOut )
      {
       case UCHAR:
	sliceOut = ( ( ( u8 * ) bufferOut ) + z * dimxXdimy );
	break;
       case SCHAR:
	sliceOut = ( ( ( s8 * ) bufferOut ) + z * dimxXdimy );
	break;
       case USHORT:
	sliceOut = ( ( ( u16 * ) bufferOut ) + z * dimxXdimy );
	break;
       case SSHORT:
	sliceOut = ( ( ( s16 * ) bufferOut ) + z * dimxXdimy );
	break;
       case INT:
	sliceOut = ( ( ( i32 * ) bufferOut ) + z * dimxXdimy );
	break;
       case DOUBLE:
	sliceOut = ( ( ( r64 * ) bufferOut ) + z * dimxXdimy );
	break;
       default:
	if ( _VERBOSE_ > 0 )
	 fprintf ( stderr, " Error in %s: such output type not handled.\n",
		   proc );
	free ( tmpBuffer );
	return ( EXIT_ON_FAILURE );
      }
     ConvertBuffer ( gx, FLOAT, sliceOut, typeOut, dimxXdimy );
    }
  }

 free ( tmpBuffer );
 return ( EXIT_ON_SUCCESS );
}
