
/** 
 * @file bmp_header.c
 * Routines for reading/writing BMP headers
 */

#include <image.h>

static int read_short_le ( FILE * file_ptr, short *short_val );
static int read_long_le ( FILE * file_ptr, long *long_val );

static void write_short_le ( const short short_val, FILE * file_ptr );
static void write_long_le ( const long long_val, FILE * file_ptr );

/* read short ( little endian ) */

/* 
  fgetc return EOF in two cases: file read error or end-of-file  
  Therefore, this function returns a generic error code E_FAILURE 
 */

static int
read_short_le ( FILE * file_ptr, short *short_val )
{
 int one_byte;

 /* Initialize return value */
 *short_val = SHRT_MIN;

 one_byte = fgetc ( file_ptr );
 if ( one_byte == EOF )
  {
   return E_FAILURE;
  }

 *short_val = ( short ) one_byte;

 one_byte = fgetc ( file_ptr );
 if ( one_byte == EOF )
  {
   return E_FAILURE;
  }

 *short_val |= ( ( unsigned short ) one_byte ) << 8;

 return E_SUCCESS;
}

/* read long ( little endian ) */

/* 
  fgetc return EOF in two cases: file read error or end-of-file  
  Therefore, this function returns a generic error code E_FAILURE 
 */

static int
read_long_le ( FILE * file_ptr, long *long_val )
{
 int one_byte;

 /* Initialize return value */
 *long_val = LONG_MIN;

 one_byte = fgetc ( file_ptr );
 if ( one_byte == EOF )
  {
   return E_FAILURE;
  }

 *long_val = ( long ) one_byte;

 one_byte = fgetc ( file_ptr );
 if ( one_byte == EOF )
  {
   return E_FAILURE;
  }

 *long_val |= ( ( unsigned long ) one_byte ) << 8;

 one_byte = fgetc ( file_ptr );
 if ( one_byte == EOF )
  {
   return E_FAILURE;
  }

 *long_val |= ( ( unsigned long ) one_byte ) << 16;

 one_byte = fgetc ( file_ptr );
 if ( one_byte == EOF )
  {
   return E_FAILURE;
  }

 *long_val |= ( ( unsigned long ) one_byte ) << 24;

 return E_SUCCESS;
}

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Reads a BMP file header
 *
 * @param[in,out] file_ptr File pointer
 * @param[out] pix_type Pixel type
 * @param[out] num_rows # rows 
 * @param[out] num_cols # columns
 * @param[out] is_bottom_up Is the file stored bottom-up (true) or top-down (false)
 *
 * @return E_SUCCESS or an appropriate error code
 *
 * @note Only uncompressed BMP files with pixel depths 1, 8, or 24 are supported
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

int
read_bmp_header ( FILE * file_ptr, PixelType * pix_type, int *num_rows,
		  int *num_cols, Bool * is_bottom_up )
{
 short reserved;
 short num_planes;
 short bits_per_pix;
 long file_size;
 long offset;
 long header_size;
 long width;
 long height;
 long compression;

 /* Initialize the output parameters to impossible values */
 *pix_type = PIX_INVALID;
 *num_rows = INT_MIN;
 *num_cols = INT_MIN;

 if ( fgetc ( file_ptr ) != 'B' || fgetc ( file_ptr ) != 'M' )
  {
   /* Should not happen since the file 
      format is checked in the upper levels */
   return E_UNFMT;
  }

 if ( read_long_le ( file_ptr, &file_size ) )
  {
   return E_FAILURE;
  }

 if ( read_short_le ( file_ptr, &reserved ) )
  {
   return E_FAILURE;
  }

 if ( read_short_le ( file_ptr, &reserved ) )
  {
   return E_FAILURE;
  }

 if ( read_long_le ( file_ptr, &offset ) )
  {
   return E_FAILURE;
  }

 if ( read_long_le ( file_ptr, &header_size ) )
  {
   return E_FAILURE;
  }

 if ( header_size != 40 )
  {
   /* Unsupported BMP version */
   return E_UNIMPL;
  }

 if ( read_long_le ( file_ptr, &width ) )
  {
   return E_FAILURE;
  }
 *num_cols = ( int ) width;

 if ( read_long_le ( file_ptr, &height ) )
  {
   return E_FAILURE;
  }

 if ( height < 0 )
  {
   *num_rows = ( int ) -height;
   *is_bottom_up = false;
  }
 else
  {
   *num_rows = ( int ) height;
   *is_bottom_up = true;
  }

 if ( read_short_le ( file_ptr, &num_planes ) )
  {
   return E_FAILURE;
  }

 if ( read_short_le ( file_ptr, &bits_per_pix ) )
  {
   return E_FAILURE;
  }

 if ( bits_per_pix == 1 )
  {
   *pix_type = PIX_BIN;
  }
 else if ( bits_per_pix == 8 )
  {
   *pix_type = PIX_GRAY;
  }
 else if ( bits_per_pix == 24 )
  {
   *pix_type = PIX_RGB;
  }
 else
  {
   /* Cannot handle bpp <> 1, 8, or 24 */
   return E_INVBPP;
  }

 if ( read_long_le ( file_ptr, &compression ) )
  {
   return E_FAILURE;
  }

 if ( compression != 0 )
  {
   /* Cannot handle compression */
   return E_UNIMPL;
  }

 /* Seek to the beginning of pixel data */
 fseek ( file_ptr, offset, SEEK_SET );

 return E_SUCCESS;
}

/** @endcond INTERNAL_FUNCTION */

/* write short ( little endian ) */
static void
write_short_le ( const short short_val, FILE * file_ptr )
{
 fputc ( ( int ) ( ( ( ( unsigned short ) short_val ) >> 0 ) & 0xff ),
	 file_ptr );
 fputc ( ( int ) ( ( ( ( unsigned short ) short_val ) >> 8 ) & 0xff ),
	 file_ptr );
}

/* write long ( little endian ) */
static void
write_long_le ( const long long_val, FILE * file_ptr )
{
 fputc ( ( int ) ( ( ( ( unsigned long ) long_val ) >> 0 ) & 0xff ), file_ptr );
 fputc ( ( int ) ( ( ( ( unsigned long ) long_val ) >> 8 ) & 0xff ), file_ptr );
 fputc ( ( int ) ( ( ( ( unsigned long ) long_val ) >> 16 ) & 0xff ),
	 file_ptr );
 fputc ( ( int ) ( ( ( ( unsigned long ) long_val ) >> 24 ) & 0xff ),
	 file_ptr );
}

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Writes a BMP file header
 *
 * @param[in] pix_type Pixel type
 * @param[in] num_cols # columns
 * @param[in] num_rows # rows
 * @param[in,out] file_ptr File pointer
 *
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

void
write_bmp_header ( const PixelType pix_type, const int num_rows,
		   const int num_cols, FILE * file_ptr )
{
 short reserved;
 short bits_per_pix;
 short num_planes;
 int bytes_per_row;
 long file_size;
 long offset;
 long header_size;
 long compression;
 long image_size;
 long x_resolution;
 long y_resolution;
 long num_colors;
 long num_sig_colors;

 if ( pix_type == PIX_BIN )
  {
   /* header + color map (2 colors) */
   offset = 54 + 2 * 4;
   bytes_per_row = 4 * ( ( num_cols + 31 ) / 32 );
   file_size = offset + num_rows * bytes_per_row;
   bits_per_pix = 1;
   num_colors = 2;
  }
 else if ( pix_type == PIX_GRAY )
  {
   /* header + color map (256 colors) */
   offset = 54 + 256 * 4;
   bytes_per_row = num_cols + ( ( 4 - ( num_cols % 4 ) ) & 3 );
   file_size = offset + num_rows * bytes_per_row;
   bits_per_pix = 8;
   num_colors = 256;
  }
 else				/* PIX_RGB */
  {
   /* no color map */
   offset = 54;
   bytes_per_row = 3 * ( num_cols + ( ( 4 - ( ( num_cols * 3 ) % 4 ) ) & 3 ) );
   file_size = offset + num_rows * bytes_per_row;
   bits_per_pix = 24;
   num_colors = 0;
  }

 header_size = 40;
 reserved = 0;
 num_planes = 1;
 compression = 0;		/* uncompressed */
 image_size = 0;		/* valid when compression = 0 */
 x_resolution = 0;		/* ignore */
 y_resolution = 0;		/* ignore */
 num_sig_colors = 0;		/* all colors are significant */

 fputc ( 'B', file_ptr );	/* Magic number */
 fputc ( 'M', file_ptr );	/* Magic number */
 write_long_le ( file_size, file_ptr );
 write_short_le ( reserved, file_ptr );
 write_short_le ( reserved, file_ptr );
 write_long_le ( offset, file_ptr );
 write_long_le ( header_size, file_ptr );
 write_long_le ( ( long ) num_cols, file_ptr );
 write_long_le ( ( long ) num_rows, file_ptr );
 write_short_le ( num_planes, file_ptr );
 write_short_le ( bits_per_pix, file_ptr );
 write_long_le ( compression, file_ptr );
 write_long_le ( image_size, file_ptr );
 write_long_le ( x_resolution, file_ptr );
 write_long_le ( y_resolution, file_ptr );
 write_long_le ( num_colors, file_ptr );
 write_long_le ( num_sig_colors, file_ptr );
}

/** @endcond INTERNAL_FUNCTION */
