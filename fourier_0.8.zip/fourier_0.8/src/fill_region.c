
/** 
 * @file fill_region.c
 * Routines for filling the regions in a binary image
 */

#include <image.h>

static void
seed_fill ( const Box * box, const int new_val, const int seed_row,
	    const int seed_col, Image * img );

/** 
 * @brief Calculates the area of a bounding-box
 * 
 * @param[in] box Bounding-box pointer
 *
 * @return Area value or INT_MIN
 *
 * @author M. Emre Celebi
 * @date 07.24.2007
 */

int
calc_box_area ( const Box * box )
{
 SET_FUNC_NAME ( "calc_box_area" );

 if ( IS_NULL ( box ) )
  {
   ERROR_RET ( "Invalid bounding-box object !", INT_MIN );
  }

 return ( box->max_row - box->min_row + 1 ) *
  ( box->max_col - box->min_col + 1 );
}

/** 
 * @brief Returns the height of a bounding-box
 * 
 * @param[in] box Bounding-box pointer
 *
 * @return Height value or INT_MIN
 *
 * @author M. Emre Celebi
 * @date 07.24.2007
 */

int
get_box_height ( const Box * box )
{
 SET_FUNC_NAME ( "get_box_height" );

 if ( IS_NULL ( box ) )
  {
   ERROR_RET ( "Invalid bounding-box object !", INT_MIN );
  }

 return ( box->max_row - box->min_row + 1 );
}

/** 
 * @brief Returns the width of a bounding-box
 * 
 * @param[in] box Bounding-box pointer
 *
 * @return Width value or INT_MIN
 *
 * @author M. Emre Celebi
 * @date 07.24.2007
 */

int
get_box_width ( const Box * box )
{
 SET_FUNC_NAME ( "get_box_width" );

 if ( IS_NULL ( box ) )
  {
   ERROR_RET ( "Invalid bounding-box object !", INT_MIN );
  }

 return ( box->max_col - box->min_col + 1 );
}

/** 
 * @brief Allocates a bounding-box object
 * 
 * @return Pointer to the bounding-box or NULL
 * @see #free_box
 *
 * @author M. Emre Celebi
 * @date 07.24.2007
 */

Box *
alloc_box (  )
{
 Box *box = NULL;

 box = MALLOC_STRUCT ( Box );

 /* 
    Initialize the fields with illegal values.
    Note that the initial row and column spans
    both equal 1 - INT_MAX. Also, calc_box relies
    on these initializations. 
  */
 box->min_row = INT_MAX;
 box->max_row = 0;
 box->min_col = INT_MAX;
 box->max_col = 0;

 return box;
}

/** 
 * @brief Deallocates a bounding-box object
 *
 * @param[in,out] box Pointer to the bounding-box
 *
 * @return none
 * @see #alloc_box
 *
 * @author M. Emre Celebi
 * @date 07.24.2007
 */

void
free_box ( Box * box )
{
 if ( !IS_NULL ( box ) )
  {
   free ( box );
  }
}

/** @cond INTERNAL_MACRO */
#define CALC_BOX( )\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    if ( data[ir][ic] == label )\
     {\
      if ( ir < box->min_row ) { box->min_row = ir; }\
      if ( box->max_row < ir ) { box->max_row = ir; }\
      if ( ic < box->min_col ) { box->min_col = ic; }\
      if ( box->max_col < ic ) { box->max_col = ic; }\
     }\
   }\
 }\


/** @endcond INTERNAL_MACRO */

/** 
 * @brief Calculates the bounding-box of the object(s) in an image 
 * 
 * @param[in] img Image pointer { binary, label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the bounding-box or NULL
 *
 * @author M. Emre Celebi
 * @date 07.24.2007
 */

Box *
calc_box ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_box" );
 int ir, ic;
 int num_rows, num_cols;
 Box *box;

 if ( !is_bin_img ( img ) && !is_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 box = alloc_box (  );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_BOX (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_BOX (  );
  }

 if ( box->min_row == INT_MAX )
  {
   ERROR ( "No object pixel with label ( %d ) found !", label );
   return NULL;
  }

 return box;
}

#undef CALC_BOX

/*
  Filled horizontal segment of scanline y for xl <= x <= xr.
  Parent segment was on line y-dy. dy=1 or -1
 */

typedef struct
{
 int y, xl, xr, dy;
} Segment;

#define MAX_STACK 10000		/* Max depth of stack */

/** @cond INTERNAL_MACRO */

/* Push new segment on stack */
#define PUSH( Y, XL, XR, DY ) \
 if ( stack_ptr < stack + MAX_STACK && Y + ( DY ) >= box->min_row && Y + ( DY ) <= box->max_row ) \
  { stack_ptr->y = Y; stack_ptr->xl = XL; stack_ptr->xr = XR; stack_ptr->dy = DY; stack_ptr++; }

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */

/* Pop segment off stack */
#define POP( Y, XL, XR, DY ) \
 { stack_ptr--; Y = stack_ptr->y + ( DY = stack_ptr->dy ); XL = stack_ptr->xl; XR = stack_ptr->xr; }

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_FUNCTION */

#define SEED_FILL( skip_label )\
old_val = data[y][x];\
\
if ( old_val == new_val || x < box->min_col || x > box->max_col || y < box->min_row || y > box->max_row )\
 { return; }\
PUSH ( y, x, x, 1 ); /* Needed in some cases */\
PUSH ( y + 1, x, x, -1 ); /* Seed segment (popped 1st) */\
while ( stack_ptr > stack )\
 {\
  /* Pop segment off stack and fill a neighboring scan line */\
  POP ( y, x1, x2, dy );\
  /* Segment of scan line y-dy for x1<=x<=x2 was previously filled.
     Now explore adjacent pixels in scan line y. */\
  for ( x = x1; x >= box->min_col && data[y][x] == old_val; x-- ) { data[y][x] = new_val; }\
  if ( x >= x1 ) { goto skip_label; }\
  l = x + 1;\
  if ( l < x1 )	/* Leak on left? */ { PUSH ( y, l, x1 - 1, -dy ); }\
  x = x1 + 1;\
  do \
   {\
    while ( x <= box->max_col && data[y][x] == old_val )\
     {\
      data[y][x] = new_val;\
      x++;\
     }\
    PUSH ( y, l, x - 1, dy );\
    if ( x > x2 + 1 ) /* Leak on right? */ { PUSH ( y, x2 + 1, x - 1, -dy ); }\
    \
    skip_label:\
     for ( x++; x <= x2 && data[y][x] != old_val; x++ ) { /* Empty body */ ; }\
     l = x;\
   }\
  while ( x <= x2 );\
 }\


/*
  Set the pixel at ( seed_row, seed_col ) and all of its 4-connected neighbors
  with the same pixel value to the new pixel value NEW_VAL.
 */

static void
seed_fill ( const Box * box, const int new_val, const int seed_row,
	    const int seed_col, Image * img )
{
 SET_FUNC_NAME ( "seed_fill" );
 int x, y;
 int l, x1, x2, dy;
 int old_val;			/* old pixel value */
 Segment *stack;		/* stack data */
 Segment *stack_ptr;		/* stack pointer */

 if ( IS_NULL ( box ) )
  {
   ERROR ( "Invalid bounding-box object !" );
  }

 x = seed_col;
 y = seed_row;

 stack = ( Segment * ) malloc ( MAX_STACK * sizeof ( Segment ) );
 stack_ptr = stack;

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   SEED_FILL ( byte_label );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   SEED_FILL ( int_label );
  }

 free ( stack );
}

/** @endcond INTERNAL_FUNCTION */

#undef MAX_STACK
#undef PUSH
#undef POP
#undef SEED_FILL

/** 
 * @brief Implements Heckbert's 4-connected seed-fill algorithm 
 * 
 * @param[in] seed_row Row coordinate of the seed pixel { non-negative }
 * @param[in] seed_col Column coordinate of the seed pixel { non-negative }
 * @param[in] label Label of the object { positive }
 * @param[in,out] img Image pointer { binary }
 *
 * @note This routine modifies the input image !
 * @return none
 *
 * @ref Heckbert P. (1990) "A Seed Fill Algorithm" in Graphics Gems, Academic Press
 *      http://www.acm.org/tog/GraphicsGems/gems/SeedFill.c
 *
 * @author Paul Heckbert
 * @date 07.24.2007
 */

void
fill_region ( const int seed_row, const int seed_col, const int label,
	      Image * img )
{
 SET_FUNC_NAME ( "fill_region" );

 if ( ( seed_row < 0 ) || ( seed_col < 0 ) )
  {
   ERROR ( "Seed pixel coordinates ( %d, %d ) must be non-negative !",
	   seed_row, seed_col );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
  }

 if ( !is_bin_img ( img ) && !is_label_img ( img ) )
  {
   ERROR ( "Not a binary or label image !" );
  }

 seed_fill ( calc_box ( img, label ), label, seed_row, seed_col, img );
}
