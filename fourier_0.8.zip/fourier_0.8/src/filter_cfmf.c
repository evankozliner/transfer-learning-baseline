
/** 
 * @file filter_cfmf.c
 * Routines for CFMF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the CFMF (Combined Fuzzy Metric Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] C_value Parameter of the fuzzy metric { positive }
 * @param[in] t_value Parameter of the fuzzy metric { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco The authors recommend C_VALUE = 50..250 and T_VALUE = 4
 *
 * @ref 1) Morillas S., Gregori V., Peris-Fajarnes G., and Sapena A. (2007) 
 *         "New Adaptive Vector Filter Using Fuzzy Metrics" Journal of Electronic 
 *         Imaging, 16(3): 033007
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 05.02.2008
 */

Image *
filter_cfmf ( const Image * in_img, const int win_size, const double C_value,
	      const double t_value )
{
 SET_FUNC_NAME ( "filter_cfmf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int max_sim_index;
 int *red, *green, *blue;
 int *row, *col;
 double max_sim;
 double sim_sum;
 double **sim_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( !IS_POS ( C_value ) )
  {
   ERROR ( "C ( %f ) must be positive !", C_value );
   return NULL;
  }

 if ( !IS_POS ( t_value ) )
  {
   ERROR ( "t ( %f ) must be positive !", t_value );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 row = ( int * ) malloc ( win_count * sizeof ( int ) );
 col = ( int * ) malloc ( win_count * sizeof ( int ) );

 sim_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];

	 /* 
	    Store the Cartesian coordinates of the vector. 
	    Note that we only need the relative coordinates 
	    of the pixel to calculate the L_max difference.
	  */

	 row[count] = iwr /* - wr_begin */ ;
	 col[count] = iwc /* - wc_begin */ ;
	 count++;
	}
      }

     /* Calculate the combined fuzzy similarity between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 sim_mat[iwr][iwc] =
	  ( C_value /
	    ( C_value +
	      L2_DIST_3D ( red[iwr], green[iwr], blue[iwr], red[iwc],
			   green[iwc],
			   blue[iwc] ) ) ) * ( t_value / ( t_value +
							   MAX_2 ( abs
								   ( row[iwr] -
								     row[iwc] ),
								   abs ( col
									 [iwr] -
									 col
									 [iwc] ) ) ) );
	}
      }

     /* Calculate the row sums and find the maximum one */
     max_sim = DBL_MIN;
     max_sim_index = center_pix;
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       sim_sum = 0.0;

       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 sim_sum += sim_mat[iwc][iwr];
	}

       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 sim_sum += sim_mat[iwr][iwc];
	}

       if ( max_sim < sim_sum )
	{
	 max_sim = sim_sum;
	 max_sim_index = iwr;
	}
      }

     out_data[ir][ic][0] = red[max_sim_index];
     out_data[ir][ic][1] = green[max_sim_index];
     out_data[ir][ic][2] = blue[max_sim_index];

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( row );
 free ( col );
 free_nd ( sim_mat, 2 );

 return out_img;
}
