
/** 
 * @file filter_perona_malik.c
 * Routines for Perona-Malik filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Perona-Malik Anisotropic Diffusion filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] k_value K parameter of the edge-stopping function { non-zero }
 * @param[in] lambda Diffusion rate { [0.0, 0.25] }
 * @param[in] num_iters Number of iterations { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Perona P. and Malik J. (1990) "Scale-Space and Edge Detection Using 
 *      Anisotropic Diffusion" IEEE Trans. on Pattern Analysis and Machine 
 *      Intelligence, 12(7): 629-639
 *
 * @author M. Emre Celebi
 * @date 02.09.2008
 */

Image *
filter_perona_malik ( const Image * in_img, const double k_value,
		      const double lambda, const int num_iters )
{
 SET_FUNC_NAME ( "filter_perona_malik" );
 int num_rows, num_cols;
 int ik, ir, ic;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 double center_val;
 double del_west, del_north, del_east, del_south;
 double term;
 double conv_sum;
 double **in_data;
 double **out_data;
 Image *in_dbl_img;
 Image *out_dbl_img;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( IS_ZERO ( k_value ) )
  {
   ERROR_RET ( "k_value must be non-zero !", NULL );
  }

 if ( lambda < 0.0 || lambda > 0.25 )
  {
   ERROR ( "Lambda ( %f ) must be in [0.0, 0.25] !", lambda );
   return NULL;
  }

 if ( num_iters <= 0 )
  {
   ERROR ( "Number of iterations ( %d ) must be positive !", num_iters );
   return NULL;
  }

 term = 1.0 / ( k_value * k_value );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 /* Convert the input image to double type */
 in_dbl_img = byte_to_dbl_img ( in_img );
 in_data = get_img_data_nd ( in_dbl_img );

 out_dbl_img = alloc_img ( PIX_DBL_1B, num_rows, num_cols );
 if ( IS_NULL ( out_dbl_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_dbl_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = 1;
 r_end = num_rows - 1;
 c_begin = 1;
 c_end = num_cols - 1;

 for ( ik = 0; ik < num_iters; ik++ )
  {
   for ( ir = r_begin; ir < r_end; ir++ )
    {
     for ( ic = c_begin; ic < c_end; ic++ )
      {
       conv_sum = 0.0;
       center_val = in_data[ir][ic];

       /* 4-nearest-neighbor discretization of the Laplacian operator */

       del_west = in_data[ir][ic - 1] - center_val;
       del_north = in_data[ir - 1][ic] - center_val;
       del_east = in_data[ir][ic + 1] - center_val;
       del_south = in_data[ir + 1][ic] - center_val;

       out_data[ir][ic] = center_val +
	lambda * ( ( del_west / ( 1.0 + term * del_west * del_west ) ) +
		   ( del_north / ( 1.0 + term * del_north * del_north ) ) +
		   ( del_east / ( 1.0 + term * del_east * del_east ) ) +
		   ( del_south / ( 1.0 + term * del_south * del_south ) ) );

       /*
          out_data[ir][ic] = center_val + 
          lambda * ( ( exp ( -term * del_west * del_west ) * del_west ) +
          ( exp ( -term * del_north * del_north ) * del_north ) +
          ( exp ( -term * del_east * del_east ) * del_east ) +
          ( exp ( -term * del_south * del_south ) * del_south ) );
        */
      }
    }

   /* Assign the output of current iteration to the input of next iteration */
   in_data = out_data;
  }

 /* Convert the output image to byte type */
 out_img = dbl_to_byte_img ( out_dbl_img );

 free_img ( in_dbl_img );
 free_img ( out_dbl_img );

 return out_img;
}
