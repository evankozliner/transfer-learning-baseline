
/** 
 * @file filter_fvdrhf.c
 * Routines for FVDRHF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the FVDRHF (Fuzzy Vector Directional-Rational Hybrid Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] weight Center pixel weight { positive }
 * @param[in] h_value Ensures numerical stability in the rational filter { positive }
 * @param[in] k_value Regulates the nonlinearity of the rational filter { positive }
 * @param[in] beta Controls the fuzziness of the weights
 * @param[in] gamma Controls the fuzziness of the weights
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco The authors recommend WEIGHT = H_VALUE = K_VALUE = 3.0, BETA = 2.0, and GAMMA = 1.0
 *
 * @ref 1) Khriji L. and Gabbouj M. (2002) "Adaptive Fuzzy Order Statistics-Rational 
 *         Hybrid Filters for Color Image Processing" Fuzzy Sets and Systems, 128(1): 35-46
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
filter_fvdrhf ( const Image * in_img, const double weight,
		const double h_value, const double k_value,
		const double beta, const double gamma )
{
 SET_FUNC_NAME ( "filter_fvdrhf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 const int win_size = 3;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int index1, index3;
 int valid1[5], valid3[5];
 int *red, *green, *blue;
 double weight_m1;
 double acos_arg;
 double angle;
 double dot_prod;
 double red_numer, green_numer, blue_numer;
 double denom;
 double angle_sum[4];
 double weight_sum[4];
 double red_FVDF[4], green_FVDF[4], blue_FVDF[4];
 double alpha[3];
 double *vec_len;
 double *weight1, *weight2, *weight3;
 double **angle_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS ( weight ) )
  {
   ERROR ( "Weight ( %f ) must be positive !", weight );
   return NULL;
  }

 if ( !IS_POS ( h_value ) )
  {
   ERROR ( "H ( %f ) must be positive !", h_value );
   return NULL;
  }

 if ( !IS_POS ( k_value ) )
  {
   ERROR ( "K ( %f ) must be positive !", k_value );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;
 weight_m1 = weight - 1.0;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 vec_len = ( double * ) malloc ( win_count * sizeof ( double ) );
 weight1 = ( double * ) malloc ( win_count * sizeof ( double ) );
 weight2 = ( double * ) malloc ( win_count * sizeof ( double ) );
 weight3 = ( double * ) malloc ( win_count * sizeof ( double ) );

 angle_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* In sub-filter 1 only pixels {1, 3, 4, 5, 7} are valid */
 valid1[0] = 1;
 valid1[1] = 3;
 valid1[2] = 4;
 valid1[3] = 5;
 valid1[4] = 7;

 /* In sub-filter 3 only pixels {0, 2, 4, 6, 8} are valid */
 valid3[0] = 0;
 valid3[1] = 2;
 valid3[2] = 4;
 valid3[3] = 6;
 valid3[4] = 8;

 alpha[1] = alpha[3] = 1.0;
 alpha[2] = -2.0;

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the vector lengths */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       vec_len[iwr] = L2_NORM_3D ( red[iwr], blue[iwr], green[iwr] );
      }

     /* Calculate the angles between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   if ( vec_len[iwc] > 0.0 )
	    {
	     /* ( dot product ) / ( || vector1 || * || vector2 || ) */
	     acos_arg =
	      ( red[iwr] * red[iwc] + green[iwr] * green[iwc] +
		blue[iwr] * blue[iwc] ) / ( vec_len[iwr] * vec_len[iwc] );

	     /* Calculate the angle between the two color vectors */
	     angle_mat[iwr][iwc] = ACOS ( acos_arg );
	    }
	   else
	    {
	     /* Idempotent value */
	     angle_mat[iwr][iwc] = 0.0;
	    }
	  }
	}
      }

     /* Determine the weights for sub-filter 2 (FCWVMF) */

     weight_sum[2] = 0.0;
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 angle_sum[2] = 0.0;

	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   angle_sum[2] += angle_mat[iwc][iwr];
	  }

	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   angle_sum[2] += angle_mat[iwr][iwc];
	  }

	 if ( iwr < center_pix )
	  {
	   angle_sum[2] += weight_m1 * angle_mat[iwr][center_pix];
	  }
	 else
	  {
	   angle_sum[2] += weight_m1 * angle_mat[center_pix][iwr];
	  }

	 weight2[iwr] = beta / ( 1.0 + exp ( pow ( angle_sum[2], gamma ) ) );
	 weight_sum[2] += weight2[iwr];
	}
       else
	{
	 weight2[iwr] = 0.0;
	}
      }

     /* Determine the weights for the sub-filters 1 and 3 (FVDF) */

     weight_sum[1] = weight_sum[3] = 0.0;
     for ( iwr = 0; iwr <= center_pix; iwr++ )
      {
       angle_sum[1] = angle_sum[3] = 0.0;

       index1 = valid1[iwr];

       if ( vec_len[index1] > 0.0 )
	{
	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   angle_sum[1] += angle_mat[valid1[iwc]][index1];
	  }

	 for ( iwc = iwr + 1; iwc <= center_pix; iwc++ )
	  {
	   angle_sum[1] += angle_mat[index1][valid1[iwc]];
	  }

	 weight1[index1] = beta / ( 1.0 + exp ( pow ( angle_sum[1], gamma ) ) );
	 weight_sum[1] += weight1[index1];
	}
       else
	{
	 weight1[index1] = 0.0;
	}

       index3 = valid3[iwr];

       if ( vec_len[index3] > 0.0 )
	{
	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   angle_sum[3] += angle_mat[valid3[iwc]][index3];
	  }

	 for ( iwc = iwr + 1; iwc <= center_pix; iwc++ )
	  {
	   angle_sum[3] += angle_mat[index3][valid3[iwc]];
	  }

	 weight3[index3] = beta / ( 1.0 + exp ( pow ( angle_sum[3], gamma ) ) );
	 weight_sum[3] += weight3[index3];
	}
       else
	{
	 weight3[index3] = 0.0;
	}
      }

     /* Reset the output of sub-filter 2 */
     red_FVDF[2] = green_FVDF[2] = blue_FVDF[2] = 0.0;

     if ( weight_sum[2] > 0.0 )
      {
       for ( iwr = 0; iwr < win_count; iwr++ )
	{
	 weight2[iwr] /= weight_sum[2];	/* Normalize the fuzzy weight */

	 red_FVDF[2] += weight2[iwr] * red[iwr];
	 green_FVDF[2] += weight2[iwr] * green[iwr];
	 blue_FVDF[2] += weight2[iwr] * blue[iwr];
	}
      }

     /* Reset the output of sub-filter 1 */
     red_FVDF[1] = green_FVDF[1] = blue_FVDF[1] = 0.0;

     if ( weight_sum[1] > 0.0 )
      {
       for ( iwr = 0; iwr <= center_pix; iwr++ )
	{
	 index1 = valid1[iwr];

	 weight1[index1] /= weight_sum[1];	/* Normalize the fuzzy weight */

	 red_FVDF[1] += weight1[index1] * red[index1];
	 green_FVDF[1] += weight1[index1] * green[index1];
	 blue_FVDF[1] += weight1[index1] * blue[index1];
	}
      }

     /* Reset the output of sub-filter 3 */
     red_FVDF[3] = green_FVDF[3] = blue_FVDF[3] = 0.0;

     if ( weight_sum[3] > 0.0 )
      {
       for ( iwr = 0; iwr <= center_pix; iwr++ )
	{
	 index3 = valid3[iwr];

	 weight3[index3] /= weight_sum[3];	/* Normalize the fuzzy weight */

	 red_FVDF[3] += weight3[index3] * red[index3];
	 green_FVDF[3] += weight3[index3] * green[index3];
	 blue_FVDF[3] += weight3[index3] * blue[index3];
	}
      }

     /* Equation 8 */
     red_numer =
      alpha[1] * red_FVDF[1] + alpha[2] * red_FVDF[2] + alpha[3] * red_FVDF[3];
     green_numer =
      alpha[1] * green_FVDF[1] + alpha[2] * green_FVDF[2] +
      alpha[3] * green_FVDF[3];
     blue_numer =
      alpha[1] * blue_FVDF[1] + alpha[2] * blue_FVDF[2] +
      alpha[3] * blue_FVDF[3];

     dot_prod =
      red_FVDF[1] * red_FVDF[3] + green_FVDF[1] * green_FVDF[3] +
      blue_FVDF[1] * blue_FVDF[3];
     denom = h_value;
     if ( dot_prod > 0.0 )
      {
       acos_arg =
	dot_prod / ( L2_NORM_3D ( red_FVDF[1], green_FVDF[1], blue_FVDF[1] ) *
		     L2_NORM_3D ( red_FVDF[3], green_FVDF[3], blue_FVDF[3] ) );
       angle = ACOS ( acos_arg );
       denom += k_value * angle;
      }

     /* Output */
     out_data[ir][ic][0] = red_FVDF[2] + red_numer / denom + .5;	/* round */
     out_data[ir][ic][1] = green_FVDF[2] + green_numer / denom + .5;	/* round */
     out_data[ir][ic][2] = blue_FVDF[2] + blue_numer / denom + .5;	/* round */

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( vec_len );
 free ( weight1 );
 free ( weight2 );
 free ( weight3 );
 free_nd ( angle_mat, 2 );

 return out_img;
}
