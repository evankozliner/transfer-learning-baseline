
/** 
 * @file filter_mad.c
 * Routines for Adaptive MAD-based filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Adaptive MAD-based filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] a_value a parameter of the method { positive }
 * @param[in] b_value b parameter of the method { a_value < }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco Crnojevic recommends A_VALUE in [10,30] and B_VALUE in [60,90]
 *
 * @ref Crnojevic V. (2005) "Impulse Noise Filter with Adaptive Mad-Based Threshold"
 *      Proc. of the IEEE Int. Conf. on Image Processing, 3: 337-340
 *
 * @author M. Emre Celebi
 * @date 07.14.2007
 */

Image *
filter_mad ( const Image * in_img, const int win_size, const int a_value,
	     const int b_value )
{
 SET_FUNC_NAME ( "filter_mad" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int ik;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int center_val;
 int center_dev;
 int local_med;
 int local_mad;
 int threshold;
 int *win_data;			/* stores the pixels in a particular window position */
 double term;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( a_value <= 0 )
  {
   ERROR ( "a_value ( %d ) must be positive !", a_value );
   return NULL;
  }

 if ( b_value <= a_value )
  {
   ERROR ( "b_value ( %d ) must be positive and greater than ( %d ) !", b_value,
	   a_value );
   return NULL;
  }

 /* Precompute the constant term in Equation (7) */
 term = ( b_value - a_value ) / ( double ) b_value;

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 win_data = ( int * ) calloc ( win_count, sizeof ( int ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 win_data[count++] = in_data[iwr][iwc];
	}
      }

     /* Save the center pixel value */
     center_val = win_data[center_pix];

     /* Determine the local median */
     local_med = find_median ( win_count, win_data );

     /* 
        Calculate and store the median absolute 
        deviation of each pixel: Equation (3) 
      */
     for ( ik = 0; ik < win_count; ik++ )
      {
       win_data[ik] = abs ( win_data[ik] - local_med );
      }

     /* 
        Since find_median ( ) modifies the input array, we need to 
        compute the absolute deviation of the center pixel again.
      */
     center_dev = abs ( center_val - local_med );

     /* Determine the local mad ( median absolute deviation ): Equation (6) */
     local_mad = find_median ( win_count, win_data );

     /* Determine the switching threshold: Equation (7) */
     threshold = ( local_mad >= b_value ) ? a_value
      : ( a_value + term * local_mad );

     /* Determine the output pixel value */
     out_data[ir][ic] = ( center_dev >= threshold ) ? local_med : center_val;

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}
