
/** 
 * @file filter_lum.c
 * Routines for LUM filtering of a grayscale image
 */

#include <image.h>

#define MEDIAN_OF_THREE( A, B, C )\
 ( ( ( A ) <= ( B ) ) ? ( ( ( B ) <= ( C ) ) ? ( B ) : ( ( ( A ) <= ( C ) ) ? ( C ) : ( A ) ) ) :\
                        ( ( ( A ) <= ( C ) ) ? ( A ) : ( ( ( B ) <= ( C ) ) ? ( C ) : ( B ) ) ) )\


/** 
 * @brief Implements the LUM (Lower-Upper-Middle) filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] k_value K parameter of the filter { [1, WIN_SIZE^2 / 2] }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Hardie R.C. and Boncelet C.G. (1993) "LUM Filters: A Class of 
 *      Rank-Order-Based Filters for Smoothing and Sharpening" IEEE 
 *      Trans. on Signal Processing, 41(3): 1061-1076
 *
 * @author M. Emre Celebi
 * @date 02.09.2008
 */

Image *
filter_lum ( const Image * in_img, const int win_size, const int k_value )
{
 SET_FUNC_NAME ( "filter_lum" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;
 int index_middle;
 int index_upper;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int lower, middle, upper;
 int *win_data;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( k_value == ( win_size * win_size ) / 2 )	/* Median filter */
  {
   return filter_running_median ( in_img, win_size );
  }
 else if ( ( k_value <= 0 ) || ( k_value > ( win_size * win_size ) / 2 ) )
  {
   ERROR ( "K value ( %d ) must be in [1, %d] !", k_value,
	   ( win_size * win_size ) / 2 );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;
 index_middle = win_count / 2;
 index_upper = win_count - k_value - 1;

 win_data = ( int * ) calloc ( win_count, sizeof ( int ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 win_data[count++] = in_data[iwr][iwc];
	}
      }

     /* Original center pixel */
     middle = win_data[index_middle];

     /* Sort the window */
     sort_int ( win_count, win_data );

     /* Lower and upper statistics */
     lower = win_data[k_value];
     upper = win_data[index_upper];

     /* Assign the median of the three statistics to the output pixel */
     out_data[ir][ic] = MEDIAN_OF_THREE ( lower, middle, upper );

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}

#undef MEDIAN_OF_THREE
