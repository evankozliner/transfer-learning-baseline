
/** 
 * @file arith.c
 * Routines for arithmetic operations on images
 */

#include <image.h>

#define INIT_ARITH( FUNC_NAME )\
 SET_FUNC_NAME ( FUNC_NAME );\
 byte *in_data_a;\
 byte *in_data_b;\
 byte *out_data;\
 int ik;\
 int num_rows, num_cols;\
 int num_elems;\
 int value;\
 Image *out_img;\
 \
 if ( !img_dims_agree ( in_img_a, in_img_b ) )\
  {\
   ERROR_RET ( "Image dimensions must agree !", NULL );\
  }\
 \
 if ( !img_types_agree ( in_img_a, in_img_b ) )\
  {\
   ERROR_RET ( "Image types must agree !", NULL );\
  }\
 \
 if ( !is_byte_img ( in_img_a ) )\
  {\
   ERROR_RET ( "Images must be of byte type !", NULL );\
  }\
 \
 num_rows = get_num_rows ( in_img_a );\
 num_cols = get_num_cols ( in_img_a );\
 num_elems = get_num_bands ( in_img_a ) * num_rows * num_cols;\
 \
 in_data_a = get_img_data_1d ( in_img_a );\
 in_data_b = get_img_data_1d ( in_img_b );\
 \
 out_img = alloc_img ( get_pix_type ( in_img_a ), num_rows, num_cols );\
 if ( IS_NULL ( out_img ) )\
  {\
   ERROR_RET ( "Insufficient memory !", NULL );\
  }\
 out_data = get_img_data_1d ( out_img );\


/** 
 * @brief Adds two images
 *
 * @param[in] in_img_a Image #1 { byte }
 * @param[in] in_img_b Image #2 { byte }
 *
 * @return Pointer to the resulting image or NULL
 *
 * @note If the value of an output pixel becomes greater 
 *       than MAX_GRAY, it is set to MAX_GRAY.
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
add_img ( const Image * in_img_a, const Image * in_img_b )
{
 INIT_ARITH ( "add_img" );

 for ( ik = 0; ik < num_elems; ik++ )
  {
   value = in_data_a[ik] + in_data_b[ik];

   /* Prevent overflow by setting the output value to MAX_GRAY */
   out_data[ik] = value > MAX_GRAY ? MAX_GRAY : value;
  }

 return out_img;
}

/** 
 * @brief Subtracts two images
 *
 * @param[in] in_img_a Image #1 { byte }
 * @param[in] in_img_b Image #2 { byte }
 *
 * @return Pointer to the resulting image or NULL
 *
 * @note If the value of an output pixel becomes negative,
 *       it is set to 0.
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
sub_img ( const Image * in_img_a, const Image * in_img_b )
{
 INIT_ARITH ( "sub_img" );

 for ( ik = 0; ik < num_elems; ik++ )
  {
   value = in_data_a[ik] - in_data_b[ik];

   /* Prevent underflow by setting the output value to 0 */
   out_data[ik] = value < 0 ? 0 : value;
  }

 return out_img;
}

/** 
 * @brief Multiplies two images
 *
 * @param[in] in_img_a Image #1 { byte }
 * @param[in] in_img_b Image #2 { byte }
 *
 * @return Pointer to the resulting image or NULL
 *
 * @note If the value of an output pixel becomes greater 
 *       than MAX_GRAY, it is set to MAX_GRAY.
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
mult_img ( const Image * in_img_a, const Image * in_img_b )
{
 INIT_ARITH ( "mult_img" );

 for ( ik = 0; ik < num_elems; ik++ )
  {
   value = in_data_a[ik] * in_data_b[ik];

   /* Prevent overflow by setting the output value to MAX_GRAY */
   out_data[ik] = value > MAX_GRAY ? MAX_GRAY : value;
  }

 return out_img;
}

/** 
 * @brief Calculates the absolute difference between two images
 *
 * @param[in] in_img_a Image #1 { byte }
 * @param[in] in_img_b Image #2 { byte }
 *
 * @return Pointer to the resulting image or NULL
 *
 * @author M. Emre Celebi
 * @date 02.10.2008
 */

Image *
abs_diff_img ( const Image * in_img_a, const Image * in_img_b )
{
 INIT_ARITH ( "abs_diff_img" );

 for ( ik = 0; ik < num_elems; ik++ )
  {
   /* No need to check for under/overflow */
   out_data[ik] = abs ( in_data_a[ik] - in_data_b[ik] );
  }

 return out_img;
}

/** 
 * @brief Calculates the union of two images
 *
 * @param[in] in_img_a Image #1 { binary, grayscale }
 * @param[in] in_img_b Image #2 { binary, grayscale }
 *
 * @return Pointer to the union image or NULL
 *
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
union_img ( const Image * in_img_a, const Image * in_img_b )
{
 SET_FUNC_NAME ( "union_img" );
 byte *in_data_a;
 byte *in_data_b;
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_pixels;
 Image *out_img;

 if ( !img_dims_agree ( in_img_a, in_img_b ) )
  {
   ERROR_RET ( "Image dimensions must agree !", NULL );
  }

 if ( !is_bin_or_gray_img ( in_img_a ) || !is_bin_or_gray_img ( in_img_b ) )
  {
   ERROR_RET ( "Images must be binary or grayscale !", NULL );
  }

 num_rows = get_num_rows ( in_img_a );
 num_cols = get_num_cols ( in_img_a );
 num_pixels = num_rows * num_cols;

 in_data_a = get_img_data_1d ( in_img_a );
 in_data_b = get_img_data_1d ( in_img_b );

 out_img = alloc_img ( is_bin_img ( in_img_a ) &&
		       is_bin_img ( in_img_b ) ? PIX_BIN : PIX_GRAY, num_rows,
		       num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }
 out_data = get_img_data_1d ( out_img );

 if ( is_bin_img ( in_img_a ) )
  {
   if ( is_bin_img ( in_img_b ) )
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = in_data_a[ik] || in_data_b[ik];
      }
    }
   else
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = ( in_data_a[ik] == OBJECT ) ? MAX_GRAY : in_data_b[ik];
      }
    }
  }
 else
  {
   if ( is_bin_img ( in_img_b ) )
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = ( in_data_b[ik] == OBJECT ) ? MAX_GRAY : in_data_a[ik];
      }
    }
   else
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = MAX_2 ( in_data_a[ik], in_data_b[ik] );
      }
    }
  }

 return out_img;
}

/** 
 * @brief Calculates the intersection of two images
 *
 * @param[in] in_img_a Image #1 { binary, grayscale }
 * @param[in] in_img_b Image #2 { binary, grayscale }
 *
 * @return Pointer to the intersection image or NULL
 *
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
intersect_img ( const Image * in_img_a, const Image * in_img_b )
{
 SET_FUNC_NAME ( "intersect_img" );
 byte *in_data_a;
 byte *in_data_b;
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_pixels;
 Image *out_img;

 if ( !img_dims_agree ( in_img_a, in_img_b ) )
  {
   ERROR_RET ( "Image dimensions must agree !", NULL );
  }

 if ( !is_bin_or_gray_img ( in_img_a ) || !is_bin_or_gray_img ( in_img_b ) )
  {
   ERROR_RET ( "Images must be binary or grayscale !", NULL );
  }

 num_rows = get_num_rows ( in_img_a );
 num_cols = get_num_cols ( in_img_a );
 num_pixels = num_rows * num_cols;

 in_data_a = get_img_data_1d ( in_img_a );
 in_data_b = get_img_data_1d ( in_img_b );

 out_img = alloc_img ( is_bin_img ( in_img_a ) &&
		       is_bin_img ( in_img_b ) ? PIX_BIN : PIX_GRAY, num_rows,
		       num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }
 out_data = get_img_data_1d ( out_img );

 if ( is_bin_img ( in_img_a ) )
  {
   if ( is_bin_img ( in_img_b ) )
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = in_data_a[ik] && in_data_b[ik];
      }
    }
   else
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = ( in_data_a[ik] == OBJECT ) ? in_data_b[ik] : 0;
      }
    }
  }
 else
  {
   if ( is_bin_img ( in_img_b ) )
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = ( in_data_b[ik] == OBJECT ) ? in_data_a[ik] : 0;
      }
    }
   else
    {
     for ( ik = 0; ik < num_pixels; ik++ )
      {
       out_data[ik] = MIN_2 ( in_data_a[ik], in_data_b[ik] );
      }
    }
  }

 return out_img;
}

/** 
 * @brief Adds a scalar to each pixel of an image
 *
 * @param[in] in_img Image pointer { byte }
 * @param[in] scalar Scalar value
 *
 * @return Pointer to the resulting image or NULL
 *
 * @note If the value of an output pixel becomes negative or greater 
 *       than MAX_GRAY, it is set to 0 or MAX_GRAY, respectively.
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
add_img_scalar ( const Image * in_img, const double scalar )
{
 SET_FUNC_NAME ( "add_img_scalar" );
 byte *in_data;
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_pixels;
 int int_val;
 double dbl_val;
 Image *out_img;

 if ( !is_byte_img ( in_img ) )
  {
   ERROR_RET ( "Image must be of byte type !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = get_num_bands ( in_img ) * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( get_pix_type ( in_img ), num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }
 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_pixels; ik++ )
  {
   dbl_val = in_data[ik] + scalar;
   int_val = ( int ) ROUND ( dbl_val );

   out_data[ik] = CLAMP_BYTE ( int_val );
  }

 return out_img;
}

/** 
 * @brief Subtracts a scalar from each pixel of an image
 *
 * @param[in] in_img Image pointer { byte }
 * @param[in] scalar Scalar value
 *
 * @return Pointer to the resulting image or NULL
 *
 * @note If the value of an output pixel becomes negative or greater 
 *       than MAX_GRAY, it is set to 0 or MAX_GRAY, respectively.
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
sub_img_scalar ( const Image * in_img, const double scalar )
{
 return add_img_scalar ( in_img, -scalar );
}

/** 
 * @brief Multiplies each pixel of an image with a scalar
 *
 * @param[in] in_img Image pointer { byte }
 * @param[in] scalar Scalar value
 *
 * @return Pointer to the output image or NULL
 *
 * @note If the value of an output pixel becomes negative or greater 
 *       than MAX_GRAY, it is set to 0 or MAX_GRAY, respectively.
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
mult_img_scalar ( const Image * in_img, const double scalar )
{
 SET_FUNC_NAME ( "mult_img_scalar" );
 byte *in_data;
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_pixels;
 int int_val;
 double dbl_val;
 Image *out_img;

 if ( !is_byte_img ( in_img ) )
  {
   ERROR_RET ( "Image must be of byte type !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = get_num_bands ( in_img ) * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( get_pix_type ( in_img ), num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }
 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_pixels; ik++ )
  {
   dbl_val = in_data[ik] * scalar;
   int_val = ( int ) ROUND ( dbl_val );

   out_data[ik] = CLAMP_BYTE ( int_val );
  }

 return out_img;
}

/** 
 * @brief Divides each pixel of an image with a scalar
 *
 * @param[in] in_img Image pointer { byte }
 * @param[in] scalar Scalar value
 *
 * @return Pointer to the output image or NULL
 *
 * @author M. Emre Celebi
 * @date 02.10.2008
 */

Image *
div_img_scalar ( const Image * in_img, const double scalar )
{
 SET_FUNC_NAME ( "div_img_scalar" );

 if ( !is_byte_img ( in_img ) )
  {
   ERROR_RET ( "Image must be of byte type !", NULL );
  }

 if ( IS_ZERO ( scalar ) )
  {
   /* Divide by 0 => Assign the maximum possible value to each pixel */
   return alloc_const_img ( get_pix_type ( in_img ), get_num_rows ( in_img ),
			    get_num_cols ( in_img ), UCHAR_MAX );
  }

 return mult_img_scalar ( in_img, 1.0 / scalar );
}
