
/** 
 * @file bmp_io.c
 * Routines for reading/writing BMP pixel data
 */

#include <image.h>

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Reads pixel data of a 1-bit BMP file
 *
 * @param[in] num_rows # rows
 * @param[in] num_cols # columns
 * @param[in,out] file_ptr File pointer
 *
 * @return Pointer to the image or NULL
 *
 * @ref http://www.fileformat.info/format/cloud.htm

 * @author M. Emre Celebi
 * @date 10.15.2006
 */

Image *
read_bmp1_data ( const int num_rows, const int num_cols,
		 const Bool is_bottom_up, FILE * file_ptr )
{
 static int bit_masks[] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };
 byte bg_val, obj_val;		/* values for background and object pixels */
 byte one_byte;
 byte *tmp_data_1d;
 byte *data_1d;
 int pad_amount;
 int col_size;
 int num_bytes;
 int ir, ic, ik;
 int offset;
 int pos1;
 int pos2;
 div_t div_res;
 Image *img;

 img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( img ) )
  {
   return NULL;
  }

 data_1d = get_img_data_1d ( img );

 /* Calculate the # padding bytes */
 div_res = div ( num_cols, 8 );
 pad_amount = 4 - ( ( div_res.quot + ( div_res.rem > 0 ) ) % 4 );
 if ( pad_amount == 4 )
  {
   pad_amount = 0;
  }

 col_size = 4 * ( ( num_cols + 31 ) / 32 );
 num_bytes = num_rows * col_size;
 tmp_data_1d = ( byte * ) malloc ( num_bytes * sizeof ( byte ) );
 if ( IS_NULL ( tmp_data_1d ) )
  {
   free_img ( img );
   return NULL;
  }

 /* Go back to the color map */
 fseek ( file_ptr, -8, SEEK_CUR );
 /* Read the first byte in the color map */
 ( void ) fread ( &one_byte, 1, 1, file_ptr );
 /* If it is 255 then object pixels are 1 and
    background pixels are 0; otherwise vice versa */
 obj_val = ( one_byte == 255 ) ? 1 : 0;
 bg_val = !obj_val;
 /* Go back to the pixel data */
 fseek ( file_ptr, 7, SEEK_CUR );

 /* Read the pixel data into a temporary 1d array */
 ( void ) fread ( tmp_data_1d, 1, ( size_t ) num_bytes, file_ptr );

 if ( is_bottom_up )
  {
   /* Rows are stored bottom-up */
   pos1 = ( num_rows - 1 ) * col_size;
   offset = 2 * col_size - pad_amount;
  }
 else
  {
   /* Rows are stored top-down */
   pos1 = 0;
   offset = -pad_amount;
  }

 /* Unpack the pixels and store them into the image arrays */
 pos2 = 0;
 for ( ir = 0; ir < num_rows; ir++ )
  {
   for ( ic = 0; ic < div_res.quot; ic++ )
    {
     /* Get one byte */
     one_byte = tmp_data_1d[pos1++];

     /* Unpack it and store the bits */
     data_1d[pos2++] = ( one_byte & 0x80 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x40 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x20 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x10 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x08 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x04 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x02 ) ? bg_val : obj_val;
     data_1d[pos2++] = ( one_byte & 0x01 ) ? bg_val : obj_val;
    }

   if ( div_res.rem )
    {
     /* Get the last byte of this row */
     one_byte = tmp_data_1d[pos1++];

     /* Unpack it and store the bits */
     for ( ik = 0; ik < div_res.rem; ik++ )
      {
       data_1d[pos2++] = ( one_byte & bit_masks[7 - ik] ) ? bg_val : obj_val;
      }
    }

   pos1 -= offset;
  }

 free ( tmp_data_1d );

 return img;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Writes pixel data of a 1-bit BMP file
 *
 * @param[in] img Image pointer
 * @param[in,out] file_ptr File pointer
 *
 * @return E_SUCCESS or NULL
 *
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

int
write_bmp1 ( const Image * img, FILE * file_ptr )
{
 byte one_byte;
 static byte color_table[] = { 255, 255, 255, 0, 0, 0, 0, 0 };	/* cannot be INT ! */
 byte *tmp_data_1d;
 byte *data_1d;
 int pad_amount;
 int ir, ic, ik;
 int num_rows, num_cols;
 int col_size;
 int num_bytes;
 int offset;
 int pos1, pos2;
 div_t div_res;

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 /* Calculate the # padding bytes */
 div_res = div ( num_cols, 8 );
 pad_amount = 4 - ( ( div_res.quot + ( div_res.rem > 0 ) ) % 4 );
 if ( pad_amount == 4 )
  {
   pad_amount = 0;
  }

 data_1d = get_img_data_1d ( img );

 col_size = 4 * ( ( num_cols + 31 ) / 32 );
 num_bytes = num_rows * col_size;
 tmp_data_1d = ( byte * ) malloc ( num_bytes * sizeof ( byte ) );
 if ( IS_NULL ( tmp_data_1d ) )
  {
   return E_NOMEM;
  }

 /* Unpack the pixels and store them into the image arrays */
 offset = 2 * col_size - pad_amount;
 pos1 = ( num_rows - 1 ) * col_size;
 pos2 = 0;
 for ( ir = 0; ir < num_rows; ir++ )
  {
   for ( ic = 0; ic < div_res.quot; ic++ )
    {
     /* Pack 8 bits into one byte and store */
     tmp_data_1d[pos1++] = 255 - ( ( data_1d[pos2] << 7 ) |
				   ( data_1d[pos2 + 1] << 6 ) |
				   ( data_1d[pos2 + 2] << 5 ) |
				   ( data_1d[pos2 + 3] << 4 ) |
				   ( data_1d[pos2 + 4] << 3 ) |
				   ( data_1d[pos2 + 5] << 2 ) |
				   ( data_1d[pos2 + 6] << 1 ) |
				   ( data_1d[pos2 + 7] ) );

     pos2 += 8;
    }

   if ( div_res.rem )
    {
     /* Pack the last bits of this row into a byte */
     one_byte = 0;
     for ( ik = 0; ik < div_res.rem; ik++ )
      {
       one_byte |= ( ( data_1d[pos2] > 0 ) << ( 7 - ik ) );
       pos2++;
      }

     /* Store the last byte */
     tmp_data_1d[pos1++] = 255 - one_byte;
    }

   pos1 -= offset;
  }

 /* Write image header */
 write_bmp_header ( PIX_BIN, num_rows, num_cols, file_ptr );
 /* Write the color table (only 2 colors) */
 ( void ) fwrite ( color_table, 1, 8, file_ptr );
 /* Write pixel data */
 ( void ) fwrite ( tmp_data_1d, 1, ( size_t ) num_bytes, file_ptr );

 free ( tmp_data_1d );

 return E_SUCCESS;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Reads pixel data of an 8-bit BMP file
 *
 * @param[in] num_rows # rows
 * @param[in] num_cols # columns
 * @param[in,out] file_ptr File pointer
 *
 * @return Pointer to the image or NULL
 *
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

Image *
read_bmp8_data ( const int num_rows, const int num_cols,
		 const Bool is_bottom_up, FILE * file_ptr )
{
 byte *data_1d;
 int pad_amount;
 int pos;
 int offset;
 int i;
 Image *img;

 img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( img ) )
  {
   return NULL;
  }

 data_1d = get_img_data_1d ( img );

 pad_amount = ( 4 - ( num_cols % 4 ) ) & 3;

 if ( is_bottom_up )
  {
   /* Rows are stored bottom-up */
   pos = ( num_rows - 1 ) * num_cols;
   offset = num_cols;
  }
 else
  {
   /* Rows are stored top-down */
   pos = 0;
   offset = -num_cols;
  }

 /* Read pixel data */
 for ( i = 0; i < num_rows; i++ )
  {
   /* Read one row */
   ( void ) fread ( data_1d + pos, 1, ( size_t ) num_cols, file_ptr );

   if ( pad_amount )
    {
     /* Skip padding */
     fseek ( file_ptr, pad_amount, SEEK_CUR );
    }
   pos -= offset;
  }

 return img;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Writes pixel data of an 8-bit BMP file
 *
 * @param[in] img Image pointer
 * @param[in,out] file_ptr File pointer
 *
 * @return E_SUCCESS 
 *
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

int
write_bmp8 ( const Image * img, FILE * file_ptr )
{
 byte *zeros = NULL;
 byte **data_2d;
 int num_rows, num_cols;
 int pad_amount;
 int i;

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 pad_amount = ( 4 - ( num_cols % 4 ) ) & 3;

 if ( pad_amount )
  {
   zeros = ( byte * ) calloc ( ( size_t ) pad_amount, sizeof ( byte ) );
  }

 data_2d = get_img_data_nd ( img );

 /* Write image header */
 write_bmp_header ( PIX_GRAY, num_rows, num_cols, file_ptr );

 /* Write the color table (256 colors) */
 for ( i = 0; i < 256; i++ )
  {
   fputc ( i, file_ptr );
   fputc ( i, file_ptr );
   fputc ( i, file_ptr );
   fputc ( 0, file_ptr );
  }

 /* Write pixel data */
 for ( i = num_rows - 1; i >= 0; i-- )
  {
   ( void ) fwrite ( data_2d[i], 1, ( size_t ) num_cols, file_ptr );

   if ( pad_amount )
    {
     /* Pad the rest of the rows with 0s */
     ( void ) fwrite ( zeros, 1, ( size_t ) pad_amount, file_ptr );
    }
  }

 if ( pad_amount )
  {
   free ( zeros );
  }

 return E_SUCCESS;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Reads pixel data of a 24-bit BMP file
 *
 * @param[in] num_rows # rows
 * @param[in] num_cols # columns
 * @param[in,out] file_ptr File pointer
 *
 * @return Pointer to the image or 
 *         NULL if memory is insufficient
 *
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

Image *
read_bmp24_data ( const int num_rows, const int num_cols,
		  const Bool is_bottom_up, FILE * file_ptr )
{
 byte tmp_val;
 byte *data_1d;
 int num_cols_t3;
 int pad_amount;
 int pos;
 int offset;
 int i;
 Image *img;

 img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( img ) )
  {
   return NULL;
  }

 data_1d = get_img_data_1d ( img );

 num_cols_t3 = 3 * num_cols;
 pad_amount = ( 4 - ( num_cols_t3 % 4 ) ) & 3;

 if ( is_bottom_up )
  {
   /* Rows are stored bottom-up */
   pos = ( num_rows - 1 ) * num_cols_t3;
   offset = num_cols_t3;
  }
 else
  {
   /* Rows are stored top-down */
   pos = 0;
   offset = -num_cols_t3;
  }

 /* Read pixel data */
 for ( i = 0; i < num_rows; i++ )
  {
   /* Read one row */
   ( void ) fread ( data_1d + pos, 1, ( size_t ) num_cols_t3, file_ptr );

   if ( pad_amount )
    {
     /* Skip padding */
     fseek ( file_ptr, pad_amount, SEEK_CUR );
    }
   pos -= offset;
  }

 /* Convert BGR to RGB */
 for ( i = 0; i < ( num_rows * num_cols_t3 ); i += 3 )
  {
   tmp_val = data_1d[i + 2];
   data_1d[i + 2] = data_1d[i];
   data_1d[i] = tmp_val;
  }

 return img;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Writes pixel data of a 24-bit BMP file
 *
 * @param[in] img Image pointer
 * @param[in,out] file_ptr File pointer
 *
 * @return E_SUCCESS 
 *
 * @ref http://www.fileformat.info/format/cloud.htm
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

int
write_bmp24 ( const Image * img, FILE * file_ptr )
{
 byte tmp_val;
 byte *zeros = NULL;
 byte *data_1d;
 int num_rows, num_cols;
 int num_cols_t3;
 int pad_amount;
 int pos;
 int i;

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );
 num_cols_t3 = 3 * num_cols;

 pad_amount = ( 4 - ( ( num_cols_t3 ) % 4 ) ) & 3;

 if ( pad_amount )
  {
   zeros = ( byte * ) calloc ( ( size_t ) pad_amount, sizeof ( byte ) );
  }

 data_1d = get_img_data_1d ( img );

 /* Write image header */
 write_bmp_header ( PIX_RGB, num_rows, num_cols, file_ptr );

 /* Convert RGB to BGR */
 for ( i = 0; i < ( num_rows * num_cols_t3 ); i += 3 )
  {
   tmp_val = data_1d[i + 2];
   data_1d[i + 2] = data_1d[i];
   data_1d[i] = tmp_val;
  }

 /* Write pixel data */
 pos = ( num_rows - 1 ) * num_cols_t3;
 for ( i = 0; i < num_rows; i++ )
  {
   /* Write one row */
   ( void ) fwrite ( data_1d + pos, 1, ( size_t ) num_cols_t3, file_ptr );

   if ( pad_amount )
    {
     /* Pad the rest of the rows with 0s */
     ( void ) fwrite ( zeros, 1, ( size_t ) pad_amount, file_ptr );
    }

   pos -= num_cols_t3;
  }

 if ( pad_amount )
  {
   free ( zeros );
  }

 return E_SUCCESS;
}

/** @endcond INTERNAL_FUNCTION */
