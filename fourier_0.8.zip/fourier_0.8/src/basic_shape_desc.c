
/** 
 * @file basic_shape_desc.c
 * Routines for Basic Shape Descriptors
 */

#include <image.h>

/** 
 * @brief Counts the number of pixels in an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pixel count or INT_MIN
 *
 * @author M. Emre Celebi
 * @date 11.17.2007
 */

/** @cond INTERNAL_MACRO */

#define COUNT_OBJ_PIXELS( )\
count = 0;\
for ( ik = 0; ik < num_pixels; ik++ )\
 { count += ( data[ik] == label ); }\


/** @endcond INTERNAL_MACRO */

int
count_obj_pixels ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "count_obj_pixels" );
 int num_pixels;
 int ik;
 int count;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", INT_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return INT_MIN;
  }

 num_pixels = get_num_rows ( img ) * get_num_cols ( img );

 if ( is_bin_img ( img ) )
  {
   byte *data = get_img_data_1d ( img );

   COUNT_OBJ_PIXELS (  );
  }
 else
  {
   int *data = get_img_data_1d ( img );

   COUNT_OBJ_PIXELS (  );
  }

 return count;
}

#undef COUNT_OBJ_PIXELS

/** 
 * @brief Calculates the Area of an object using Bit-Quads
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Area value or INT_MIN
 *
 * @note 1) Border effects are ignored.
 *       2) This method is slower than simple pixel counting (count_obj_pixels). 
 *          However, it is more accurate especially for objects with rough borders.
 *
 * @ref 1) Gray S.B. (1971) "Local Properties of Binary Images in Two Dimensions" 
 *         IEEE Trans. on Computers, C-20(5): 551-561.
 *      2) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside"
 *          (4th Ed.), pp. 628-630, John Wiley & Sons
 *	3) Yang L., Albregtsen F., Lonnestad T., and Grottum P. (1994) "Methods to 
 *	   Estimate Areas and Perimeters of Blob-Like Objects: A Comparison" Proc. 
 *	   of the IAPR Workshop on Machine Vision Applications, pp. 272-276.
 *	   
 * @author M. Emre Celebi
 * @date 11.17.2007
 */

/** @cond INTERNAL_MACRO */

#define CALC_OBJ_AREA( )\
area = 0;\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  row_limit = ( ir == num_rows - 1 ) ? 0 : 1;\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    col_limit = ( ic == num_cols - 1 ) ? 0 : 1;\
    offset = 0;\
    for ( iwr = 0; iwr <= row_limit; iwr++ )\
     {\
      for ( iwc = 0; iwc <= col_limit; iwc++ )\
       {\
        offset += weights[iwr][iwc] * ( data[ir + iwr][ic + iwc] == label );\
       }\
     }\
    area += lut[offset];\
   }\
 }\


/** @endcond INTERNAL_MACRO */

double
calc_obj_area ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_obj_area" );
 int num_rows, num_cols;
 int ir, ic;
 int iwr, iwc;
 int row_limit, col_limit;
 int offset;
 int area;
 static int weights[2][2] = { {1, 4}, {2, 8} };	/* Weights for the Bit Quad patterns */
 /* Lookup Table for the Bit Quad patterns */
 /* Q0  Q1  Q1  Q2  Q1  Q2  QD  Q3  Q1  QD  Q2  Q3  Q2  Q3  Q3  Q4 */
 static int lut[16] = { 0, 2, 2, 4, 2, 4, 6, 7, 2, 6, 4, 7, 4, 7, 7, 8 };

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_OBJ_AREA (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_OBJ_AREA (  );
  }

 /* Normalize the convolution result */
 return area / 8.0;
}

#undef CALC_OBJ_AREA

/** 
 * @brief Calculates the Aspect Ratio (width to height ratio 
 *        of the axis-aligned bounding box) of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Aspect Ratio value or INT_MIN
 *
 * @author M. Emre Celebi
 * @date 11.17.2007
 */

double
calc_aspect_ratio ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_aspect_ratio" );
 double aspect_ratio;
 Box *box;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 box = calc_box ( img, label );
 if ( IS_NULL ( box ) )
  {
   ERROR ( "No object pixel with label ( %d ) found !", label );
   return DBL_MIN;
  }

 aspect_ratio = get_box_width ( box ) / ( double ) get_box_height ( box );

 free ( box );

 return aspect_ratio;
}

/** 
 * @brief Calculates the Centroid (center of mass) of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the Centroid or NULL
 *
 * @author M. Emre Celebi
 * @date 11.17.2007
 */

/** @cond INTERNAL_MACRO */

#define CALC_OBJ_CENTROID( )\
pix_count = 0;\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    if ( data[ir][ic] == label )\
     {\
      centroid->row += ir;\
      centroid->col += ic;\
      pix_count++;\
     }\
   }\
 }\


/** @endcond INTERNAL_MACRO */

Point *
calc_obj_centroid ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_obj_centroid" );
 int num_rows, num_cols;
 int ir, ic;
 int pix_count;
 Point *centroid;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 centroid = alloc_point ( 0.0, 0.0 );

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_OBJ_CENTROID (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_OBJ_CENTROID (  );
  }

 if ( pix_count == 0 )
  {
   ERROR ( "No object pixel with label ( %d ) found !", label );
   return NULL;
  }

 centroid->row /= ( double ) pix_count;
 centroid->col /= ( double ) pix_count;

 return centroid;
}

#undef CALC_OBJ_CENTROID

/** 
 * @brief Crops an object out of an image
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the image that contains the cropped object or NULL
 *
 * @author M. Emre Celebi
 * @date 11.17.2007
 */

/** @cond INTERNAL_MACRO */

#define CROP_OBJECT( )\
for ( ir = box->min_row; ir <= box->max_row; ir++ )\
 {\
  for ( ic = box->min_col; ic <= box->max_col; ic++ )\
   {\
    if ( in_data[ir][ic] == label )\
     {\
      out_data[ir - box->min_row][ic - box->min_col] = OBJECT;\
     }\
   }\
 }\


/** @endcond INTERNAL_MACRO */

Image *
crop_object ( const Image * in_img, const int label )
{
 SET_FUNC_NAME ( "crop_object" );
 int ir, ic;
 byte **out_data;
 Box *box;
 Image *out_img;

 if ( !is_bin_or_label_img ( in_img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 box = calc_box ( in_img, label );

 out_img = alloc_img ( PIX_BIN, get_box_height ( box ), get_box_width ( box ) );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 if ( is_bin_img ( in_img ) )
  {
   byte **in_data = get_img_data_nd ( in_img );

   CROP_OBJECT (  );
  }
 else
  {
   int **in_data = get_img_data_nd ( in_img );

   CROP_OBJECT (  );
  }

 free ( box );

 return out_img;
}

#undef CROP_OBJECT

/** @cond INTERNAL_MACRO */

#define CLIP( num, lim ) ( ( num ) > ( lim ) ? ( lim ) : ( num ) )

/** @endcond INTERNAL_MACRO */

/** 
 * @brief Scales an object to fit it into a circle
 *
 * @param[in] in_img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] radius Radius of the target circle { positive }
 *
 * @return Pointer to the image that contains the scaled object or NULL
 * @see #calc_zernike_moments, #calc_gen_fourier_desc
 *
 * @author Dengsheng Zhang
 * @date 11.18.2007
 */

Image *
circular_scale ( const Image * in_img, const int label, const int radius )
{
 SET_FUNC_NAME ( "circular_scale" );
 byte **ci_data;		/* Pixel data of the cropped image */
 byte **si_data;		/* Pixel data of the scaled image */
 byte **tmp_data;		/* Temporary pixel data */
 int diameter;
 int ir, ic;
 int old_row, old_col;
 int new_row, new_col;
 int iwr, iwc;
 int cr, cc;
 int si_num_rows, si_num_cols;	/* Dimensions of the scaled image */
 int ci_num_rows, ci_num_cols;	/* Dimensions of the cropped image */
 int ulimit;
 double rad, max_rad;
 double scaling_factor;
 Point *centroid;
 Image *cropped_img;
 Image *scaled_img;

 if ( !is_bin_or_label_img ( in_img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( radius <= 0 )
  {
   ERROR ( "Radius ( %d ) must be positive !", radius );
   return NULL;
  }

 diameter = 2 * radius;
 ulimit = diameter - 1;

 /* Allocate output image */
 scaled_img = alloc_img ( PIX_BIN, diameter, diameter );
 si_data = get_img_data_nd ( scaled_img );

 /* Allocate temporary data */
 tmp_data = alloc_nd ( sizeof ( byte ), 2, diameter, diameter );
 if ( IS_NULL ( tmp_data ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Crop the object -- The resulting image is always binary */
 cropped_img = crop_object ( in_img, label );

 ci_num_rows = get_num_rows ( cropped_img );
 ci_num_cols = get_num_cols ( cropped_img );
 ci_data = get_img_data_nd ( cropped_img );

 /* Calculate the object centroid */
 centroid = calc_obj_centroid ( cropped_img, OBJECT );

 /* Calculate the maximum radius of the shape */
 max_rad = DBL_MIN;
 for ( ir = 0; ir < ci_num_rows; ir++ )
  {
   for ( ic = 0; ic < ci_num_cols; ic++ )
    {
     if ( ci_data[ir][ic] == OBJECT )
      {
       rad = L2_DIST_2D_SQR ( ir, ic, centroid->row, centroid->col );
       if ( max_rad < rad )
	{
	 max_rad = rad;
	}
      }
    }
  }

 max_rad = sqrt ( max_rad );

 /* Determine the scaling factor */
 scaling_factor = radius / max_rad;

 /* Scale the shape */
 old_row = old_col = 0;
 for ( ir = 0; ir < ci_num_rows; ir++ )
  {
   new_row = ir * scaling_factor;
   if ( new_row > ulimit )
    {
     new_row = ulimit;
    }

   for ( ic = 0; ic < ci_num_cols; ic++ )
    {
     new_col = ic * scaling_factor;
     if ( new_col > ulimit )
      {
       new_col = ulimit;
      }

     si_data[new_row][new_col] = ci_data[ir][ic];

     /* Spread pixels */
     if ( new_col > old_col )
      {
       if ( new_row > old_row )	/* Spread pixels in both directions */
	{
	 for ( iwr = old_row; iwr <= new_row; iwr++ )
	  {
	   for ( iwc = old_col; iwc <= new_col; iwc++ )
	    {
	     si_data[iwr][iwc] = ci_data[ir][ic];
	    }
	  }
	}
       else			/* Spread pixels in horizontal direction only */
	{
	 for ( iwc = old_col; iwc <= new_col; iwc++ )
	  {
	   si_data[new_row][iwc] = ci_data[ir][ic];
	  }
	}
      }
     old_col = new_col;
    }
   old_row = new_row;
  }

 /* Calculate the translation amount */
 centroid = calc_obj_centroid ( scaled_img, OBJECT );
 cr = radius - centroid->row;
 cc = radius - centroid->col;

 /* Translate the scaled object to the center of the unit disk, i.e. (RADIUS, RADIUS) */
 si_num_rows = scaling_factor * ci_num_rows;
 si_num_cols = scaling_factor * ci_num_cols;

 for ( ir = 0; ir < si_num_rows; ir++ )
  {
   for ( ic = 0; ic < si_num_cols; ic++ )
    {
     tmp_data[CLIP ( ir + cr, ulimit )][CLIP ( ic + cc, ulimit )] =
      si_data[CLIP ( ir, ulimit )][CLIP ( ic, ulimit )];
    }
  }

 for ( ir = 0; ir < diameter; ir++ )
  {
   for ( ic = 0; ic < diameter; ic++ )
    {
     si_data[ir][ic] = tmp_data[ir][ic];
    }
  }

 free_nd ( tmp_data, 2 );
 free_img ( cropped_img );

 return scaled_img;
}

#undef CLIP

/** 
 * @brief Calculates the Triangularity of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Triangularity value or DBL_MIN
 *
 * @ref Rosin P.L. (2003) "Measuring Shape: Ellipticity, Rectangularity, 
 *      and Triangularity" Machine Vision and Applications, 14: 172-184.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

/** @cond INTERNAL_MACRO */

#define CALC_CENTRAL_MOMENTS( )\
/* Calculate the centroid */\
r_bar = c_bar = 0.0;\
pix_count = 0;\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    if ( data[ir][ic] == label )\
     {\
      r_bar += ir;\
      c_bar += ic;\
      pix_count++;\
     }\
   }\
 }\
cm->m00 = pix_count;\
r_bar /= cm->m00;\
c_bar /= cm->m00;\
/* Calculate the second order central moments */\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  r_dist = ir - r_bar;\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    if ( data[ir][ic] == label )\
     {\
      c_dist = ic - c_bar;\
      cm->m02 += r_dist * r_dist;\
      cm->m11 += r_dist * c_dist;\
      cm->m20 += c_dist * c_dist;\
     }\
   }\
 }\


/** @endcond INTERNAL_MACRO */

double
calc_triangularity ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_triangularity" );
 int ir, ic;
 int pix_count;
 int num_rows, num_cols;
 double r_bar, c_bar;
 double r_dist, c_dist;
 double I1_object;
 double I1_triangle;
 GeoMoments *cm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 /* Calculate the second-order central moments */
 cm = CALLOC_STRUCT ( GeoMoments );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }

 I1_object = ( cm->m20 * cm->m02 - cm->m11 * cm->m11 ) / pow ( cm->m00, 4.0 );

 I1_triangle = 1 / 108.0;

 free ( cm );

 if ( I1_object <= I1_triangle )
  {
   return I1_object / I1_triangle;
  }

 return I1_triangle / I1_object;
}

/** 
 * @brief Calculates the Ellipticity of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Ellipticity value or DBL_MIN
 *
 * @ref Rosin P.L. (2003) "Measuring Shape: Ellipticity, Rectangularity, 
 *      and Triangularity" Machine Vision and Applications, 14: 172-184.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_ellipticity ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_ellipticity" );
 int ir, ic;
 int pix_count;
 int num_rows, num_cols;
 double r_bar, c_bar;
 double r_dist, c_dist;
 double I1_object;
 double I1_unit_circle;
 GeoMoments *cm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 /* Calculate the second-order central moments */
 cm = CALLOC_STRUCT ( GeoMoments );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }

 I1_object = ( cm->m20 * cm->m02 - cm->m11 * cm->m11 ) / pow ( cm->m00, 4.0 );

 I1_unit_circle = 1.0 / ( 16.0 * PI * PI );

 free ( cm );

 if ( I1_object <= I1_unit_circle )
  {
   return I1_object / I1_unit_circle;
  }

 return I1_unit_circle / I1_object;
}

/** 
 * @brief Calculates the Ellipse Features of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the Ellipse Features or NULL
 *
 * @ref 1) Haralick R.M. and Shapiro L. (1992) "Computer and Robot Vision" Volume 1
 *      2) Shapiro L. and Stockman G. (2001) "Computer Vision" Prentice-Hall
 *      3) Jahne B. (2001) "Digital Image Processing (5th Ed.)" Springer
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

EllipseFeatures *
calc_ellipse_feats ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_ellipse_feats" );
 int ir, ic;
 int pix_count;
 int num_rows, num_cols;
 double r_bar, c_bar;
 double r_dist, c_dist;
 double common;
 double numer, denom;
 GeoMoments *cm;
 EllipseFeatures *feats;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 /* Calculate the second-order central moments */
 cm = CALLOC_STRUCT ( GeoMoments );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }

 feats = CALLOC_STRUCT ( EllipseFeatures );

 /* Normalize the second-order central moments */
 /* 1 / 12.0 = Normalized second-order central moment of a single pixel */
 cm->m20 = cm->m20 / cm->m00 + 1 / 12.0;
 cm->m02 = cm->m02 / cm->m00 + 1 / 12.0;
 cm->m11 = -cm->m11 / cm->m00;

 common =
  sqrt ( ( cm->m02 - cm->m20 ) * ( cm->m02 - cm->m20 ) +
	 4 * cm->m11 * cm->m11 );

 feats->maj_axis_len = 2 * sqrt ( 2. ) * sqrt ( cm->m02 + cm->m20 + common );
 feats->min_axis_len = 2 * sqrt ( 2. ) * sqrt ( cm->m02 + cm->m20 - common );

 feats->aspect_ratio = feats->maj_axis_len / feats->min_axis_len;

 /* Note that eccentricity has multiple different formulations */
 feats->eccentricity = common / ( cm->m02 + cm->m20 );

 if ( cm->m02 > cm->m20 )
  {
   numer = cm->m02 - cm->m20 + common;
   denom = 2 * cm->m11;
  }
 else
  {
   numer = 2 * cm->m11;
   denom = cm->m20 - cm->m02 + common;
  }

 if ( IS_ZERO ( numer ) || IS_ZERO ( denom ) )
  {
   feats->orientation = 0.0;
  }
 else
  {
   feats->orientation = atan ( numer / denom );
  }

 free ( cm );

 return feats;
}

#undef CALC_CENTRAL_MOMENTS

/** 
 * @brief Calculates the Equivalent Diameter of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Equivalent Diameter value or DBL_MIN
 *
 * @ref 1) Russ J.C. (2007) "The Image Processing Handbook (5th Ed.)" CRC Press 
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_equi_diameter ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_equi_diameter" );

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 return sqrt ( 4.0 * count_obj_pixels ( img, label ) / PI );
}

/** 
 * @brief Calculates the Elliptic Variance of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 *
 * @return Elliptic Variance value or DBL_MIN
 *
 * @ref 1) Peura M. and Iivarinen J. (1997) "Efficiency of Simple Shape Descriptors"
 *         Aspects of Visual Form Processing, Arcelli C., Cordella L.P., Sanniti di Baja G. 
 *	   (Eds.), World Scientific, pp 443-451
 *      2) Rosin P.L. (2003) "Measuring Shape: Ellipticity, Rectangularity, 
 *         and Triangularity" Machine Vision and Applications, 14: 172-184.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_elliptic_var ( const Image * img, const int label, const PointList * cont )
{
 SET_FUNC_NAME ( "calc_elliptic_var" );
 int ik;
 int num_pts;
 double row_mean, col_mean;
 double row_delta, col_delta;
 double cov00, cov01, cov11;
 double mean_rad_dist;
 double elliptic_var;
 double determinant;
 double *rad_dist;
 Point *centroid;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", DBL_MIN );
  }

 /* 
  * Calculate the object centroid. This is more robust 
  * than the contour centroid which is sensitive to noise. 
  */
 centroid = calc_obj_centroid ( img, label );
 row_mean = centroid->row;
 col_mean = centroid->col;

 num_pts = get_num_pts ( cont );

 rad_dist = ( double * ) malloc ( num_pts * sizeof ( double ) );
 if ( IS_NULL ( rad_dist ) )
  {
   ERROR_RET ( "Insufficient memory !", DBL_MIN );
  }

 /* Calculate and simultaneously invert the covariance matrix */
 cov00 = cov01 = cov11 = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   row_delta = cont->point[ik]->row - row_mean;
   col_delta = cont->point[ik]->col - col_mean;

   cov00 += col_delta * col_delta;
   cov01 -= row_delta * col_delta;
   cov11 += row_delta * row_delta;
  }

 cov00 /= ( num_pts - 1 );
 cov11 /= ( num_pts - 1 );
 cov01 /= ( num_pts - 1 );

 determinant = cov00 * cov11 - cov01 * cov01;
 if ( IS_ZERO ( determinant ) )
  {
   ERROR_RET ( "Covariance matrix is ill-conditioned !", DBL_MIN );
  }

 cov00 /= determinant;
 cov11 /= determinant;
 cov01 /= determinant;

 /* Premultiply the diagonal entry for weighted distance calculations */
 cov01 *= 2;

 /* Calculate the weighted radial distances and their mean */
 mean_rad_dist = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   mean_rad_dist += ( rad_dist[ik] =
		      sqrt ( ( cont->point[ik]->row -
			       row_mean ) * ( cont->point[ik]->row -
					      row_mean ) * cov00 +
			     ( cont->point[ik]->row -
			       row_mean ) * ( cont->point[ik]->col -
					      col_mean ) * cov01 +
			     ( cont->point[ik]->col -
			       col_mean ) * ( cont->point[ik]->col -
					      col_mean ) * cov11 ) );
  }
 mean_rad_dist /= num_pts;

 /* Calculate the elliptic variance */
 elliptic_var = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   elliptic_var += ( rad_dist[ik] - mean_rad_dist ) *
    ( rad_dist[ik] - mean_rad_dist );
  }

 /* In Rosin's article the normalization factor is NUM_PTS * MEAN_RAD_DIST^2 */
 elliptic_var /= ( num_pts * mean_rad_dist );

 free ( rad_dist );

 return elliptic_var;
}

/** 
 * @brief Calculates the Circularity of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 *
 * @return Circularity value or DBL_MIN
 *
 * @ref 1) Haralick R.M. (1974) "Measure for Circularity of Digital Figures"
 * 	   IEEE Trans. on Systems, Man, and Cybernetics, SMC-4: 394-396.
 * 	2) Haralick R.M. and Shapiro L. (1992) "Computer and Robot Vision" Volume 1
 *      3) Shapiro L. and Stockman G. (2001) "Computer Vision" Prentice-Hall
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_circularity ( const Image * img, const int label, const PointList * cont )
{
 SET_FUNC_NAME ( "calc_circularity" );
 int ik;
 int num_pts;
 double row_mean, col_mean;
 double mean_dist, var_dist;
 double *rad_dist;
 Point *centroid;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", DBL_MIN );
  }

 /* 
  * Calculate the object centroid. This is more robust 
  * than the contour centroid which is sensitive to noise. 
  */
 centroid = calc_obj_centroid ( img, label );
 row_mean = centroid->row;
 col_mean = centroid->col;

 num_pts = get_num_pts ( cont );

 rad_dist = ( double * ) malloc ( num_pts * sizeof ( double ) );
 if ( IS_NULL ( rad_dist ) )
  {
   ERROR_RET ( "Insufficient memory !", DBL_MIN );
  }

 /* Calculate the mean of the radial distances */
 mean_dist = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   mean_dist += ( rad_dist[ik] =
		  L2_DIST_2D ( cont->point[ik]->row, cont->point[ik]->col,
			       row_mean, col_mean ) );
  }

 mean_dist /= num_pts;

 /* Calculate the variance of the radial distances */
 var_dist = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   var_dist += ( rad_dist[ik] - mean_dist ) * ( rad_dist[ik] - mean_dist );
  }

 var_dist /= num_pts;

 free ( rad_dist );

 /* circularity = mean / stdev */
 return mean_dist / sqrt ( var_dist );
}

/** 
 * @brief Calculates the Radial Distance Features of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 *
 * @return Pointer to the Radial Distance Features or NULL
 *
 * @ref 1) Kilday J., Palmieri F., and Fox M.D. (1993) "Classifying Mammographic Lesions Using 
 *         Computerized Image Analysis" IEEE Trans. on Medical Imaging, 12(4): 664-669.
 * 	2) Bruce L.M. and Kallergi M. (1999) "Effects of Image Resolution and Segmentation Method on 
 * 	   Automated Mammographic Mass Shape Classification" Proc. of the SPIE, 3661: 940-947.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

RadialDistFeatures *
calc_radial_dist_feats ( const Image * img, const int label,
			 const PointList * cont )
{
 SET_FUNC_NAME ( "calc_radial_dist_feats" );
 int ik, is;
 int num_pts;
 int num_bins = 100;		/* # bins in the radial distance histogram */
 int num_segs = 100;		/* # segments in the contour */
 int seg_len;
 int index;
 double row_mean, col_mean;
 double mean_dist, max_dist, var_dist;
 double entropy;
 double seg_roughness, total_roughness;
 double *rad_dist;
 double *histo;
 Point *centroid;
 RadialDistFeatures *rdm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR ( "Invalid point list object !" );
  }

 rdm = CALLOC_STRUCT ( RadialDistFeatures );

 num_pts = get_num_pts ( cont );
 if ( num_pts < num_segs )
  {
   ERROR ( "Object contour is too short for reliable measurements !" );
  }

 /* 
  * Calculate the object centroid. This is more robust 
  * than the contour centroid which is sensitive to noise. 
  */
 centroid = calc_obj_centroid ( img, label );
 row_mean = centroid->row;
 col_mean = centroid->col;

 rad_dist = ( double * ) malloc ( ( num_pts + 1 ) * sizeof ( double ) );
 if ( IS_NULL ( rad_dist ) )
  {
   ERROR ( "Insufficient memory !" );
  }

 /* Calculate the mean of the radial distances: Equation (2) */
 mean_dist = 0.0;
 max_dist = DBL_MIN;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   mean_dist += ( rad_dist[ik] =
		  L2_DIST_2D ( cont->point[ik]->row, cont->point[ik]->col,
			       row_mean, col_mean ) );
   if ( max_dist < rad_dist[ik] )
    {
     max_dist = rad_dist[ik];
    }
  }
 mean_dist /= num_pts;
 rdm->mean = mean_dist;

 /* Calculate the variance of the radial distances: Equation (2) */
 var_dist = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   var_dist += ( rad_dist[ik] - mean_dist ) * ( rad_dist[ik] - mean_dist );
  }

 var_dist /= num_pts;
 rdm->stdev = sqrt ( var_dist );

 /* Normalize radial distances by the max. distance */
 for ( ik = 0; ik < num_pts; ik++ )
  {
   rad_dist[ik] /= max_dist;
  }

 /* Allocate storage for radial distance histogram */
 histo = ( double * ) calloc ( num_bins, sizeof ( double ) );

 /* Populate histogram */
 for ( ik = 0; ik < num_pts; ik++ )
  {
   index = ( int ) ( num_bins * rad_dist[ik] + 0.5 );	/* round */
   if ( index == num_bins )
    {
     index--;			/* Avoid overflow */
    }

   histo[index] += 1.0;
  }

 /* Calculate the frequency histogram (normalize the histogram) */
 for ( ik = 0; ik < num_bins; ik++ )
  {
   histo[ik] /= num_pts;
  }

 /* Calculate the entropy of the frequency histogram: Equation (3) */
 entropy = 0.0;
 for ( ik = 0; ik < num_bins; ik++ )
  {
   if ( histo[ik] > 0.0 )
    {
     entropy -= histo[ik] * log ( histo[ik] );
    }
  }

 rdm->entropy = entropy;

 /* # points in each boundary segment (L) */
 seg_len = ( int ) ceil ( num_pts / num_segs );

 /* Duplicate the first radial distance value at the end */
 rad_dist[num_pts] = rad_dist[0];

 /* Calculate the roughness measure: Equation (5) */
 total_roughness = 0.0;
 num_segs = 0;			/* NUM_PTS might not be an exact multiple of NUM_SEGS */
 /* For each boundary segment */
 for ( ik = 0; ik < num_pts; ik += seg_len )
  {
   seg_roughness = 0.0;		/* Segment roughness */
   /* Traverse the segment points */
   for ( is = ik; is < ik + seg_len; is++ )
    {
     seg_roughness += fabs ( rad_dist[is] - rad_dist[is + 1] );
    }

   total_roughness += seg_roughness;
   num_segs++;
  }

 /* Mean boundary roughness */
 rdm->roughness = total_roughness / num_segs;

 free ( rad_dist );
 free ( histo );

 return rdm;
}

/** 
 * @brief Calculates the Chord Length Statistics of an object
 *
 * @param[in] cont Contour pointer for the object
 *
 * @return Pointer to the Chord Length Statistics or NULL
 *
 * @ref 1) You Z. and Jain A.K. (1984) "Performance Evaluation of Shape Matching 
 *         via Chord Length Distribution" CVGIP, 28: 185-198.
 *      2) Rangayyan R.M. (2005) "Biomedical Image Analysis" CRC Press 
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

ChordLenStats *
calc_chord_len_stats ( const PointList * cont )
{
 SET_FUNC_NAME ( "calc_chord_len_stats" );
 int ik;
 int aa, bb;
 int num_pts;
 int num_chords;
 int index;
 double max_len;
 double mean, variance, skewness, kurtosis;
 double dispersion;
 double *chord_len;
 ChordLenStats *stats;

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", NULL );
  }

 num_pts = get_num_pts ( cont );

 stats = CALLOC_STRUCT ( ChordLenStats );

 num_chords = num_pts * ( num_pts - 1 ) / 2;
 chord_len = ( double * ) malloc ( num_chords * sizeof ( double ) );
 if ( IS_NULL ( chord_len ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Calculate the lengths of the n(n-1)/2 unique chords */
 index = 0;
 max_len = DBL_MIN;
 for ( aa = 0; aa < num_pts; aa++ )
  {
   for ( bb = aa + 1; bb < num_pts; bb++ )
    {
     chord_len[index] = L2_DIST_2D ( cont->point[aa]->row, cont->point[aa]->col,
				     cont->point[bb]->row,
				     cont->point[bb]->col );

     if ( max_len < chord_len[index] )
      {
       max_len = chord_len[index];
      }

     index++;
    }
  }

 /* Normalize the lengths and calculate their mean */
 mean = 0.0;
 for ( ik = 0; ik < num_chords; ik++ )
  {
   chord_len[ik] /= max_len;
   mean += chord_len[ik];
  }

 mean /= num_chords;

 /* Calculate variance, skewness, kurtosis */
 variance = skewness = kurtosis = 0.0;
 for ( ik = 0; ik < num_chords; ik++ )
  {
   dispersion = ( chord_len[ik] - mean ) * ( chord_len[ik] - mean );
   variance += dispersion;
   skewness += dispersion * ( chord_len[ik] - mean );
   kurtosis += dispersion * dispersion;
  }

 variance /= num_chords;
 skewness /= ( num_chords * variance * sqrt ( variance ) );
 kurtosis /= ( num_chords * variance * variance );

 stats->mean = mean;
 stats->variance = variance;
 stats->skewness = skewness;
 stats->kurtosis = kurtosis;

 free ( chord_len );

 return stats;
}
