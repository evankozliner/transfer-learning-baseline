
/** 
 * @file edge_advanced.c
 * Routines for Canny and Deriche Edge Detectors
 */

#include <image.h>

/* canny_deriche.c */
extern int Extract_Gradient_Maxima_2D ( void *bufferIn, bufferType typeIn,
					void *bufferOut, bufferType typeOut,
					int *bufferDims, int *borderLengths,
					float *filterCoefs,
					recursiveFilterType filterType );

/* connexe.c */
extern int HysteresisThresholding ( void *bufferIn, bufferType typeIn,
				    void *bufferOut, bufferType typeOut,
				    int *bufferDims, double lowThreshold,
				    double highThreshold );

#define CANNY 0
#define DERICHE 1

static void
calc_hysteresis_thresholds ( const float *grad_data, const int num_pixels,
			     const double low, const double high,
			     double *low_val, double *high_val )
{
 int ih, ik;
 int num_pass;
 int index;
 int *histo;
 float value;

 histo = ( int * ) calloc ( NUM_GRAY, sizeof ( int ) );

 /* Calculate the edge magnitude histogram */
 for ( ik = 0; ik < num_pixels; ik++ )
  {
   value = grad_data[ik];
   if ( value > 0.0f )
    {
     index = value + 0.5;	/* round */
     if ( index > MAX_GRAY )
      {
       index = MAX_GRAY;
      }

     histo[index]++;
    }
  }

 /* Calculate the cumulative edge magnitude histogram */
 histo[0] = 0;
 for ( ih = 1; ih < NUM_GRAY; ih++ )
  {
   histo[ih] += histo[ih - 1];
  }

 /* Number of pixels that pass the non-maximum suppression */
 num_pass = histo[MAX_GRAY] * high + 0.5;	/* round */

 /* Calculate the high and low values */
 *low_val = 0;
 *high_val = MAX_GRAY;
 for ( ih = 1; ih < NUM_GRAY; ih++ )
  {
   if ( histo[ih] >= num_pass )
    {
     *high_val = ih - 1;
     *low_val = *high_val * low;
     break;
    }
  }

 free ( histo );
}

static Image *
detect_edge_advanced ( const Image * in_img, const double blur_factor,
		       const double low, const double high, const int method )
{
 SET_FUNC_NAME ( "detect_edge_advanced" );
 byte *in_data;
 byte *edge_data;
 int num_rows, num_cols;
 int num_pixels;
 int buffer_dim[3];
 int border_len[3] = { 10, 10, 10 };
 float filt_coef[3];
 float *grad_data;
 double low_val, high_val;
 recursiveFilterType filt_type;
 Image *edge_img;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( method == CANNY )
  {
   if ( blur_factor < 0.1 )
    {
     ERROR ( "Sigma ( %f ) must be >= 0.1 !", blur_factor );
     return NULL;
    }

   filt_type = GAUSSIAN_DERICHE;
  }
 else
  {
   if ( blur_factor < 0.1 || blur_factor > 1.9 )
    {
     ERROR ( "Alpha ( %f ) must be in [0.1,1.9] !", blur_factor );
     return NULL;
    }

   filt_type = ALPHA_DERICHE;
  }

 if ( IS_NEG ( low ) || low >= high || high >= 1.0 )
  {
   ERROR ( "Thresholds must satisfy 0.0 <= low ( %f ) <= high ( %f ) < 1.0 !",
	   low, high );
   return NULL;
  }

 filt_coef[0] = filt_coef[1] = filt_coef[2] = ( float ) blur_factor;

 buffer_dim[1] = num_rows = get_num_rows ( in_img );
 buffer_dim[0] = num_cols = get_num_cols ( in_img );
 buffer_dim[2] = 1;
 num_pixels = num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 grad_data = ( float * ) malloc ( num_pixels * sizeof ( float ) );
 if ( IS_NULL ( grad_data ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 if ( Extract_Gradient_Maxima_2D
      ( in_data, UCHAR, grad_data, FLOAT, buffer_dim, border_len, filt_coef,
	filt_type ) == 0 )
  {
   ERROR_RET ( "Gradient maxima extraction failed !", NULL );
  }

 calc_hysteresis_thresholds ( grad_data, num_pixels, low, high, &low_val,
			      &high_val );

 edge_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( edge_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 edge_data = get_img_data_1d ( edge_img );

 if ( HysteresisThresholding
      ( grad_data, FLOAT, edge_data, UCHAR, buffer_dim, low_val,
	high_val ) < 0 )
  {
   ERROR_RET ( "Hysteresis thresholding failed !", NULL );
  }

 out_img = threshold_img ( edge_img, 1 );

 free ( grad_data );
 free_img ( edge_img );

 return out_img;
}

/** 
 * @brief Implements the Canny Edge Detector
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] sigma Standard deviation of the Gaussian filter { 0.1 <= }
 * @param[in] low Low threshold { 0 <= low <= high < 1 }
 * @param[in] high High threshold { 0 <= low <= high < 1 }
 *
 * @return Pointer to the binary edge image or NULL
 *
 * @ref Canny J.F. (1986) "A Computational Approach to Edge Detection" IEEE
 *      Trans. on Pattern Analysis and Machine Intelligence, 8(6): 679-698
 *
 * @author Gregoire Malandain
 * @date 02.10.2008
 */

Image *
detect_edge_canny ( const Image * in_img, const double sigma, const double low,
		    const double high )
{
 return detect_edge_advanced ( in_img, sigma, low, high, CANNY );
}

/** 
 * @brief Implements the Deriche Edge Detector
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] alpha Alpha parameter { 0.1 <= alpha <= 1.9 }
 * @param[in] low Low threshold { 0 <= low <= high < 1 }
 * @param[in] high High threshold { 0 <= low <= high < 1 }
 *
 * @return Pointer to the binary edge image or NULL
 *
 * @ref 1) Deriche R. (1987) "Using Canny's Criteria to Derive a Recursively 
 *         Implemented Optimal Edge Detector" Int. J. Computer Vision, 1(2): 167-187
 *      2) Monga O, Deriche R., Malandain G., and Cocquerez J.P. (1991) "Recursive 
 *         Filtering and Edge Tracking: Two Primary Tools for 3-D Edge Detection"
 *         Image and Vision Computing, 4(9): 203-214
 *      3) Deriche R. (1992) "Recursively Implementing the Gaussian and its Derivatives"
 *         Proc. of the IEEE ICIP'92 Conf., pp. 263-267
 *
 * @author Gregoire Malandain
 * @date 02.10.2008
 */

Image *
detect_edge_deriche ( const Image * in_img, const double alpha,
		      const double low, const double high )
{
 return detect_edge_advanced ( in_img, alpha, low, high, DERICHE );
}

#undef CANNY
#undef DERICHE
