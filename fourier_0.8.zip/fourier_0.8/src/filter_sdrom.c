
/** 
 * @file filter_sdrom.c
 * Routines for SDROM (Signal-Dependent Rank-Ordered Mean) filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the SDROM (Signal-Dependent Rank-Ordered Mean) filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] t0 Threshold 0 { positive }
 * @param[in] t1 Threshold 1 { t0 < }
 * @param[in] t2 Threshold 2 { t1 < }
 * @param[in] t3 Threshold 3 { t2 < }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note 1) Filtering window is taken as 3x3.
 *       2) Pixels outside the convolution area are set to 0.
 * @reco The authors recommend T0 = { 4, 8, 12 }, T1 = { 15, 20, 25 },
 *       T2 = 40, and T3 = 50. They also mention that there is no need
 *       to consider values outside the following intervals: T0 <= 15, 
 *       15 <= T1 <= 25, 30 <= T2 <= 50, and 40 <= T3 <= 60.
 *
 * @ref Abreu E., Lightstone M., Mitra S.K., and Arakawa K. (1996) "A New Efficient 
 *      Approach for the Removal of Impulse Noise from Highly Corrupted Images" 
 *      IEEE Trans. on Image Processing, 5(6): 1012-1025
 *
 * @author M. Emre Celebi
 * @date 07.14.2007
 */

Image *
filter_sdrom ( const Image * in_img, const int t0, const int t1, const int t2,
	       const int t3 )
{
 SET_FUNC_NAME ( "filter_sdrom" );
 byte *win_data;		/* stores the pixels in a particular window position */
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 const int win_size = 3;
 int half_win;
 int ir, ic;
 int is, js;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int sort_key;
 int rom_val;
 int center_val;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !( 0 < t0 && t0 < t1 && t1 < t2 && t2 < t3 ) )
  {
   ERROR
    ( "Thresholds ( %d, %d, %d, %d ) must be a positive and increasing sequence !",
      t0, t1, t2, t3 );
   return NULL;
  }

 half_win = win_size / 2;
 win_data = ( byte * ) calloc ( 8, sizeof ( byte ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 win_data[count++] = in_data[iwr][iwc];
	}
      }

     /* Save the center pixel value */
     center_val = win_data[4];

     /* 
        Move the last pixel to the position of the center pixel.
        In the remainder of the code, the window size will be 
        taken as 8. This effectively excludes the center pixel.
      */
     win_data[4] = win_data[8];

     /* Sort the pixels (excluding the center) using Insertion sort: Equation (3) */
     for ( js = 1; js < 8; win_data[is + 1] = sort_key, js++ )
      {
       for ( sort_key = win_data[js], is = js - 1;
	     is >= 0 && win_data[is] > sort_key;
	     win_data[is + 1] = win_data[is], is-- )
	{
	 /* Empty body */ ;
	}
      }

     /* Rank-Ordered Mean (ROM): Equation (4) */
     rom_val = 0.5 * ( win_data[3] + win_data[4] );

     /* 
        Equation (5) & (6) with alpha(1)=0 and alpha(2)=1:
        Compute the rank-ordered differences and compare 
        them with the thresholds. If any of the differences
        exceeds its respective threshold, replace the center 
        pixel with ROM_VAL; otherwise leave it unchanged.
      */
     if ( center_val <= rom_val )
      {
       if ( ( ( win_data[0] - center_val ) < t0 ) &&
	    ( ( win_data[1] - center_val ) < t1 ) &&
	    ( ( win_data[2] - center_val ) < t2 ) &&
	    ( ( win_data[3] - center_val ) < t3 ) )
	{
	 out_data[ir][ic] = center_val;
	}
       else
	{
	 out_data[ir][ic] = rom_val;
	}
      }
     else
      {
       if ( ( ( center_val - win_data[7] ) < t0 ) &&
	    ( ( center_val - win_data[6] ) < t1 ) &&
	    ( ( center_val - win_data[5] ) < t2 ) &&
	    ( ( center_val - win_data[4] ) < t3 ) )
	{
	 out_data[ir][ic] = center_val;
	}
       else
	{
	 out_data[ir][ic] = rom_val;
	}
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}
