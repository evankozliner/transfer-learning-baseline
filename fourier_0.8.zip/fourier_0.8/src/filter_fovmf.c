
/** 
 * @file filter_fovmf.c
 * Routines for FOVMF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the FOVMF (Fuzzy Ordered Vector Median Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] beta Controls the fuzziness of the weights
 * @param[in] gamma Controls the fuzziness of the weights
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco The authors recommend BETA = 1.0 and GAMMA = 0.5
 *
 * @ref 1) Plataniotis K.N., Androutsos D., and Venetsanopoulos A.N. (1999) 
 *         "Adaptive Fuzzy Systems for Multichannel Signal Processing" Proc. 
 *         of the IEEE, 87(9): 1601-1622
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
filter_fovmf ( const Image * in_img, const int win_size, const double beta,
	       const double gamma )
{
 SET_FUNC_NAME ( "filter_fovmf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int idx_key;
 int begin_idx, end_idx;
 int *red, *green, *blue;
 int *weight_index;
 double tot_weight_sum;
 double dist_sum;
 double threshold;
 double data_key;
 double par_weight_sum;
 double red_out, green_out, blue_out;
 double *weight;
 double **dist_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;
 begin_idx = win_count - 1;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 weight_index = ( int * ) malloc ( win_count * sizeof ( int ) );
 weight = ( double * ) malloc ( win_count * sizeof ( double ) );

 dist_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the distances between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_mat[iwr][iwc] = DIST_FUNC ( red[iwr], green[iwr], blue[iwr],
					  red[iwc], green[iwc], blue[iwc] );
	}
      }

     /* 
        Calculate the distance sums for each pixel 
        and determine the fuzzy weights accordingly. 
      */

     tot_weight_sum = 0.0;

     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       weight_index[iwr] = iwr;

       dist_sum = 0.0;
       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 dist_sum += dist_mat[iwc][iwr];
	}

       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_sum += dist_mat[iwr][iwc];
	}

       /* Warning: Don't normalize DIST_SUM */
       weight[iwr] = exp ( pow ( dist_sum, gamma ) / -beta );

       tot_weight_sum += weight[iwr];
      }

     if ( tot_weight_sum > 0.0 )
      {
       /* Adaptive threshold */
       threshold = tot_weight_sum / ( double ) win_count;

       /* Sort the pixels according to their fuzzy weights (preserve indices) */
       for ( iwc = 1; iwc < win_count;
	     weight[iwr + 1] = data_key, weight_index[iwr + 1] =
	     idx_key, iwc++ )
	{
	 for ( data_key = weight[iwc], idx_key = iwc, iwr = iwc - 1;
	       iwr >= 0 && weight[iwr] > data_key;
	       weight[iwr + 1] = weight[iwr], weight_index[iwr + 1] =
	       weight_index[iwr], iwr-- );
	}

       par_weight_sum = 0.0;	/* Summation of the weights that are greater than the threshold */
       end_idx = 0;
       for ( iwr = begin_idx; iwr >= 0; iwr-- )
	{
	 if ( weight[iwr] < threshold )
	  {
	   end_idx = iwr + 1;
	   break;
	  }
	 else
	  {
	   par_weight_sum += weight[iwr];
	  }
	}

       /* Shouldn't happen: All of the weights are less than 1.0 / WIN_COUNT */
       if ( begin_idx < end_idx )
	{
	 out_data[ir][ic][0] = red[center_pix];
	 out_data[ir][ic][1] = green[center_pix];
	 out_data[ir][ic][2] = blue[center_pix];
	}
       else
	{
	 red_out = green_out = blue_out = 0.0;
	 for ( iwr = begin_idx; iwr >= end_idx; iwr-- )
	  {
	   weight[iwr] /= par_weight_sum;	/* Normalize the weights */

	   /* 
	      The output vector is the fuzzy weighted
	      linear combination of the input vectors 
	    */

	   red_out += weight[iwr] * red[weight_index[iwr]];
	   green_out += weight[iwr] * green[weight_index[iwr]];
	   blue_out += weight[iwr] * blue[weight_index[iwr]];
	  }

	 out_data[ir][ic][0] = red_out + .5;	/* round */
	 out_data[ir][ic][1] = green_out + .5;	/* round */
	 out_data[ir][ic][2] = blue_out + .5;	/* round */
	}
      }
     else			/* The window contains nothing but black pixels */
      {
       out_data[ir][ic][0] = red[center_pix];
       out_data[ir][ic][1] = green[center_pix];
       out_data[ir][ic][2] = blue[center_pix];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( weight_index );
 free ( weight );
 free_nd ( dist_mat, 2 );

 return out_img;
}
