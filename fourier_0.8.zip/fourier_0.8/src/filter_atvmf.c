
/** 
 * @file filter_atvmf.c
 * Routines for ATVMF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the ATVMF (Alpha-Trimmed Vector Median Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] k_value Number of window pixels that participate in the averaging { [1, WIN_SIZE^2] } 
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 *
 * @ref 1) Viero T., Oistamo K., and Neuvo Y. (1994) "Three-Dimensional Median-Related 
 *         Filters for Color Image Sequence Filtering" IEEE Trans. on Circuits and Systems 
 *         for Video Technology, 4(2): 129-142
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *
 * @author M. Emre Celebi
 * @date 08.06.2007
 */

Image *
filter_atvmf ( const Image * in_img, const int win_size, const int k_value )
{
 SET_FUNC_NAME ( "filter_atvmf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int idx_key;
 int red_sum, green_sum, blue_sum;
 int *red, *green, *blue;
 int *dist_index;
 double data_key;
 double *dist_sum;
 double **dist_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( ( k_value <= 0 ) || ( k_value > win_size * win_size ) )
  {
   ERROR ( "K value ( %d ) must be in [1, %d] range !", k_value,
	   win_size * win_size );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 dist_index = ( int * ) malloc ( win_count * sizeof ( int ) );
 dist_sum = ( double * ) malloc ( win_count * sizeof ( double ) );

 dist_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the distances between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_mat[iwr][iwc] = DIST_FUNC ( red[iwr], green[iwr], blue[iwr],
					  red[iwc], green[iwc], blue[iwc] );
	}
      }

     /* Calculate the cumulative distance for each pixel */
     memset ( dist_sum, 0, win_count * sizeof ( double ) );

     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       dist_index[iwr] = iwr;

       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 dist_sum[iwr] += dist_mat[iwc][iwr];
	}

       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_sum[iwr] += dist_mat[iwr][iwc];
	}
      }

     /* Sort the pixels according to their cumulative distances (preserve indices) */
     for ( iwc = 1; iwc < win_count;
	   dist_sum[iwr + 1] = data_key, dist_index[iwr + 1] = idx_key, iwc++ )
      {
       for ( data_key = dist_sum[iwc], idx_key = iwc, iwr = iwc - 1;
	     iwr >= 0 && dist_sum[iwr] > data_key;
	     dist_sum[iwr + 1] = dist_sum[iwr], dist_index[iwr + 1] =
	     dist_index[iwr], iwr-- );
      }

     /* Calculate the average of the lowest-ranked K_VALUE vectors */
     red_sum = green_sum = blue_sum = 0;
     for ( iwr = 0; iwr < k_value; iwr++ )
      {
       red_sum += red[dist_index[iwr]];
       green_sum += green[dist_index[iwr]];
       blue_sum += blue[dist_index[iwr]];
      }

     out_data[ir][ic][0] = red_sum / ( double ) k_value;
     out_data[ir][ic][1] = green_sum / ( double ) k_value;
     out_data[ir][ic][2] = blue_sum / ( double ) k_value;

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( dist_index );
 free ( dist_sum );
 free_nd ( dist_mat, 2 );

 return out_img;
}
