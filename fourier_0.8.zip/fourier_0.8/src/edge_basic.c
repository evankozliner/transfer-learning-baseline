
/** 
 * @file edge_basic.c
 * Routines for Roberts, Prewitt, Sobel, and LoG Edge Detectors
 */

#include <image.h>

#define ROBERTS 0
#define PREWITT 1
#define SOBEL   2

#define SUM_SQR( A, B ) ( ( A ) * ( A ) + ( B ) * ( B ) )

#define EDGE_ROBERTS( )\
r_begin = c_begin = 0;\
for ( ir = r_begin; ir < r_end; ir++ )\
 {\
  for ( ic = c_begin; ic < c_end; ic++ )\
   {\
    /* Row gradient */\
    row_grad = in_data[ir][ic] - in_data[ir + 1][ic + 1];\
    /* Column gradient */\
    col_grad = in_data[ir][ic + 1] - in_data[ir + 1][ic];\
    /* Mean of squared gradient magnitudes */\
    mean += ( grad_mag[ir][ic] = SUM_SQR ( row_grad, col_grad ) );\
   }\
 }\
mean /= ( r_end * c_end );\
factor = 6;\

#define EDGE_PREWITT( )\
r_begin = c_begin = 1;\
for ( ir = r_begin; ir < r_end; ir++ )\
 {\
  for ( ic = c_begin; ic < c_end; ic++ )\
   {\
    /* Row gradient */\
    row_grad = ( in_data[ir + 1][ic - 1] + in_data[ir + 1][ic + 1] ) -\
	       ( in_data[ir - 1][ic - 1] + in_data[ir - 1][ic + 1] ) +\
	       ( in_data[ir + 1][ic] - in_data[ir - 1][ic] );\
    /* Column gradient */\
    col_grad = ( in_data[ir - 1][ic + 1] + in_data[ir + 1][ic + 1] ) -\
	       ( in_data[ir - 1][ic - 1] + in_data[ir + 1][ic - 1] ) +\
	       ( in_data[ir][ic + 1] - in_data[ir][ic - 1] );\
    /* Mean of squared gradient magnitudes */\
    mean += ( grad_mag[ir][ic] = SUM_SQR ( row_grad, col_grad ) );\
   }\
 }\
mean /= ( ( r_end - 1 ) * ( c_end - 1 ) );\
factor = 4;\

#define EDGE_SOBEL( )\
r_begin = c_begin = 1;\
for ( ir = r_begin; ir < r_end; ir++ )\
 {\
  for ( ic = c_begin; ic < c_end; ic++ )\
   {\
    /* Row gradient */\
    row_grad = ( in_data[ir + 1][ic - 1] + in_data[ir + 1][ic + 1] ) -\
	       ( in_data[ir - 1][ic - 1] + in_data[ir - 1][ic + 1] ) +\
	       2 * ( in_data[ir + 1][ic] - in_data[ir - 1][ic] );\
    /* Column gradient */\
    col_grad = ( in_data[ir - 1][ic + 1] + in_data[ir + 1][ic + 1] ) -\
	       ( in_data[ir - 1][ic - 1] + in_data[ir + 1][ic - 1] ) +\
	       2 * ( in_data[ir][ic + 1] - in_data[ir][ic - 1] );\
    /* Mean of squared gradient magnitudes */\
    mean += ( grad_mag[ir][ic] = SUM_SQR ( row_grad, col_grad ) );\
   }\
 }\
mean /= ( ( r_end - 1 ) * ( c_end - 1 ) );\
factor = 4;\

static Image *
detect_edge_basic ( const Image * in_img, const int method )
{
 SET_FUNC_NAME ( "detect_edge_basic" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int ir, ic;
 int r_begin, c_begin;
 int r_end, c_end;
 int row_grad, col_grad;
 int factor;
 int threshold;
 int **grad_mag;
 double mean;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );
 grad_mag = alloc_nd ( sizeof ( int ), 2, num_rows, num_cols );

 r_end = num_rows - 1;
 c_end = num_cols - 1;
 mean = 0.0;

 /* Perform the convolution */
 if ( method == ROBERTS )
  {
   EDGE_ROBERTS (  );
  }
 else if ( method == PREWITT )
  {
   EDGE_PREWITT (  );
  }
 else				/* method == SOBEL */
  {
   EDGE_SOBEL (  );
  }

 /* Calculate the threshold */
 threshold = ( int ) ROUND ( factor * mean );

 /* Threshold the squared gradient magnitudes */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     out_data[ir][ic] = grad_mag[ir][ic] > threshold ? OBJECT : BACKGROUND;
    }
  }

 free ( grad_mag );

 return out_img;
}

#undef EDGE_ROBERTS
#undef EDGE_PREWITT
#undef EDGE_SOBEL

/** 
 * @brief Implements the Roberts Edge Detector
 *
 * @param[in] in_img Image pointer { grayscale }
 *
 * @return Pointer to the binary edge image or NULL
 *
 * @ref Umbaugh S.E. (2005) "Computer Imaging: Digital Image 
 *      Analysis and Processing" CRC Press
 *
 * @author M. Emre Celebi
 * @date 02.10.2008
 */

Image *
detect_edge_roberts ( const Image * in_img )
{
 return detect_edge_basic ( in_img, ROBERTS );
}

/** 
 * @brief Implements the Prewitt Edge Detector
 *
 * @param[in] in_img Image pointer { grayscale }
 *
 * @return Pointer to the binary edge image or NULL
 *
 * @ref Umbaugh S.E. (2005) "Computer Imaging: Digital Image 
 *      Analysis and Processing" CRC Press
 *
 * @author M. Emre Celebi
 * @date 02.10.2008
 */

Image *
detect_edge_prewitt ( const Image * in_img )
{
 return detect_edge_basic ( in_img, PREWITT );
}

/** 
 * @brief Implements the Sobel Edge Detector
 *
 * @param[in] in_img Image pointer { grayscale }
 *
 * @return Pointer to the binary edge image or NULL
 *
 * @ref Umbaugh S.E. (2005) "Computer Imaging: Digital Image 
 *      Analysis and Processing" CRC Press
 *
 * @author M. Emre Celebi
 * @date 02.10.2008
 */

Image *
detect_edge_sobel ( const Image * in_img )
{
 return detect_edge_basic ( in_img, SOBEL );
}

#undef ROBERTS
#undef PREWITT
#undef SOBEL

static double **
create_log_mask ( const int win_size, const double stdev )
{
 int ir, ic;
 int half_win;
 int num_pixels;
 double var;
 double var_t2;
 double var_sq;
 double mask_sum;
 double mask_mean;
 double **mask;

 half_win = win_size / 2;
 num_pixels = win_size * win_size;
 var = stdev * stdev;
 var_t2 = 2.0 * var;
 var_sq = var * var;

 mask = alloc_nd ( sizeof ( double ), 2, win_size, win_size );

 /* Calculate the Gaussian */
 mask_sum = 0.0;
 for ( ir = -half_win; ir <= half_win; ir++ )
  {
   for ( ic = -half_win; ic <= half_win; ic++ )
    {
     mask_sum += ( mask[ir + half_win][ic + half_win] =
		   exp ( -SUM_SQR ( ir, ic ) / var_t2 ) );
    }
  }

 /* Normalize the coefficients so that they add up to 1.0 */
 if ( !IS_ZERO ( mask_sum ) )
  {
   for ( ir = -half_win; ir <= half_win; ir++ )
    {
     for ( ic = -half_win; ic <= half_win; ic++ )
      {
       mask[ir + half_win][ic + half_win] /= mask_sum;
      }
    }
  }

 /* Calculate the Laplacian of Gaussian */
 mask_sum = 0.0;
 for ( ir = -half_win; ir <= half_win; ir++ )
  {
   for ( ic = -half_win; ic <= half_win; ic++ )
    {
     mask_sum += ( mask[ir + half_win][ic + half_win] *=
		   ( SUM_SQR ( ir, ic ) - var_t2 ) / var_sq );
    }
  }

 mask_mean = mask_sum / num_pixels;

 /* Normalize the coefficients so that they add up to 0.0 */
 for ( ir = -half_win; ir <= half_win; ir++ )
  {
   for ( ic = -half_win; ic <= half_win; ic++ )
    {
     mask[ir + half_win][ic + half_win] -= mask_mean;
    }
  }

 return mask;
}

/** 
 * @brief Implements the LoG (Laplacian of Gaussian) Edge Detector
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] sigma Standard deviation of the Gaussian filter { positive }
 *
 * @return Pointer to the binary edge image or NULL
 *
 * @ref Umbaugh S.E. (2005) "Computer Imaging: Digital Image 
 *      Analysis and Processing" CRC Press
 *
 * @author M. Emre Celebi
 * @date 02.10.2008
 */

Image *
detect_edge_log ( const Image * in_img, const double sigma )
{
 SET_FUNC_NAME ( "detect_edge_log" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int win_size;
 int half_win;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;
 int c_begin, c_end;
 int wr_begin, wr_end;
 int wc_begin, wc_end;
 double conv_res;		/* convolution result in a particular neighborhood */
 double mean;			/* mean of the convolution results */
 double threshold;		/* automatic threshold */
 double center_val;
 double **mask;			/* LoG mask */
 double **conv_data;		/* convolution data */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS ( sigma ) )
  {
   ERROR ( "Sigma ( %f ) must be positive !", sigma );
   return NULL;
  }

 win_size = 1 + 2 * ( int ) ceil ( 3.0 * sigma );
 half_win = win_size / 2;

 /* Calculate the LoG mask */
 mask = create_log_mask ( win_size, sigma );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 conv_data = alloc_nd ( sizeof ( double ), 2, num_rows, num_cols );
 if ( IS_NULL ( conv_data ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* Perform the convolution */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 wr_begin = 0;
 wr_end = win_size;

 mean = 0.0;

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   wc_begin = 0;
   wc_end = win_size;

   for ( ic = c_begin; ic < c_end; ic++ )
    {
     conv_res = 0.0;

     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 conv_res += in_data[iwr][iwc] * mask[iwr - wr_begin][iwc - wc_begin];
	}
      }

     /* Save the convolution result */
     conv_data[ir][ic] = conv_res;

     /* Accumulate the absolute value of the convolution result */
     mean += fabs ( conv_res );

     wc_begin++;
     wc_end++;
    }

   wr_begin++;
   wr_end++;
  }

 mean /= ( r_end - r_begin ) * ( c_end - c_begin );

 /* Calculate the threshold */
 threshold = 0.75 * mean;

 /* Determine the zero-crossings where the edge strength is greater than THRESHOLD */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     center_val = conv_data[ir][ic];
     if ( IS_NEG ( center_val ) )
      {
       if ( ( IS_POS ( conv_data[ir][ic + 1] ) &&
	      fabs ( center_val - conv_data[ir][ic + 1] ) > threshold ) ||
	    ( IS_POS ( conv_data[ir][ic - 1] ) &&
	      fabs ( conv_data[ir][ic - 1] - center_val ) > threshold ) ||
	    ( IS_POS ( conv_data[ir + 1][ic] ) &&
	      fabs ( center_val - conv_data[ir + 1][ic] ) > threshold ) ||
	    ( IS_POS ( conv_data[ir - 1][ic] ) &&
	      fabs ( conv_data[ir - 1][ic] - center_val ) > threshold ) )
	{
	 out_data[ir][ic] = OBJECT;
	}
      }
    }
  }

 free_nd ( mask, 2 );
 free_nd ( conv_data, 2 );

 return out_img;
}
