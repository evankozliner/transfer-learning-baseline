
/** 
 * @file filter_bvdf.c
 * Routines for BVDF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the BVDF (Basic Vector Directional Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 *
 * @ref 1) Trahanias P.E. and Venetsanopoulos A.N. (1993) "Vector Directional 
 *         Filters: A New Class of Multichannel Image Processing Filters" IEEE 
 *         Trans. on Image Processing, 2(4): 528-534
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *
 * @author M. Emre Celebi
 * @date 08.06.2007
 */

Image *
filter_bvdf ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_bvdf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int min_angle_index;
 int *red, *green, *blue;
 double acos_arg;
 double angle_sum;
 double min_angle;
 double *vec_len;
 double **angle_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 vec_len = ( double * ) malloc ( win_count * sizeof ( double ) );

 angle_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the vector lengths */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       vec_len[iwr] = L2_NORM_3D ( red[iwr], blue[iwr], green[iwr] );
      }

     /* Calculate the angles between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   if ( vec_len[iwc] > 0.0 )
	    {
	     /* ( dot product ) / ( || vector1 || * || vector2 || ) */
	     acos_arg =
	      ( red[iwr] * red[iwc] + green[iwr] * green[iwc] +
		blue[iwr] * blue[iwc] ) / ( vec_len[iwr] * vec_len[iwc] );

	     /* Calculate the angle between the two color vectors */
	     angle_mat[iwr][iwc] = ACOS ( acos_arg );
	    }
	   else
	    {
	     /* Idempotent value */
	     angle_mat[iwr][iwc] = 0.0;
	    }
	  }
	}
      }

     /* 
        Calculate the angle sums for each pixel and find the minimum.
        Omit the pixels with vector length 0 since their angles with 
        all the other pixels would be 0.0 automatically.
      */
     min_angle = DBL_MAX;
     min_angle_index = center_pix;
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 angle_sum = 0.0;

	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   angle_sum += angle_mat[iwc][iwr];
	  }

	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   angle_sum += angle_mat[iwr][iwc];
	  }

	 if ( angle_sum < min_angle )
	  {
	   min_angle = angle_sum;
	   min_angle_index = iwr;
	  }
	}
      }

     /* Output */
     out_data[ir][ic][0] = red[min_angle_index];
     out_data[ir][ic][1] = green[min_angle_index];
     out_data[ir][ic][2] = blue[min_angle_index];

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( vec_len );
 free_nd ( angle_mat, 2 );

 return out_img;
}
