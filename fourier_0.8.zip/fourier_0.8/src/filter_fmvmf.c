
/** 
 * @file filter_fmvmf.c
 * Routines for FMVMF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the FMVMF (Fast Modified Vector Median Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] beta Distance threshold { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco The authors recommend BETA = [0.5, 0.75]
 *
 * @ref 1) Smolka B., Szczepanski M., Plataniotis K.N., and Venetsanopoulos A.N.
 *         (2001) "Fast Modified Vector Median Filter" Proc. of the 9th Int. Conf. 
 *         on Computer Analysis of Images and Patterns, Lecture Notes in Computer 
 *         Science 2124, pp. 570-580
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
filter_fmvmf ( const Image * in_img, const int win_size, const double beta )
{
 SET_FUNC_NAME ( "filter_fmvmf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int min_dist_index;
 int *red, *green, *blue;
 double beta_scaled;
 double dist_sum;
 double dist_sum_center = 0.0;
 double min_dist;
 double **dist_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( !IS_POS ( beta ) )
  {
   ERROR ( "Distance threshold ( %f ) must be positive !", beta );
   return NULL;
  }

 /* 
    Recommended values for BETA lie in [0.5 , 0.75] for RGB values 
    normalized to [0,1]. So, multiply the BETA value by 255. Also, 
    the computations use -BETA. Therefore, premultiply it by -1.
  */
 beta_scaled = -255.0 * beta;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );

 dist_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the distances between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_mat[iwr][iwc] = DIST_FUNC ( red[iwr], green[iwr], blue[iwr],
					  red[iwc], green[iwc], blue[iwc] );
	}
      }

     /* Calculate the cumulative distance for each pixel and find the minimum */
     min_dist = DBL_MAX;
     min_dist_index = center_pix;
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       dist_sum = 0.0;

       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 dist_sum += dist_mat[iwc][iwr];
	}

       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_sum += dist_mat[iwr][iwc];
	}

       if ( iwr == center_pix )
	{
	 dist_sum_center = dist_sum;
	}
       else if ( iwr < center_pix )
	{
	 dist_sum -= dist_mat[iwr][center_pix];	/* Exclude distance to the center */
	}
       else
	{
	 dist_sum -= dist_mat[center_pix][iwr];	/* Exclude distance to the center */
	}

       if ( dist_sum < min_dist )
	{
	 min_dist = dist_sum;
	 min_dist_index = iwr;
	}
      }

     /* Center pixel noisy */
     if ( min_dist < ( dist_sum_center + beta_scaled ) )
      {
       out_data[ir][ic][0] = red[min_dist_index];
       out_data[ir][ic][1] = green[min_dist_index];
       out_data[ir][ic][2] = blue[min_dist_index];
      }
     else			/* Center pixel noise-free */
      {
       out_data[ir][ic][0] = red[center_pix];
       out_data[ir][ic][1] = green[center_pix];
       out_data[ir][ic][2] = blue[center_pix];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free_nd ( dist_mat, 2 );

 return out_img;
}
