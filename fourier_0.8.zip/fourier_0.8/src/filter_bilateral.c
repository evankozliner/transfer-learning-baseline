
/** 
 * @file filter_bilateral.c
 * Routines for Susan filtering of a grayscale image
 */

#include <image.h>

static double *calc_range_weights ( const int win_size,
				    const double range_sigma );
static double **calc_spatial_weights ( const int win_size,
				       const double spatial_sigma );

/** @cond INTERNAL_FUNCTION */

static double *
calc_range_weights ( const int win_size, const double range_sigma )
{
 int ik;
 int half_win;
 double term;
 double *range_weight;

 range_weight = ( double * ) malloc ( win_size * sizeof ( double ) );
 half_win = win_size / 2;

 term = -1.0 / ( 2.0 * range_sigma * range_sigma );
 for ( ik = -half_win; ik <= half_win; ik++ )
  {
   range_weight[ik + half_win] = exp ( ik * ik * term );
  }

 return range_weight;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

static double **
calc_spatial_weights ( const int win_size, const double spatial_sigma )
{
 int iwr, iwc;
 int half_win;
 double term;
 double **spat_weight;

 spat_weight = alloc_nd ( sizeof ( double ), 2, win_size, win_size );

 half_win = win_size / 2;
 term = -1.0 / ( 2.0 * spatial_sigma * spatial_sigma );
 for ( iwr = -half_win; iwr <= half_win; iwr++ )
  {
   for ( iwc = -half_win; iwc <= half_win; iwc++ )
    {
     spat_weight[iwr + half_win][iwc + half_win] =
      exp ( ( iwr * iwr + iwc * iwc ) * term );
    }
  }

 return spat_weight;
}

/** @endcond INTERNAL_FUNCTION */

/** 
 * @brief Implements the Bilateral filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] range_sigma Stdev of the range filter component { positive }
 * @param[in] spatial_sigma Stdev of the spatial filter component { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note 1) Pixels outside the convolution area are set to 0.
 *       2) The execution time is mainly influenced by the value of SPATIAL_SIGMA
 * @ref Tomasi C. and Manduchi R. (1998) "Bilateral Filtering for Gray and Colored Images" 
 *      Proc. of the IEEE Int. Conf. on Computer Vision, pp. 836-846
 *      http://www.soe.ucsc.edu/~manduchi/Papers/ICCV98.pdf
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_bilateral ( const Image * in_img, const double range_sigma,
		   const double spatial_sigma )
{
 SET_FUNC_NAME ( "filter_bilateral" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int r_win_size;
 int r_half_win;
 int s_win_size;
 int s_half_win;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of a window */
 int wc_begin, wc_end;		/* horizontal limits of a window */
 int center_val;
 int gray_diff;
 double c_weight;		/* combined weight = (spatial weight) * (range weight) */
 double weight_sum;		/* sum of combined weights in a window */
 double conv_sum;		/* convolution sum in a window */
 double *range_weight;		/* stores the range weights */
 double **spat_weight;		/* stores the spatial (distance) weights */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS ( range_sigma ) )
  {
   ERROR ( "Range sigma ( %f ) must be positive !", range_sigma );
   return NULL;
  }

 if ( !IS_POS ( spatial_sigma ) )
  {
   ERROR ( "Spatial sigma ( %f ) must be positive !", spatial_sigma );
   return NULL;
  }

 /* 3-sigma rule => contains 99.73002039367% of the samples */
 r_half_win = ceil ( 3.0 * range_sigma );
 r_win_size = 2 * r_half_win + 1;

 s_half_win = ceil ( 3.0 * spatial_sigma );
 s_win_size = 2 * s_half_win + 1;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* Calculate the range and spatial weights */
 range_weight = calc_range_weights ( r_win_size, range_sigma );
 spat_weight = calc_spatial_weights ( s_win_size, spatial_sigma );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = s_half_win;
 r_end = num_rows - s_half_win;
 c_begin = s_half_win;
 c_end = num_cols - s_half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = s_win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = s_win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     center_val = in_data[ir][ic];
     conv_sum = 0.0;
     weight_sum = 0.0;

     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 gray_diff = abs ( in_data[iwr][iwc] - center_val );
	 if ( gray_diff > r_half_win )
	  {
	   /* Gray value difference is out-of-range */
	   gray_diff = r_half_win;
	  }

	 c_weight = spat_weight[iwr - wr_begin][iwc - wc_begin] *
	  range_weight[r_half_win + gray_diff];
	 conv_sum += c_weight * in_data[iwr][iwc];
	 weight_sum += c_weight;
	}
      }

     out_data[ir][ic] = conv_sum / weight_sum;

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( range_weight );
 free_nd ( spat_weight, 2 );

 return out_img;
}
