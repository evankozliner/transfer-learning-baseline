
/** 
 * @file filter_sep_median.c
 * Routines for Separable Median filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Separable Median filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Narendra P.M. (1981) "A Separable Median Filter for Image Noise Smoothing"
 *      IEEE Trans. on Pattern Analysis and Machine Intelligence, 3(1): 20-29
 *
 * @author M. Emre Celebi
 * @date 02.09.2008
 */

Image *
filter_sep_median ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_sep_median" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int *row_data;			/* stores a row of a particular window position */
 int *row_med;			/* stores the median values for the window rows */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;

 row_data = ( int * ) malloc ( win_size * sizeof ( int ) );
 row_med = ( int * ) malloc ( win_size * sizeof ( int ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       count = 0;
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 row_data[count++] = in_data[iwr][iwc];
	}

       /* Find the median of the current window row */
       row_med[iwr - wr_begin] = find_median ( win_size, row_data );
      }

     /* Assign the median of the row medians to the output pixel */
     out_data[ir][ic] = find_median ( win_size, row_med );

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( row_data );
 free ( row_med );

 return out_img;
}
