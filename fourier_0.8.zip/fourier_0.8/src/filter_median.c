
/** 
 * @file filter_median.c
 * Routines for Median filtering of a grayscale image
 */

#include <image.h>

static void merge_slice ( byte * a, byte * b, byte * bc );
static byte calc_median ( byte * x, byte * bc );
void ctmf ( const unsigned char *src, unsigned char *dst, int width, int height,
	    int src_step_row, int dst_step_row, int r, int channels,
	    unsigned long memsize );

/** 
 * @brief Implements the classical median filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_classical_median ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_classical_median" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int *win_data;			/* stores the pixels in a particular window position */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;

 win_data = ( int * ) calloc ( win_count, sizeof ( int ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 win_data[count++] = in_data[iwr][iwc];
	}
      }

     /* Assign the median value to the output pixel */
     out_data[ir][ic] = find_median ( win_count, win_data );

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}

/** 
 * @brief Implements the running median filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref 1) Huang et al. (1979) "A Fast Two-Dimensional Median Filtering Algorithm"
 *         IEEE Trans. on Acoustics, Speech, and Signal Processing, 27(1): 13-18
 *      2) Glasbey C.A. and Horgan G.W. (1995) "Image Analysis for the Biological Sciences"
 *         John Wiley & Sons, Chapter 3: http://www.bioss.ac.uk/staff/chris/ch3.pdf
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_running_median ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_running_median" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int med_val;			/* median value */
 int med_idx;			/* index of the median value */
 int lt_med;			/* number of pixels in the histogram with a value less than the median */
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 size_t histo_bytes;		/* histogram size in number of bytes */
 int *histo;			/* histogram of a particular window position */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;
 med_idx = win_count / 2;

 /* 
    Note that this is a local histogram. So,
    we don't need to use the Histo structure.
  */
 histo_bytes = NUM_GRAY * sizeof ( int );
 histo = ( int * ) malloc ( histo_bytes );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win + 1;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Reset the histogram */
   memset ( histo, 0, histo_bytes );

   /* Calculate the histogram for the first window of the current row */
   for ( iwr = wr_begin; iwr < wr_end; iwr++ )
    {
     for ( iwc = 0; iwc < win_size; iwc++ )
      {
       histo[in_data[iwr][iwc]]++;
      }
    }

   /* 
      Calculate the median of the first window. Determine the 
      number of pixels having gray value less than the median.
    */
   med_val = 0;
   lt_med = 0;
   do
    {
     lt_med += histo[med_val++];
    }
   while ( lt_med + histo[med_val] <= med_idx );

   /* Assign the median value to the output pixel */
   out_data[ir][half_win] = med_val;

   /* For the rest of the current row */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Update the histogram and the median value */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       if ( in_data[iwr][ic - c_begin] < med_val )
	{
	 lt_med--;
	}
       if ( in_data[iwr][ic + half_win] < med_val )
	{
	 lt_med++;
	}

       histo[in_data[iwr][ic - c_begin]]--;
       histo[in_data[iwr][ic + half_win]]++;
      }

     if ( med_idx < lt_med )
      {
       do
	{
	 lt_med -= histo[--med_val];
	}
       while ( lt_med > med_idx );
      }
     else
      {
       while ( lt_med + histo[med_val] <= med_idx )
	{
	 lt_med += histo[med_val++];
	}
      }

     /* Assign the median value to the output pixel */
     out_data[ir][ic] = med_val;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( histo );

 return out_img;
}

/** @cond INTERNAL_FUNCTION */

static void
merge_slice ( byte * a, byte * b, byte * bc )
{
 int i, j, k;

 j = k = 0;
 for ( i = 0; i < 6; i++ )
  {
   if ( j > 2 )
    {
     bc[i] = b[k++];
    }
   else if ( k > 2 )
    {
     bc[i] = a[j++];
    }
   else
    {
     bc[i] = ( a[j] < b[k] ) ? a[j++] : b[k++];
    }
  }
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

static byte
calc_median ( byte * x, byte * bc )
{
 int i, j, k, m;

 j = 0;
 k = 1;
 for ( i = 0; i < 4; i++ )
  {
   if ( j > 2 )
    {
     m = bc[k++];
    }
   else
    {
     m = ( x[j] < bc[k] ) ? x[j++] : bc[k++];
    }
  }

 return m;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_MACRO */
#define SWAP_SLICE(a, b) { tmp_ptr = ( b ); ( b ) = ( a ); ( a ) = tmp_ptr; }

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */
#define SORT_BYTE(a, b) { if ( ( a ) > ( b ) ) { tmp_var = ( a ); ( a ) = ( b ); ( b ) = tmp_var; }  }

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */
#define SORT_SLICE( s ) { SORT_BYTE( s[0], s[1] ); SORT_BYTE( s[1], s[2] ); SORT_BYTE( s[0], s[1] ); }

/** @endcond INTERNAL_MACRO */

/** 
 * @brief Implements the fast 3x3 median filter
 *
 * @param[in] in_img Image pointer { grayscale }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Kopp M. and Purgathofer W. (1994) "Efficient 3x3 Median Filter Computations"
 *      Technical Report TR-186-2-94-18, Institute of Computer Graphics and Algorithms,
 *      Vienna University of Technology:
 *      http://www.cg.tuwien.ac.at/research/publications/1994/Kopp-1994-EMF/TR-186-2-94-18Paper.pdf
 *
 * @author Manfred Kopp
 * @date 06.18.2007
 */

Image *
filter_3x3_median ( const Image * in_img )
{
 SET_FUNC_NAME ( "filter_3x3_median" );
 byte tmp_var;			/* temporary variable used in the SORT_BYTE macro */
 byte _a[3], _b[3], _c[3], _d[3], bc[6];
 byte *tmp_ptr;			/* temporary pointer used in the SWAP_SLICE macro */
 byte *a, *b, *c, *d;
 byte **in_data;
 byte **out_data;
 int ir, ic;
 int num_rows, num_cols;
 int r_end, c_end;		/* horizontal and vertical limits of the filtering operation */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_end = num_rows - 1;
 c_end = num_cols - 1;

 /* For each image row */
 for ( ir = 1; ir < r_end; ir++ )
  {
   a = _a;
   b = _b;
   c = _c;
   d = _d;

   a[0] = in_data[ir - 1][0];
   a[1] = in_data[ir][0];
   a[2] = in_data[ir + 1][0];
   SORT_SLICE ( a );

   b[0] = in_data[ir - 1][1];
   b[1] = in_data[ir][1];
   b[2] = in_data[ir + 1][1];
   SORT_SLICE ( b );

   /* For each column pair */
   for ( ic = 1; ic < c_end; ic += 2 )
    {
     c[0] = in_data[ir - 1][ic + 1];
     c[1] = in_data[ir][ic + 1];
     c[2] = in_data[ir + 1][ic + 1];

     d[0] = in_data[ir - 1][ic + 2];
     d[1] = in_data[ir][ic + 2];
     d[2] = in_data[ir + 1][ic + 2];

     /* sort slice c and d */
     /* slice a and b are already sorted */
     SORT_SLICE ( c );
     SORT_SLICE ( d );
     /* merge slice b and c producing slice bc */
     merge_slice ( b, c, bc );
     /* merge slice bc and a to calculate median 1 */
     out_data[ir][ic] = calc_median ( a, bc );
     /* merge slice bc and d to calculate median 2 */
     out_data[ir][ic + 1] = calc_median ( d, bc );

     SWAP_SLICE ( a, c );
     SWAP_SLICE ( b, d );
    }
  }

 return out_img;
}

#undef SWAP_SLICE
#undef SORT_BYTE
#undef SORT_SLICE

/** 
 * @brief Implements the Constant Time Median Filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @ref Perreault S. and Hebert P. (2007) "Median Filtering in Constant Time" 
 *      IEEE Trans. on Image Processing, 16(9): 2389-2394.
 *      http://nomis80.org/ctmf.pdf
 *
 * @author Simon Perreault
 * @date 01.19.2008
 */

Image *
filter_const_time_median ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_const_time_median" );
 byte *in_data;
 byte *out_data;
 int num_rows, num_cols;
 int half_win;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 /* # channels = 1 ; memsize = 512Kb */
 ctmf ( in_data, out_data, num_cols, num_rows, num_rows, num_rows, half_win, 1,
	512 * 1024 );

 return out_img;
}
