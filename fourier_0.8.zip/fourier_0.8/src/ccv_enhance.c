
/** 
 * @file ccv_enhance.c
 * Routines for Contrast Enhancement of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Yu and Bajaj's Contrast Enhancement method
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] sharp_factor Sharpening factor { [0,1] }
 *
 * @return Pointer to the contrast enhanced image or NULL
 *
 * @ref Yu Z. and Bajaj C. (2004) "A Fast and Adaptive Algorithm for Image 
 *      Contrast Enhancement" Proc. of the IEEE ICIP'04, pp. 1001-1004
 *      Available at: http://www.cam.ucsd.edu/~zeyun/Paper/ICIP04.pdf
 *
 * @author Zeyun Yu
 * @date 02.09.2008
 */

#define RESISTOR  0.95

Image *
ccv_enhance ( const Image * in_img, const double sharp_factor )
{
 SET_FUNC_NAME ( "ccv_enhance" );
 byte *in_data;
 byte *out_data;
 int i, j;
 int num_rows, num_cols;
 int num_pixels;
 int index;
 double lmin, lmax, img, avg;
 double tempmax, tempmin, temp;
 double window;
 double a, b, c, alpha;
 double normal_term;
 double *lcmax, *lcmin;
 double *tmpmax, *tmpmin;
 double *imgavg;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_IN_0_1 ( sharp_factor ) )
  {
   ERROR ( "Sharpening factor ( %f ) must be in [0,1] !", sharp_factor );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;
 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 lcmin = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 lcmax = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 tmpmin = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 tmpmax = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 imgavg = ( double * ) malloc ( num_pixels * sizeof ( double ) );

 if ( IS_NULL ( lcmin ) || IS_NULL ( lcmax ) ||
      IS_NULL ( tmpmin ) || IS_NULL ( tmpmax ) || IS_NULL ( imgavg ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 for ( index = 0; index < num_pixels; index++ )
  {
   lcmin[index] = lcmax[index] = tmpmin[index] = tmpmax[index] = imgavg[index] =
    in_data[index];
  }

 for ( i = 1; i < num_cols; i++ )
  {
   imgavg[i] += RESISTOR * ( imgavg[i - 1] - imgavg[i] );
   if ( tmpmin[i - 1] < tmpmin[i] )
    {
     tmpmin[i] += RESISTOR * ( tmpmin[i - 1] - tmpmin[i] );
    }
   if ( tmpmax[i - 1] > tmpmax[i] )
    {
     tmpmax[i] += RESISTOR * ( tmpmax[i - 1] - tmpmax[i] );
    }
  }

 for ( i = num_cols - 2; i >= 0; i-- )
  {
   imgavg[i] += RESISTOR * ( imgavg[i + 1] - imgavg[i] );
   if ( tmpmin[i + 1] < tmpmin[i] )
    {
     tmpmin[i] += RESISTOR * ( tmpmin[i + 1] - tmpmin[i] );
    }
   if ( tmpmax[i + 1] > tmpmax[i] )
    {
     tmpmax[i] += RESISTOR * ( tmpmax[i + 1] - tmpmax[i] );
    }
  }

 for ( j = 1; j < num_rows; j++ )
  {
   for ( i = 0; i < num_cols; i++ )
    {
     imgavg[j * num_cols + i] +=
      RESISTOR * ( imgavg[( j - 1 ) * num_cols + i] -
		   imgavg[j * num_cols + i] );
     if ( tmpmin[( j - 1 ) * num_cols + i] < tmpmin[j * num_cols + i] )
      {
       tmpmin[j * num_cols + i] +=
	RESISTOR * ( tmpmin[( j - 1 ) * num_cols + i] -
		     tmpmin[j * num_cols + i] );
      }
     if ( tmpmax[( j - 1 ) * num_cols + i] > tmpmax[j * num_cols + i] )
      {
       tmpmax[j * num_cols + i] +=
	RESISTOR * ( tmpmax[( j - 1 ) * num_cols + i] -
		     tmpmax[j * num_cols + i] );
      }
    }

   for ( i = 1; i < num_cols; i++ )
    {
     imgavg[j * num_cols + i] +=
      RESISTOR * ( imgavg[j * num_cols + i - 1] - imgavg[j * num_cols + i] );
     if ( tmpmin[j * num_cols + i - 1] < tmpmin[j * num_cols + i] )
      {
       tmpmin[j * num_cols + i] +=
	RESISTOR * ( tmpmin[j * num_cols + i - 1] - tmpmin[j * num_cols + i] );
      }
     if ( tmpmax[j * num_cols + i - 1] > tmpmax[j * num_cols + i] )
      {
       tmpmax[j * num_cols + i] +=
	RESISTOR * ( tmpmax[j * num_cols + i - 1] - tmpmax[j * num_cols + i] );
      }
    }

   for ( i = num_cols - 2; i >= 0; i-- )
    {
     imgavg[j * num_cols + i] +=
      RESISTOR * ( imgavg[j * num_cols + i + 1] - imgavg[j * num_cols + i] );
     if ( tmpmin[j * num_cols + i + 1] < tmpmin[j * num_cols + i] )
      tmpmin[j * num_cols + i] +=
       RESISTOR * ( tmpmin[j * num_cols + i + 1] - tmpmin[j * num_cols + i] );
     if ( tmpmax[j * num_cols + i + 1] > tmpmax[j * num_cols + i] )
      tmpmax[j * num_cols + i] +=
       RESISTOR * ( tmpmax[j * num_cols + i + 1] - tmpmax[j * num_cols + i] );
    }
  }

 j = num_rows - 1;

 for ( i = num_cols - 2; i >= 0; i-- )
  {
   imgavg[j * num_cols + i] +=
    RESISTOR * ( imgavg[j * num_cols + i + 1] - imgavg[j * num_cols + i] );
   if ( lcmin[j * num_cols + i + 1] < lcmin[j * num_cols + i] )
    {
     lcmin[j * num_cols + i] +=
      RESISTOR * ( lcmin[j * num_cols + i + 1] - lcmin[j * num_cols + i] );
    }
   if ( lcmax[j * num_cols + i + 1] > lcmax[j * num_cols + i] )
    {
     lcmax[j * num_cols + i] +=
      RESISTOR * ( lcmax[j * num_cols + i + 1] - lcmax[j * num_cols + i] );
    }
  }

 for ( i = 1; i < num_cols; i++ )
  {
   imgavg[j * num_cols + i] +=
    RESISTOR * ( imgavg[j * num_cols + i - 1] - imgavg[j * num_cols + i] );
   if ( lcmin[j * num_cols + i - 1] < lcmin[j * num_cols + i] )
    {
     lcmin[j * num_cols + i] +=
      RESISTOR * ( lcmin[j * num_cols + i - 1] - lcmin[j * num_cols + i] );
    }
   if ( lcmax[j * num_cols + i - 1] > lcmax[j * num_cols + i] )
    {
     lcmax[j * num_cols + i] +=
      RESISTOR * ( lcmax[j * num_cols + i - 1] - lcmax[j * num_cols + i] );
    }
  }

 for ( j = num_rows - 2; j >= 0; j-- )
  {
   for ( i = 0; i < num_cols; i++ )
    {
     imgavg[j * num_cols + i] +=
      RESISTOR * ( imgavg[( j + 1 ) * num_cols + i] -
		   imgavg[j * num_cols + i] );
     if ( lcmin[( j + 1 ) * num_cols + i] < lcmin[j * num_cols + i] )
      {
       lcmin[j * num_cols + i] +=
	RESISTOR * ( lcmin[( j + 1 ) * num_cols + i] -
		     lcmin[j * num_cols + i] );
      }
     if ( lcmax[( j + 1 ) * num_cols + i] > lcmax[j * num_cols + i] )
      {
       lcmax[j * num_cols + i] +=
	RESISTOR * ( lcmax[( j + 1 ) * num_cols + i] -
		     lcmax[j * num_cols + i] );
      }
    }

   for ( i = num_cols - 2; i >= 0; i-- )
    {
     imgavg[j * num_cols + i] +=
      RESISTOR * ( imgavg[j * num_cols + i + 1] - imgavg[j * num_cols + i] );
     if ( lcmin[j * num_cols + i + 1] < lcmin[j * num_cols + i] )
      {
       lcmin[j * num_cols + i] +=
	RESISTOR * ( lcmin[j * num_cols + i + 1] - lcmin[j * num_cols + i] );
      }
     if ( lcmax[j * num_cols + i + 1] > lcmax[j * num_cols + i] )
      {
       lcmax[j * num_cols + i] +=
	RESISTOR * ( lcmax[j * num_cols + i + 1] - lcmax[j * num_cols + i] );
      }
    }

   for ( i = 1; i < num_cols; i++ )
    {
     imgavg[j * num_cols + i] +=
      RESISTOR * ( imgavg[j * num_cols + i - 1] - imgavg[j * num_cols + i] );
     if ( lcmin[j * num_cols + i - 1] < lcmin[j * num_cols + i] )
      {
       lcmin[j * num_cols + i] +=
	RESISTOR * ( lcmin[j * num_cols + i - 1] - lcmin[j * num_cols + i] );
      }
     if ( lcmax[j * num_cols + i - 1] > lcmax[j * num_cols + i] )
      {
       lcmax[j * num_cols + i] +=
	RESISTOR * ( lcmax[j * num_cols + i - 1] - lcmax[j * num_cols + i] );
      }
    }
  }

 tempmin = 9999;
 tempmax = -9999;
 for ( index = 0; index < num_pixels; index++ )
  {
   lmin = MIN_2 ( lcmin[index], tmpmin[index] );
   lmax = MAX_2 ( lcmax[index], tmpmax[index] );
   img = in_data[index];
   avg = imgavg[index];

   window = lmax - lmin;
   window = sqrt ( window * ( 510 - window ) );
   if ( lmin != lmax )
    {
     img = window * ( img - lmin ) / ( lmax - lmin );
     avg = window * ( avg - lmin ) / ( lmax - lmin );
    }

   alpha = ( avg - img ) / ( 181.019 * window );

   if ( alpha != 0 )
    {
     a = 0.707 * alpha;
     b = 1.414 * alpha * ( img - window ) - 1;
     c = 0.707 * alpha * img * ( img - 2 * window ) + img;

     lcmin[index] = lmin + ( -b - sqrt ( b * b - 4 * a * c ) ) / ( 2 * a );
    }
   else
    {
     lcmin[index] = lmin + img;
    }

   temp = lcmin[index];
   if ( temp > tempmax )
    {
     tempmax = temp;
    }
   if ( temp < tempmin )
    {
     tempmin = temp;
    }
  }

 /* the following "0.0" could be set to other value (e.g., 0.1)
    in case you want to sharpen the enhanced images */
 temp = tempmax - tempmin;
 tempmin += sharp_factor * temp;
 tempmax -= sharp_factor * temp;
 normal_term = 255.0 / ( tempmax - tempmin );

 for ( index = 0; index < num_pixels; index++ )
  {
   if ( lcmin[index] < tempmin )
    {
     lcmin[index] = tempmin;
    }
   if ( lcmin[index] > tempmax )
    {
     lcmin[index] = tempmax;
    }

   out_data[index] = ( byte ) ( ( lcmin[index] - tempmin ) * normal_term );
  }

 free ( lcmin );
 free ( lcmax );
 free ( tmpmin );
 free ( tmpmax );
 free ( imgavg );

 return out_img;
}

#undef RESISTOR
