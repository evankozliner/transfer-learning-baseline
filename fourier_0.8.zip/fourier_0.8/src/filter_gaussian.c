
/** 
 * @file filter_gaussian.c
 * Routines for Gaussian filtering of a grayscale image
 */

#include <image.h>

void anigauss ( double *input, double *output, int sizex, int sizey,
		double sigmav, double sigmau, double phi, int orderv,
		int orderu );

/** 
 * @brief Implements the separable Gaussian filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] stdev Standard deviation of the Gaussian mask { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels in the output image outside the convolution area are set to 0.
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_gaussian ( const Image * in_img, const double stdev )
{
 SET_FUNC_NAME ( "filter_gaussian" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int mask_size;			/* dimension of the filtering window */
 int half_mask;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 double hor_conv;		/* result of the convolution in the horizontal direction */
 double ver_conv;		/* result of the convolution in the vertical direction. 
				   note that this is also the total convolution result */
 double *mask;			/* 1D Gaussian mask coefficients */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS ( stdev ) )
  {
   ERROR ( "Standard deviation ( %f ) must be positive !", stdev );
   return NULL;
  }

 mask = gauss_1d ( stdev, &mask_size );
 if ( IS_NULL ( mask ) )
  {
   ERROR_RET ( "gauss_1d() failed !", NULL );
  }

 if ( IS_EVEN ( mask_size ) )
  {
   /* Make the mask size odd */
   mask_size++;
  }

 half_mask = mask_size / 2;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_mask;
 r_end = num_rows - half_mask;
 c_begin = half_mask;
 c_end = num_cols - half_mask;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = mask_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = mask_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     /* Initialize the vertical/total convolution result */
     ver_conv = 0.0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* Initialize the horizontal convolution result */
       hor_conv = 0.0;

       /* Perform convolution in the horizontal direction */
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 hor_conv += in_data[iwr][iwc] * mask[iwc - wc_begin];
	}

       /* Perform convolution in the vertical direction */
       ver_conv += hor_conv * mask[iwr - wr_begin];
      }

     /* Assign the convolution result to the output pixel */
     out_data[ir][ic] = ver_conv;

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( mask );

 return out_img;
}

/** 
 * @brief Implements the Fast Anisotropic Gaussian filter
 *
 * @param[in] in_img  Image pointer { grayscale }
 * @param[in] sigma_v Standard deviation for the short-axis 
 * @param[in] sigma_u Standard deviation for the long-axis
 * @param[in] phi     Orientation angle in degrees
 * @param[in] order_v Order for the short-axis { positive }
 * @param[in] order_u Order for the long-axis  { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note 1) The output image is of PIX_DBL_1B type.
 *       2) When SIGMA_V = SIGMA_U the filter becomes isotropic.
 * @reco For noise removal (ORDER_V, ORDER_U) = (0.0, 0.0);
 *       For edge detection (ORDER_V, ORDER_U) = (1.0, 0.0);
 *       For line detection (ORDER_V, ORDER_U) = (2.0, 0.0).
 *
 * @ref Geusebroek J.M., Smeulders A.W.M., and Weijer J. van de (2003) 
 *      "Fast Anisotropic Gauss Filtering" IEEE Trans. on Image Processing, 
 *      12(8): 938-943.
 *      http://www.science.uva.nl/~mark/pub/2003/geusebroekIP03.pdf
 *
 * @author Jan-Mark Geusebroek
 * @date 01.17.2008
 */

Image *
filter_ani_gaussian ( const Image * in_img, const double sigma_v,
		      const double sigma_u, const double phi, const int order_v,
		      const int order_u )
{
 SET_FUNC_NAME ( "filter_ani_gaussian" );
 byte *in_data_byte;
 int ik;
 int num_rows, num_cols;
 int num_pixels;
 double *in_data_dbl;
 double *out_data_dbl;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( order_v < 0 )
  {
   ERROR ( "order_v ( %f ) must be non-negative !", order_v );
   return NULL;
  }

 if ( order_u < 0 )
  {
   ERROR ( "order_u ( %f ) must be non-negative !", order_u );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;
 in_data_byte = get_img_data_1d ( in_img );

 in_data_dbl = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 if ( IS_NULL ( in_data_dbl ) )
  {
   ERROR ( "Insufficient memory !" );
  }

 /* Cast input byte data to double */
 for ( ik = 0; ik < num_pixels; ik++ )
  {
   in_data_dbl[ik] = in_data_byte[ik];
  }

 out_img = alloc_img ( PIX_DBL_1B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR ( "Insufficient memory !" );
  }
 out_data_dbl = get_img_data_1d ( out_img );

 anigauss ( in_data_dbl, out_data_dbl, num_cols, num_rows, sigma_v, sigma_u,
	    phi, order_v, order_u );

 free ( in_data_dbl );

 return out_img;
}
