
/** 
 * @file filter_annf.c
 * Routines for ANNF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the ANNF (Adaptive Nearest Neighbor Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 *
 * @ref 1) Plataniotis K.N., Androutsos D., Vinayagamoorthy S., and Venetsanopoulos A.N.
 *         (1995) "A Nearest Neighbor Multichannel Filter" Electronics Letters, 31(22): 1910-1911
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *
 * @author M. Emre Celebi
 * @date 08.06.2007
 */

Image *
filter_annf ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_annf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int *red, *green, *blue;
 double acos_arg;
 double min_angle;
 double max_angle;
 double range_angle;
 double weight_sum;
 double red_out, green_out, blue_out;
 double *vec_len;
 double *angle_sum;
 double *weight;
 double **angle_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 vec_len = ( double * ) malloc ( win_count * sizeof ( double ) );
 angle_sum = ( double * ) malloc ( win_count * sizeof ( double ) );
 weight = ( double * ) malloc ( win_count * sizeof ( double ) );

 angle_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the vector lengths */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       vec_len[iwr] = L2_NORM_3D ( red[iwr], blue[iwr], green[iwr] );
      }

     /* Calculate the angles between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   if ( vec_len[iwc] > 0.0 )
	    {
	     /* ( dot product ) / ( || vector1 || * || vector2 || ) */
	     acos_arg =
	      ( red[iwr] * red[iwc] + green[iwr] * green[iwc] +
		blue[iwr] * blue[iwc] ) / ( vec_len[iwr] * vec_len[iwc] );

	     /* Calculate the angle between the two color vectors */
	     angle_mat[iwr][iwc] = ACOS ( acos_arg );
	    }
	   else
	    {
	     /* Idempotent value */
	     angle_mat[iwr][iwc] = 0.0;
	    }
	  }
	}
      }

     /* Calculate the cumulative angle for each pixel */

     memset ( angle_sum, 0, win_count * sizeof ( double ) );
     min_angle = DBL_MAX;
     max_angle = DBL_MIN;

     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   angle_sum[iwr] += angle_mat[iwc][iwr];
	  }

	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   angle_sum[iwr] += angle_mat[iwr][iwc];
	  }

	 if ( angle_sum[iwr] < min_angle )
	  {
	   min_angle = angle_sum[iwr];
	  }
	 if ( max_angle < angle_sum[iwr] )
	  {
	   max_angle = angle_sum[iwr];
	  }
	}
      }

     range_angle = max_angle - min_angle;

     if ( range_angle > 0.0 )
      {
       weight_sum = 0.0;

       /* Calculate the fuzzy weights */
       for ( iwr = 0; iwr < win_count; iwr++ )
	{
	 if ( vec_len[iwr] > 0.0 )
	  {
	   weight[iwr] = ( max_angle - angle_sum[iwr] ) / range_angle;
	   weight_sum += weight[iwr];
	  }
	 else
	  {
	   weight[iwr] = 0.0;
	  }
	}

       if ( weight_sum > 0.0 )
	{
	 red_out = green_out = blue_out = 0.0;
	 for ( iwr = 0; iwr < win_count; iwr++ )
	  {
	   weight[iwr] /= weight_sum;	/* Normalize the weights */

	   /* 
	      The output vector is the fuzzy weighted
	      linear combination of the input vectors 
	    */

	   red_out += weight[iwr] * red[iwr];
	   green_out += weight[iwr] * green[iwr];
	   blue_out += weight[iwr] * blue[iwr];
	  }

	 out_data[ir][ic][0] = red_out + .5;	/* round */
	 out_data[ir][ic][1] = green_out + .5;	/* round */
	 out_data[ir][ic][2] = blue_out + .5;	/* round */
	}
       else
	{
	 out_data[ir][ic][0] = red[center_pix];
	 out_data[ir][ic][1] = green[center_pix];
	 out_data[ir][ic][2] = blue[center_pix];
	}
      }
     else			/* All of the window pixels are of the same color */
      {
       out_data[ir][ic][0] = red[center_pix];
       out_data[ir][ic][1] = green[center_pix];
       out_data[ir][ic][2] = blue[center_pix];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( vec_len );
 free ( angle_sum );
 free ( weight );
 free_nd ( angle_mat, 2 );

 return out_img;
}
