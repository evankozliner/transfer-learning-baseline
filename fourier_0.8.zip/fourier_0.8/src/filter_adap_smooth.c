
/** 
 * @file filter_adap_smooth.c
 * Routines for Adaptive Smoothing of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Adaptive Smoothing filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] k_value K parameter of the filter { non-zero }
 * @param[in] num_iters Number of iterations { positive }
 *
 * @return Pointer to the filtered image or NULL
 * @reco The authors recommend K_VALUE = 6..10
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Saint-Marc P., Chen J.-S, Medioni G. (1991) "Adaptive Smoothing:
 *      A General Tool for Early Vision" IEEE Trans. on Pattern Analysis
 *      and Machine Intelligence, 13(6): 514-529
 *
 * @author M. Emre Celebi
 * @date 02.09.2008
 */

/** @cond INTERNAL_MACRO */

#define FILTER_ADAP_SMOOTH( R, C )\
 grad_row = in_data[( R ) + 1][( C )] - in_data[( R ) - 1][( C )];\
 grad_col = in_data[( R )][( C ) + 1] - in_data[( R )][( C ) - 1];\
 weight_sum += ( weight = exp ( -term * ( grad_row * grad_row + grad_col * grad_col ) ) );\
 conv_sum += weight * in_data[( R )][( C )];\


/** @endcond INTERNAL_MACRO */

Image *
filter_adap_smooth ( const Image * in_img, const double k_value,
		     const int num_iters )
{
 SET_FUNC_NAME ( "filter_adap_smooth" );
 int num_rows, num_cols;
 int ik, ir, ic;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 double term;
 double weight;
 double weight_sum;
 double conv_sum;
 double grad_row, grad_col;
 double **in_data;
 double **out_data;
 Image *in_dbl_img;
 Image *out_dbl_img;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( IS_ZERO ( k_value ) )
  {
   ERROR_RET ( "k_value must be non-zero !", NULL );
  }

 if ( num_iters <= 0 )
  {
   ERROR ( "Number of iterations ( %d ) must be positive !", num_iters );
   return NULL;
  }

 term = 1.0 / ( 8.0 * k_value * k_value );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 /* Convert the input image to double type */
 in_dbl_img = byte_to_dbl_img ( in_img );
 in_data = get_img_data_nd ( in_dbl_img );

 out_dbl_img = alloc_img ( PIX_DBL_1B, num_rows, num_cols );
 if ( IS_NULL ( out_dbl_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_dbl_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = 2;
 r_end = num_rows - 2;
 c_begin = 2;
 c_end = num_cols - 2;

 for ( ik = 0; ik < num_iters; ik++ )
  {
   for ( ir = r_begin; ir < r_end; ir++ )
    {
     for ( ic = c_begin; ic < c_end; ic++ )
      {
       /* Initialize */
       weight_sum = conv_sum = 0.0;

       /* Perform convolution */
       FILTER_ADAP_SMOOTH ( ir - 1, ic - 1 );
       FILTER_ADAP_SMOOTH ( ir - 1, ic );
       FILTER_ADAP_SMOOTH ( ir - 1, ic + 1 );
       FILTER_ADAP_SMOOTH ( ir, ic - 1 );
       FILTER_ADAP_SMOOTH ( ir, ic );
       FILTER_ADAP_SMOOTH ( ir, ic + 1 );
       FILTER_ADAP_SMOOTH ( ir + 1, ic - 1 );
       FILTER_ADAP_SMOOTH ( ir + 1, ic );
       FILTER_ADAP_SMOOTH ( ir + 1, ic + 1 );

       /* Assign the convolution result to the output pixel value */
       out_data[ir][ic] = conv_sum / weight_sum;
      }
    }

   /* Assign the output of current iteration to the input of next iteration */
   in_data = out_data;
  }

 /* Convert the output image to byte type */
 out_img = dbl_to_byte_img ( out_dbl_img );

 free_img ( in_dbl_img );
 free_img ( out_dbl_img );

 return out_img;
}

#undef FILTER_ADAP_SMOOTH
