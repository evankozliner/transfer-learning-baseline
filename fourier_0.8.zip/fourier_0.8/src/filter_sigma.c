
/** 
 * @file filter_sigma.c
 * Routines for Lee's sigma filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Lee's sigma filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] k_value If the center pixel has more than K_VALUE neighbors 
 *                    that satisfy the 2*sigma constraint, the output is 
 *                    determined by the average of these; otherwise it is 
 *                    determined by the average of the immediate neighbors { [0, WIN_SIZE^2) }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco Lee recommends that K_VALUE >= 4 for WIN_SIZE = 7 and K_VALUE >= 3 for WIN_SIZE = 5
 *
 * @ref Lee J.S. (1983) "Digital Image Smoothing and the Sigma Filter" Computer Vision, 
 *      Graphics and Image Processing, 24(2): pp. 255-269
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_sigma ( const Image * in_img, const int win_size, const int k_value )
{
 SET_FUNC_NAME ( "filter_sigma" );
 byte *win_data;		/* stores the pixels in a particular window position */
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int count;
 int half_win;
 int win_count;
 int ir, ic;
 int ik;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int sum;
 int sum_sq;
 int center_val;
 int sig_count;			/* # pixels in a window that satisfy the 2*sigma constraint */
 int sig_sum;			/* sum of those pixels that satisfy the 2*sigma constraint */
 double two_sigma;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( ( k_value < 0 ) || ( k_value >= win_size * win_size ) )
  {
   ERROR ( "K value ( %d ) must be in [0, %d) range !", k_value,
	   win_size * win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;

 win_data = ( byte * ) malloc ( win_count * sizeof ( byte ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;
     sum = sum_sq = 0;
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 win_data[count] = in_data[iwr][iwc];
	 sum += win_data[count];
	 sum_sq += win_data[count] * win_data[count];
	 count++;
	}
      }

     /* stdev = sqrt ( var ) = sqrt ( n * squared_sum - sum^2 ) / n ) */
     two_sigma =
      2.0 * ( sqrt ( ( win_count * sum_sq ) - sum * sum ) / win_count );

     center_val = in_data[ir][ic];

     /* Determine the number of the pixels that satisfy the 2*sigma constraint */
     sig_count = 0;
     sig_sum = sum;
     for ( ik = 0; ik < win_count; ik++ )
      {
       if ( ( abs ( win_data[ik] - center_val ) < two_sigma ) )
	{
	 sig_count++;
	}
       else
	{
	 /* 
	    Update SIG_SUM so that it contains the sum 
	    of those pixels that satisfy the constraint 
	  */
	 sig_sum -= win_data[ik];
	}
      }

     /* More than K_VALUE neighbors satisfy ... */
     if ( sig_count > k_value )
      {
       /* The output is the mean of those pixels */
       out_data[ir][ic] = sig_sum / sig_count;
      }
     else
      {
       /* The output is the average of all the immediate neighbors of the center pixel */
       if ( win_size == 3 )
	{
	 out_data[ir][ic] = ( sum - center_val ) / 8;
	}
       else
	{
	 out_data[ir][ic] = ( in_data[ir - 1][ic - 1] + in_data[ir - 1][ic] +
			      in_data[ir - 1][ic + 1] + in_data[ir][ic - 1] +
			      in_data[ir][ic + 1] + in_data[ir + 1][ic - 1] +
			      in_data[ir + 1][ic] + in_data[ir + 1][ic +
								    1] ) / 8;
	}
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}
