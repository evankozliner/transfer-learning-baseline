
/** 
 * @file cs_moments.c
 * Routines for the calculation of Contour Sequence Moments
 */

#include <image.h>

/** 
 * @brief Calculates the Contour Sequence Moments of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 *
 * @return Pointer to the Contour Sequence Moments or NULL
 *
 * @ref 1) Gupta L. and Srinath M.D. (1987) "Contour Sequence Moments for the 
 *         Classification of Closed Planar Shapes" Pattern Recognition, 20(3): 267-272.
 *      2) Rangayyan R.M. (2005) "Biomedical Image Analysis" CRC Press 
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

CSMoments *
calc_cs_moments ( const Image * img, const int label, const PointList * cont )
{
 SET_FUNC_NAME ( "calc_cs_moments" );
 int ik;
 int num_pts;
 double row_mean, col_mean;
 double mean_dist;
 double dev, dev_p2, dev_p3;
 double mu2, mu3, mu4, mu5;
 double *rad_dist;
 Point *centroid;
 CSMoments *csm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", NULL );
  }

 /* 
  * Calculate the object centroid. This is more robust 
  * than the contour centroid which is sensitive to noise. 
  */
 centroid = calc_obj_centroid ( img, label );
 row_mean = centroid->row;
 col_mean = centroid->col;

 num_pts = get_num_pts ( cont );

 rad_dist = ( double * ) malloc ( num_pts * sizeof ( double ) );
 if ( IS_NULL ( rad_dist ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Calculate the mean of the radial distances */
 mean_dist = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   mean_dist += ( rad_dist[ik] =
		  L2_DIST_2D ( cont->point[ik]->row, cont->point[ik]->col,
			       row_mean, col_mean ) );
  }
 mean_dist /= num_pts;

 /* Calculate the central contour sequence moments */
 mu2 = mu3 = mu4 = mu5 = 0.0;
 for ( ik = 0; ik < num_pts; ik++ )
  {
   dev = fabs ( rad_dist[ik] - mean_dist );	/* FABS is not included in the original paper */
   dev_p2 = dev * dev;
   dev_p3 = dev * dev_p2;

   mu2 += dev_p2;
   mu3 += dev_p3;
   mu4 += dev_p2 * dev_p2;
   mu5 += dev_p2 * dev_p3;
  }

 mu2 /= num_pts;
 mu3 /= num_pts;
 mu4 /= num_pts;
 mu5 /= num_pts;

 /* Calculate the normalized contour sequence moments */
 csm = MALLOC_STRUCT ( CSMoments );

 csm->F1 = sqrt ( mu2 ) / mean_dist;
 csm->F2 = mu3 / pow ( mu2, 1.5 );
 csm->F3 = mu4 / ( mu2 * mu2 );
 csm->F4 = mu5 / pow ( mu2, 2.5 );

 free ( rad_dist );

 return csm;
}
