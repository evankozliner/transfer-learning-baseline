
/** 
 * @file filter_giws.c
 * Routines for Gradient Inverse Weighted Smoothing of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Gradient Inverse Weighted Smoothing filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Wang et al. (1981) "Gradient Inverse Weighted Smoothing Scheme and the Evaluation 
 *      of its Performance" Computer Graphics and Image Processing, 15(2): 167-181
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_giws ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_giws" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int center_val;
 int cur_val;
 double weight;
 double weight_sum;
 double conv_sum;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     center_val = in_data[ir][ic];
     conv_sum = 0.0;
     weight_sum = 0.0;

     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 cur_val = in_data[iwr][iwc];

	 /* Determine the weight for the current pixel */
	 if ( cur_val == center_val )
	  {
	   weight = 2.0;
	  }
	 else
	  {
	   weight = 1.0 / abs ( cur_val - center_val );
	  }

	 conv_sum += weight * cur_val;
	 weight_sum += weight;
	}
      }

     out_data[ir][ic] = conv_sum / weight_sum;

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 return out_img;
}
