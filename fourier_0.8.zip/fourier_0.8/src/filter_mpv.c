
/** 
 * @file filter_mpv.c
 * Routines for Modified Peak-and-Valley filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Modified Peak-and-Valley Filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref 1) Alajlan N. and Jernigan E. (2004) "An Effective Detail Preserving Filter
 *         for Impulse Noise Removal" Proc. of the ICIAR'04, LNCS 3211: 139-146
 *      2) Alajlan N., Kamel M., and Jernigan E. (2004) "Detail Preserving Impulsive 
 *         Noise Removal" Signal Processing: Image Communication, 19(10): 993-1003
 *
 * @author M. Emre Celebi
 * @date 05.03.2008
 */

Image *
filter_mpv ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_mpv" );
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int win_count_m1;		/* number of pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int ik;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int min_val, max_val;
 int center_val;
 int P_min, P_max;
 int E_val, L_val;
 int tmp;
 int *win_data;			/* stores the pixels in a particular window position */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;
 win_count_m1 = win_count - 1;
 center_pix = win_count / 2;

 win_data = ( int * ) calloc ( win_count, sizeof ( int ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 /* This filter is recursive => Clone input image */
 out_img = clone_img ( in_img );
 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 win_data[count++] = out_data[iwr][iwc];
	}
      }

     /* Initialize to impossible values */
     min_val = NUM_GRAY;
     max_val = -1;

     /* 
        Determine the minimum and maximum value 
        in the window (exclude the center pixel) 
      */
     for ( ik = 0; ik < win_count; ik++ )
      {
       if ( ik != center_pix )
	{
	 if ( win_data[ik] < min_val )
	  {
	   min_val = win_data[ik];
	  }
	 if ( max_val < win_data[ik] )
	  {
	   max_val = win_data[ik];
	  }
	}
      }

     center_val = win_data[center_pix];

     /* Center pixel is noise-free */
     if ( ( min_val < center_val ) && ( center_val < max_val ) )
      {
       out_data[ir][ic] = center_val;
      }
     else			/* Center pixel is noisy */
      {
       /* Initialize to impossible values */
       P_min = NUM_GRAY;
       P_max = -1;

       /* Go through each symmetric pair of pixels and determine P_MIN and P_MAX */
       for ( ik = 0; ik < center_pix; ik++ )
	{
	 /* 
	    E and L should contain the minimum and 
	    maximum of this pixel pair, respectively.
	  */
	 E_val = win_data[ik];
	 L_val = win_data[win_count_m1 - ik];

	 /* Values are out of order => Swap them */
	 if ( L_val < E_val )
	  {
	   tmp = E_val;
	   E_val = L_val;
	   L_val = tmp;
	  }

	 /* Check whether we have found a new P_MIN and/or P_MAX */
	 if ( P_max < E_val )
	  {
	   P_max = E_val;
	  }
	 if ( L_val < P_min )
	  {
	   P_min = L_val;
	  }
	}

       /* Assign the arithmetic mean of P_MIN and P_MAX to the output pixel */
       out_data[ir][ic] = 0.5 * ( P_min + P_max ) + .5;	/* round */
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}
