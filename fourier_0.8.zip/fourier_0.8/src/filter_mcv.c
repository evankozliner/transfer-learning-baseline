
/** 
 * @file filter_mcv.c
 * Routines for MCV (Mean of Least Coefficient of Variation) filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the MCV (Mean of Least Coefficient of Variation) filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note 1) This filter is designed to smooth multiplicative noise.
 *       2) Pixels outside the convolution area are set to 0.
 * @ref Schulze M.A. and Wu Q.X. (1995) "Noise Reduction in Synthetic Aperture 
 *      Radar Imagery Using a Morphology-Based Nonlinear Filter" Proc. of DICTA'95, 
 *      Digital Image Computing: Techniques and Applications, pp. 661-666
 * @see #filter_mlv
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

Image *
filter_mcv ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_mcv" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int gray_val;
 int sum, sum_sq;		/* temp variables used in the calculation of local mean and variances */
 double local_mean;		/* gray level mean in a particular window position */
 double min_cv;
 double mean_min_cv = DBL_MIN;
 double **mean_data;
 double **cv_data;
 Image *mean_img;
 Image *cv_img;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 mean_img = alloc_img ( PIX_DBL_1B, num_rows, num_cols );
 if ( IS_NULL ( mean_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 mean_data = get_img_data_nd ( mean_img );

 cv_img = alloc_img ( PIX_DBL_1B, num_rows, num_cols );
 if ( IS_NULL ( cv_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 cv_data = get_img_data_nd ( cv_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* FIRST PASS: Determine the local mean and coefficient of variation at each window position */

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     sum = sum_sq = 0;
     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 sum += ( gray_val = in_data[iwr][iwc] );
	 sum_sq += gray_val * gray_val;
	}
      }

     /* Calculate the local mean and coefficient of variation */
     local_mean = sum / ( double ) win_count;
     mean_data[ir][ic] = local_mean;

     /* This is actually the squared coefficient of variation */
     cv_data[ir][ic] =
      ( ( sum_sq / ( double ) win_count ) -
	local_mean * local_mean ) / ( local_mean * local_mean );

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 /* SECOND PASS: Determine the output pixel values */

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     min_cv = DBL_MAX;
     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Find the window pixel with the minimum neighborhood coefficient of variation */
	 if ( cv_data[iwr][iwc] < min_cv )
	  {
	   min_cv = cv_data[iwr][iwc];
	   mean_min_cv = mean_data[iwr][iwc];
	  }
	}
      }

     /* 
        The output is the neigborhood mean of the window pixel
        with the minimum neighborhood coefficient of variation
      */
     out_data[ir][ic] = mean_min_cv;

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 return out_img;
}
