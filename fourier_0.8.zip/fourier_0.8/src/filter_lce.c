
/** 
 * @file filter_lce.c
 * Routines for Local Contrast Entropy filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Local Contrast Entropy (LCE) filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Beghdadi A. and Khellaf A. (1997) "A Noise Filtering Method Using a
 *      Local Information Measure" IEEE Trans. on Image Processing, 6(6): 879-882
 *
 * @author M. Emre Celebi
 * @date 07.12.2007
 */

Image *
filter_lce ( const Image * in_img, const int win_size )
{
 SET_FUNC_NAME ( "filter_lce" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int ik;
 int center_pix;
 int sum;
 int *win_data;			/* stores the pixels in a particular window position */
 double critical_val;
 double mean;
 double delta_sum;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;
 critical_val = 1.0 / ( double ) win_count;
 center_pix = win_count / 2;

 win_data = ( int * ) calloc ( win_count, sizeof ( int ) );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;
     sum = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 sum += ( win_data[count] = in_data[iwr][iwc] );
	 count++;
	}
      }

     /* Calculate the local mean */
     mean = sum / ( double ) win_count;

     /* Calculate the sum of absolute differences */
     delta_sum = 0.0;
     for ( ik = 0; ik < win_count; ik++ )
      {
       delta_sum += fabs ( win_data[ik] - mean );
      }

     /* 
        Local contrast probability of the center pixel is:
        P = fabs ( WIN_DATA[CENTER_PIX] - MEAN ) / DELTA_SUM;
        If P is greater than or equal to ( 1. / WIN_COUNT ) then 
        the center pixel is considered to be noisy and is replaced 
        by the local median. Otherwise, it remains unchanged.
      */
     if ( fabs ( win_data[center_pix] - mean ) >= delta_sum * critical_val )
      {
       /* Center pixel is noisy => replace it with the local median */
       out_data[ir][ic] = find_median ( win_count, win_data );
      }
     else
      {
       /* Center pixel value remains unchanged */
       out_data[ir][ic] = win_data[center_pix];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( win_data );

 return out_img;
}
