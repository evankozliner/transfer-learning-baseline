#include <image.h>

#define MAX_CHAIN_LEN 10000
#define MIN_CC_SIZE   500

int
main ( int argc, char **argv )
{
 int i;
 int num_cc;
 double elapsed_time;
 clock_t start_time;
 PointList *cont;
 CSMoments *csm;
 Image *in_img;
 Image *lab_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing contour sequence moments...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 /* Get the number of components */
 num_cc = get_num_cc ( lab_img );

 /* Remove the components smaller than MIN_CC_SIZE */
 if ( num_cc > 1 )
  {
   lab_img = remove_small_cc ( lab_img, MIN_CC_SIZE );
   num_cc = get_num_cc ( lab_img );
  }

 start_time = start_timer (  );
 for ( i = 1; i <= num_cc; i++ )
  {
   printf ( "Features for Object #%d\n", i );
   printf ( "----------------------\n" );

   /* Get the object contour */
   cont = chain_to_point_list ( trace_contour ( lab_img, i, MAX_CHAIN_LEN ) );

   csm = calc_cs_moments ( lab_img, i, cont );

   printf ( "F1 = %f, F2 = %f, F3 = %f, F4 = %f\n", csm->F1, csm->F2, csm->F3,
	    csm->F4 );

   printf ( "\n" );
  }
 elapsed_time = stop_timer ( start_time );

 printf ( "Feature extraction time = %f\n", elapsed_time );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );

 return EXIT_SUCCESS;
}
