#include <image.h>

#define MAX_CHAIN_LEN 10000
#define MIN_CC_SIZE   500

int
main ( int argc, char **argv )
{
 int i, j;
 int rad_res;
 int ang_res;
 int radius;
 int num_cc;
 double elapsed_time;
 double *gfd;
 clock_t start_time;
 Image *in_img;
 Image *lab_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing generic fourier descriptor...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 rad_res = 4;
 ang_res = 15;
 radius = 64;

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 /* Get the number of components */
 num_cc = get_num_cc ( lab_img );

 /* Remove the components smaller than MIN_CC_SIZE */
 if ( num_cc > 1 )
  {
   lab_img = remove_small_cc ( lab_img, MIN_CC_SIZE );
   num_cc = get_num_cc ( lab_img );
  }

 start_time = start_timer (  );
 for ( i = 1; i <= num_cc; i++ )
  {
   printf ( "Features for Object #%d\n", i );
   printf ( "----------------------\n" );

   gfd = calc_gen_fourier_desc ( lab_img, i, rad_res, ang_res, radius );

   for ( j = 0; j < rad_res * ang_res; j++ )
    {
     printf ( "%f ", gfd[j] );
    }
   printf ( "\n\n" );

   free ( gfd );
  }
 elapsed_time = stop_timer ( start_time );

 printf ( "Feature extraction time = %f\n", elapsed_time );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );

 return EXIT_SUCCESS;
}
