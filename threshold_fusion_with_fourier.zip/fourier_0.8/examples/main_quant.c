#include <image.h>

int
main ( int argc, char **argv )
{
 int num_bits;
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 3 )
  {
   fprintf ( stderr, "Usage: %s <input image { rgb }> <# colors { [1,256] }>\n",
	     argv[0] );
   exit ( EXIT_FAILURE );
  }

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's an rgb image */
 if ( !is_rgb_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be rgb !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing three color quantization algorithms...\n" );

 num_bits = 5;

 /* Start the timer */
 start_time = start_timer (  );

 /* Perform color quantization using Wu's method */
 out_img = quant_wan ( in_img, atoi ( argv[2] ), num_bits );

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "Wan's quantization time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_wan.ppm", FMT_PPM );

 /* Start the timer */
 start_time = start_timer (  );

 /* Perform color quantization using Wu's method */
 out_img = quant_wu ( in_img, atoi ( argv[2] ) );

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "Wu's quantization time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_wu.ppm", FMT_PPM );

 /* Start the timer */
 start_time = start_timer (  );

 /* Perform color quantization using the neural network method */
 out_img = quant_neural ( in_img, atoi ( argv[2] ), 5 );	/* Sampling Factor = 5 */

 /* Stop the timer */
 elapsed_time = stop_timer ( start_time );

 printf ( "Neural network quantization time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_neural.ppm", FMT_PPM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
