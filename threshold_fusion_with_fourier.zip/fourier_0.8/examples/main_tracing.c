#include <image.h>

int
main ( int argc, char **argv )
{
 Image *in_img;
 Image *lab_img;
 Image *out_img;
 ChainList *chain_list;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing contour tracing...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Label the 8-connected components */
 lab_img = label_cc ( in_img, 8 );

 /* Trace the object contours */
 chain_list = trace_contours ( lab_img, 10000 );

 /* Write the chains to a binary image */
 out_img = chain_list_to_img ( chain_list );

 /* Write the chain image to a file */
 write_img ( out_img, "out_contours.pbm", FMT_PBM );

 /* Free the chain list */
 free_chain_list ( chain_list );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
