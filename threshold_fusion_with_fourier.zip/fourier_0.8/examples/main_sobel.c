#include <image.h>

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { grayscale }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing Sobel Edge Detector...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a grayscale image */
 if ( !is_gray_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 start_time = start_timer (  );

 /* Detect the edges in the input image */
 out_img = detect_edge_sobel ( in_img );

 elapsed_time = stop_timer ( start_time );

 printf ( "Sobel Edge Detector time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_sobel.pbm", FMT_PBM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
