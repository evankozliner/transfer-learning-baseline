#include <image.h>

int
main ( int argc, char **argv )
{
 Image *in_img;
 Image *lab_img;
 Image *out_img;
 int i;
 int num_cc;
 int *area;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing connected component labeling...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 /* Get the number of components */
 num_cc = get_num_cc ( lab_img );

 /* Get the areas of the components */
 area = get_cc_areas ( lab_img );

 printf ( "\n" );
 /* 
    Print the areas of the components.
    Label 0 is for the background.
  */
 for ( i = 0 + 1; i <= num_cc; i++ )
  {
   printf ( "area[%d] = %d\n", i, area[i] );
  }

 printf ( "\n# 4-connected components = %d\n", num_cc );

 /* Remove all the components except for the largest */
 lab_img = retain_largest_cc ( lab_img );

 printf
  ( "\n# 4-connected components after calling retain_largest_cc( ) = %d\n",
    get_num_cc ( lab_img ) );

 /* Convert the label image to binary */
 out_img = label_to_bin ( lab_img );

 /* Write the binary image to a file */
 write_img ( out_img, "out_cc.pbm", FMT_PBM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
