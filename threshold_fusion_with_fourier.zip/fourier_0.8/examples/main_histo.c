#include <image.h>

int
main ( int argc, char **argv )
{
 Image *in_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { grayscale }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing histogram equalization and hyperbolization...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a grayscale image */
 if ( !is_gray_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Create the histogram and then write the image of it to a file */
 write_img ( histo_to_img ( create_histo ( in_img ), 256, 0 ), "out_histo.pbm",
	     FMT_PBM );

 /* Equalize the histogram and then write the resulting image to a file */
 write_img ( equalize_histo ( in_img ), "out_equalize.pgm", FMT_PGM );

 /* Hyperbolize the histogram and then write the resulting image to a file */
 write_img ( hyperbolize_histo ( in_img, 0.5 ), "out_hyperbolize.pgm",
	     FMT_PGM );

 free_img ( in_img );

 return EXIT_SUCCESS;
}
