#include <image.h>

#define MAX_CHAIN_LEN 10000
#define MIN_CC_SIZE   500

int
main ( int argc, char **argv )
{
 int i, j;
 int max_order;
 int radius;
 int num_cc;
 double elapsed_time;
 double *zd;
 clock_t start_time;
 ZernikeBasis *basis;
 Image *in_img;
 Image *lab_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { binary }\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing zernike moments...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a binary image */
 if ( !is_bin_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be binary !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 max_order = 10;
 radius = 64;

 /* Label the 4-connected components */
 lab_img = label_cc ( in_img, 4 );

 /* Get the number of components */
 num_cc = get_num_cc ( lab_img );

 /* Remove the components smaller than MIN_CC_SIZE */
 if ( num_cc > 1 )
  {
   lab_img = remove_small_cc ( lab_img, MIN_CC_SIZE );
   num_cc = get_num_cc ( lab_img );
  }

 start_time = start_timer (  );

 /* Calculate the Zernike Basis */
 basis = calc_zernike_basis ( max_order, radius );

 for ( i = 1; i <= num_cc; i++ )
  {
   printf ( "Features for Object #%d\n", i );
   printf ( "----------------------\n" );

   zd = calc_zernike_moments ( lab_img, i, basis );

   for ( j = 0; j < basis->num_terms; j++ )
    {
     printf ( "%f ", zd[j] );
    }
   printf ( "\n\n" );

   free ( zd );
  }
 elapsed_time = stop_timer ( start_time );

 printf ( "Feature extraction time = %f\n", elapsed_time );

 /* Free Zernike Basis */
 free_zernike_basis ( basis );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( lab_img );

 return EXIT_SUCCESS;
}
