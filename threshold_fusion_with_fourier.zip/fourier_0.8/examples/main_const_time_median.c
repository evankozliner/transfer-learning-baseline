#include <image.h>

int
main ( int argc, char **argv )
{
 int win_size;
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 3 )
  {
   fprintf ( stderr, "Usage: %s <input image { grayscale }> <win size>\n",
	     argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing constant-time median filter...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );
 win_size = atoi ( argv[2] );

 /* Make sure it's a grayscale image */
 if ( !is_gray_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 start_time = start_timer (  );

 /* Filter the input image */
 out_img = filter_const_time_median ( in_img, win_size );

 elapsed_time = stop_timer ( start_time );

 printf ( "Constant-time median filtering time = %f\n", elapsed_time );

 /* Write the output image to a file */
 write_img ( out_img, "out_median.pgm", FMT_PGM );

 /* Deallocate the images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
