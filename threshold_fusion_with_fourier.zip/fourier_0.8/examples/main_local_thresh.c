#include <image.h>

#define WIN_SIZE 15

int
main ( int argc, char **argv )
{
 double elapsed_time;
 clock_t start_time;
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { grayscale }>\n", argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing various local thresholding algorithms...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 /* Make sure it's a grayscale image */
 if ( !is_gray_img ( in_img ) )
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale !", argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Print the header */
 printf ( "\nMethod\t\tTime\n" );
 printf ( "--------\t----\n" );

 /* Perform local thresholding using 4 different methods */

 /* Start the timer */
 start_time = start_timer (  );

 /* Bernsen's method */
 out_img = threshold_bernsen ( in_img, WIN_SIZE, 15 );

 /* Calculate the elapsed time */
 elapsed_time = stop_timer ( start_time );

 /* Write the output image */
 write_img ( out_img, "out_bernsen.pbm", FMT_PBM );

 /* Deallocate the output image */
 free_img ( out_img );

 /* Display the method name and elapsed time */
 printf ( "%8s\t%f\n", "Bernsen", elapsed_time );

 /* Start the timer */
 start_time = start_timer (  );

 /* Niblack's method */
 out_img = threshold_niblack ( in_img, WIN_SIZE, -0.2 );

 /* Calculate the elapsed time */
 elapsed_time = stop_timer ( start_time );

 /* Write the output image */
 write_img ( out_img, "out_niblack.pbm", FMT_PBM );

 /* Deallocate the output image */
 free_img ( out_img );

 /* Display the method name and elapsed time */
 printf ( "%8s\t%f\n", "Niblack", elapsed_time );

 /* Start the timer */
 start_time = start_timer (  );

 /* Sauvola's method */
 out_img = threshold_sauvola ( in_img, WIN_SIZE, 0.5, 128 );

 /* Calculate the elapsed time */
 elapsed_time = stop_timer ( start_time );

 /* Write the output image */
 write_img ( out_img, "out_sauvola.pbm", FMT_PBM );

 /* Deallocate the output image */
 free_img ( out_img );

 /* Display the method name and elapsed time */
 printf ( "%8s\t%f\n", "Sauvola", elapsed_time );

 /* Start the timer */
 start_time = start_timer (  );

 /* Savakis's method */
 out_img = threshold_savakis_opt ( in_img, WIN_SIZE, &threshold_otsu );

 /* Calculate the elapsed time */
 elapsed_time = stop_timer ( start_time );

 /* Write the output image */
 write_img ( out_img, "out_savakis.pbm", FMT_PBM );

 /* Deallocate the output image */
 free_img ( out_img );

 /* Display the method name and elapsed time */
 printf ( "%8s\t%f\n", "Savakis", elapsed_time );

 /* Deallocate the input image */
 free_img ( in_img );

 return EXIT_SUCCESS;
}
