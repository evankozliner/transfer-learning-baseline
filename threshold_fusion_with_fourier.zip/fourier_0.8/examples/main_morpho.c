#include <image.h>

int
main ( int argc, char **argv )
{
 char format_char;
 char out_file[15];
 char method_name[6][7] =
  { "close", "dilate", "erode", "open", "tophat", "bothat" };
 int i;
 int se_size;
 int format;
 double elapsed_time;
 clock_t start_time;
 Strel *se;
 Image *in_img;
 Image *out_img;
 Image *( *function[6] ) ( const Image *, const Strel * ) =
 {
 &close_img, &dilate_img, &erode_img, &open_img, &tophat_img, &bothat_img};

 if ( argc != 3 )
  {
   fprintf ( stderr,
	     "Usage: %s <input image { binary or grayscale }> <strel size { odd }>\n",
	     argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing various morphological operations...\n\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );
 se_size = atoi ( argv[2] );

 /* Make sure it's binary or grayscale */
 if ( is_bin_img ( in_img ) )
  {
   format_char = 'b';
   format = FMT_PBM;
  }
 else if ( is_gray_img ( in_img ) )
  {
   format_char = 'g';
   format = FMT_PGM;
  }
 else
  {
   fprintf ( stderr, "Input image ( %s ) must be binary or grayscale !",
	     argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Create a rectangular structuring element */
 se = make_rect_strel ( se_size, se_size );

 /* Print the header */
 printf ( "Method  \tTime\n" );
 printf ( "--------\t--------\n" );

 for ( i = 0; i < 6; i++ )
  {
   /* Start the timer */
   start_time = start_timer (  );

   /* Perform morphological operation #i */
   out_img = function[i] ( in_img, se );

   /* Calculate the elapsed time */
   elapsed_time = stop_timer ( start_time );

   /* Determine the output file name */
   sprintf ( out_file, "out_%s.p%cm", method_name[i], format_char );

   /* Write the output image */
   write_img ( out_img, out_file, format );

   /* Deallocate the output image */
   free_img ( out_img );

   /* Display the elapsed time */
   printf ( "%8s\t%f\n", method_name[i], elapsed_time );
  }

 /* Deallocate the input image */
 free_img ( in_img );

 return EXIT_SUCCESS;
}
