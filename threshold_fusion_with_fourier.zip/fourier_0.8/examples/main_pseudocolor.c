#include <image.h>

int
main ( int argc, char **argv )
{
 Image *in_img;
 Image *out_img;

 if ( argc != 2 )
  {
   fprintf ( stderr, "Usage: %s <input image { grayscale, label }>\n",
	     argv[0] );
   exit ( EXIT_FAILURE );
  }

 printf ( "Testing pseudo-coloring...\n" );

 /* Read the input image */
 in_img = read_img ( argv[1] );

 if ( is_bin_img ( in_img ) )	/* Binary */
  {
   /* Label the 8-connected components */
   Image *lab_img = label_cc ( in_img, 8 );

   /* Pseudo-color the label image using the HSV colormap */
   out_img = pseudo_color ( lab_img, CMAP_HSV );

   /* Write the color image to a file */
   write_img ( out_img, "out_pseudo.ppm", FMT_PPM );

   /* Deallocate the label image */
   free_img ( lab_img );
  }
 else if ( is_gray_img ( in_img ) )	/* Grayscale */
  {
   /* Pseudo-color the label image using the HSV colormap */
   out_img = pseudo_color ( in_img, CMAP_HSV );

   /* Write the color image to a file */
   write_img ( out_img, "out_pseudo.ppm", FMT_PPM );
  }
 else
  {
   fprintf ( stderr, "Input image ( %s ) must be grayscale or label !",
	     argv[1] );
   exit ( EXIT_FAILURE );
  }

 /* Deallocate the input/output images */
 free_img ( in_img );
 free_img ( out_img );

 return EXIT_SUCCESS;
}
