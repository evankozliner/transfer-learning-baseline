 FOURIER 0.8
 
 Copyright (C) 2008

 Developed by 
 M. Emre Celebi 
 Department of Computer Science
 Louisiana State University in Shreveport
 Shreveport, LA 71115, USA
 WWW: 
  http://sourceforge.net/projects/fourier-ipal
  http://www.lsus.edu/faculty/~ecelebi/fourier.htm
 
 Project administrator: M. Emre Celebi

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as 
published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
USA.

--------------------------------------------------------------------

This is the beta release of Fourier, a portable image processing and 
analysis library written in ANSI C. The following is a list of some of 
the high-level functions currently available:

A. Image I/O
   Reading/Writing 
   1) PNM (PBM, PGM, PPM) format
   2) BMP (uncompressed) format
   3) JPEG format (only read)

B. Arithmetic/Logic
   1) add_img: Adds two images
   2) sub_img: Subtracts an image from another
   3) mult_img: Multiplies two images
   4) add_img_scalar: Adds a scalar to an image
   5) sub_img_scalar: Subtracts a scalar from an image
   6) mult_img_scalar: Multiplies an image with a scalar
   7) div_img_scalar: Divides an image by a scalar
   8) union_img: Unions two images
   9) intersect_img: Intersects two images

C. Geometric
   1) rotate_img: Rotate an image using bilinear interpolation
   2) scale_img: Scale an image using bilinear interpolation

D. Grayscale Image Smoothing/Noise Removal
   1) add_noise: Adds noise { Gaussian, Salt & Pepper, Speckle, Impulsive } to a grayscale/color 
                 image. Also, calculates various error measures { MAE, MSE, RMSE, PSNR, NMSE, NCD }.
   2) filter_adap_smooth: Adaptive Smoothing filter
   3) filter_bilateral: Bilateral filter
   4) filter_gaussian: Separable and Fast Anisotropic Gaussian filters
   5) filter_giws: Gradient Inverse Weighted Smoothing filter
   6) filter_kuwahara: Kuwahara filter
   7) filter_lce: Local Contrast Entropy filter
   8) filter_lee: Lee's local statistics filter
   9) filter_lum: LUM (Lower-Upper-Middle) filter
  10) filter_mad: Adaptive MAD-based filter
  11) filter_mcv: MCV (Mean of Least Coefficient of Variation) filter
  12) filter_mean: (Arithmetic) Mean filter
  13) filter_median: Classical, Running, 3x3, and Constant-Time Median filters 
  14) filter_mlv: MLV (Mean of Least Variance) filter
  15) filter_mpv; Modified Peak-and-Valley Filter
  16) filter_perona_malik: Perona-Malik Anisotropic Diffusion filter
  17) filter_robust_aniso: Robust Anisotropic Diffusion filter
  18) filter_sdrom: SDROM (Signal-Dependent Rank-Ordered Mean) filter
  19) filter_sep_median: Separable Median filter
  20) filter_sigma: Lee's Sigma filter
  21) filter_snn: Symmetric Nearest Neighbor filter
  22) filter_susan: Susan filter

E. Grayscale Image Enhancement
   1) ccv_enhance: Yu and Bajaj's Adaptive Contrast Enhancement method
   2) equalize_histo: Histogram Equalization
   3) expand_histo: Histogram Expansion
   4) hyperbolize_histo: Histogram Hyperbolization
   5) match_histo: Histogram Matching
   6) smooth_histo_gauss: Smoothes a histogram using a Gaussian-weighted mask
   7) smooth_histo_local: Smoothes a histogram using local arithmetic averaging

F. Binary and Grayscale Mathematical Morphology
   bin_morpho, gray_morpho, morpho:
   1) Dilation
   2) Erosion
   3) Opening
   4) Closing
   5) Opening Top-Hat
   6) Closing Top-Hat (Bottom-Hat)
   7) Conditional Dilation
   8) Conditional Erosion
   9) Morphological Gradient
  10) Inf-Reconstruction
  11) Sup-Reconstruction
  12) Opening by Reconstruction
  13) Closing by Reconstruction
  14) Open-by-Reconstruction Top-Hat
  15) Close-by-Reconstruction Top-Hat
  16) H-minima Transform
  17) H-maxima Transform
  18) Regional minima
  19) Regional maxima
  20) Extended-minima Transform
  21) Extended-maxima Transform
  22) Alternating Sequential Filter
  23) Hole Filling
  24) Border Clearing

G. Thresholding
   1) threshold_huang: Huang's fuzzy thresholding method
   2) threshold_iter: Iterative Selection thresholding method
   3) threshold_kapur: Kapur-Sahoo-Wong (Maximum Entropy) thresholding method
   4) threshold_li: Li's Minimum Cross Entropy thresholding method
   5) threshold_moment: Moment-Preserving thresholding method
   6) threshold_otsu: Otsu's thresholding method
   7) threshold_renyi: Sahoo et al.'s thresholding method
   8) threshold_shanbhag: Shanbhag's fuzzy thresholding method
   9) threshold_yen: Yen's thresholding method
  10) threshold_bernsen: Bernsen's thresholding method
  11) threshold_niblack: Niblack's thresholding method
  12) threshold_sauvola: Sauvola's thresholding method
  13) threshold_savakis: Savakis's thresholding method
  14) threshold_savakis_opt: Optimized version of Savakis's thresholding method

H. Grayscale Edge Detection
   1) detect_edge_canny: Canny Edge Detector
   2) detect_edge_deriche: Deriche Edge Detector
   3) detect_edge_log: LoG (Laplacian of Gaussian) Edge Detector
   4) detect_edge_prewitt: Prewitt Edge Detector
   5) detect_edge_roberts: Roberts Edge Detector
   6) detect_edge_sobel: Sobel Edge Detector

I. Binary Image Processing
   1) label_cc: Connected components labeling using the Union-Find data structure
   2) label_cc_hybrid: Connected components labeling using the hybrid method
   3) label_cc_trace: Connected components labeling using the contour tracing method
   4) fill_region: Heckbert's 4-connected seed-fill algorithm
   5) filter_majority: Majority filter
   6) pseudo_color: Pseudo coloring of a grayscale or label image
   7) trace_contours: 8-connected contour tracing

J. Shape Feature Extraction
   1) calc_2d_convex_hull: Calculates the convex hull of an object
   2) calc_affine_moments: Calculates the affine invariant moments of an object
   3) calc_aspect_ratio: Calculates the aspect ratio of an object
   4) calc_chord_len_stats: Calculates the chord length statistics { mean, 
                            variance, skewness, kurtosis } of an object
   5) calc_circularity: Calculates the circularity of an object
   6) calc_compactness: Calculates the compactness of an object
   7) calc_cs_moments: Calculates the contour sequence moments of an object
   8) calc_ellipse_feats: Calculates the ellipse-related { major/minor axis length,
                          aspect ratio, eccentricity, orientation } features of an object
   9) calc_ellipticity: Calculates the ellipticity of an object
  10) calc_elliptic_var: Calculates the elliptic variance of an object
  11) calc_equi_diameter: Calculates the equivalent diameter of an object
  12) calc_gen_fourier_desc: Calculates the generic fourier descriptors of an object
  13) calc_hu_moments: Calculates the seven invariant moments of an object
  14) calc_max_diameter: Calculates the maximum diameter of an object
  15) calc_obj_area: Calculates the area of an object using Bit-Quads
  16) calc_obj_centroid: Calculates the centroid of an object
  17) calc_radial_dist_feats: Calculates the radial distance features { mean, 
                              standard deviation, entropy, roughness } of an object
  18) calc_rectangularity: Calculates the rectangularity of an object
  19) calc_solidity: Calculates the solidity of an object
  20) calc_triangularity: Calculates the triangularity of an object
  21) calc_zernike_moments: Calculates the zernike moments of an object
   
K. Color Image Segmentation
   1) graph_segment: Efficient Graph-Based Segmentation method
   2) srm: Statistical Region Merging method

L. Color Space Conversions
   1) rgb_to_hsv: RGB to HSV conversion
   2) hsv_to_rgb: HSV to RGB conversion
   3) rgb_to_hsl: RGB to HSL conversion
   4) hsl_to_rgb: HSL to RGB conversion
   5) rgb_to_hsi: RGB to HSI conversion
   6) rgb_to_hsi_kender: RGB to HSI conversion (Kender's formulation)
   7) hsi_to_rgb: HSI to RGB conversion
   8) rgb_to_l1l2l3: RGB to l1l2l3 conversion
   9) rgb_to_nrgb: RGB to normalized RGB conversion
  10) rgb_to_ohta: RGB to Ohta (I1I2I3) space conversion
  11) ohta_to_rgb: Ohta (I1I2I3) space to RGB conversion
  12) rgb_to_sct: RGB to SCT (Spherical Coordinate Transform) space conversion
  13) sct_to_rgb: SCT (Spherical Coordinate Transform) space to RGB conversion
  14) rgb_to_lab: RGB to CIE-Lab conversion
  15) lab_to_rgb: CIE-Lab to RGB conversion
  16) rgb_to_luv: RGB to CIE-Luv conversion
  17) luv_to_rgb: CIE-Luv to RGB conversion
  18) lab_to_lch: CIE-Lab to CIE-LCH conversion
  19) lch_to_lab: CIE-LCH to CIE-Lab conversion

M. Color Quantization
   1) quant_neural: NeuQuant (Neural Network Quantization) method
   2) quant_wan: Wan's variance-based method
   3) quant_wu: Wu's method

N. Color Image Smoothing & Noise Removal
   1) filter_abvdf: Adaptive Basic Vector Directional Filter
   2) filter_acwddf: Adaptive Center-Weighted Vector Directional Filter
   3) filter_acwvdf: Adaptive Center-Weighted Directional-Distance Filter
   4) filter_acwvmf: Adaptive Center-Weighted Vector Median Filter
   5) filter_ahdf: Adaptive Hybrid Directional Filter
   6) filter_amnfe: Adaptive Multichannel Non-Parametric Filter with Exponential Kernel
   7) filter_amnfg: Adaptive Multichannel Non-Parametric Filter with Gaussian Kernel
   8) filter_annf: Adaptive Nearest Neighbor Filter
   9) filter_annmf: Adaptive Nearest Neighbor Multichannel Filter
  10) filter_asbvdf_mean: Adaptive Sigma Basic Vector Directional Filter based on Mean
  11) filter_asbvdf_rank: Adaptive Sigma Basic Vector Directional Filter based on Rank
  12) filter_asddf_mean: Adaptive Sigma Directional Distance Filter based on Mean
  13) filter_asddf_rank: Adaptive Sigma Directional Distance Filter based on Rank
  14) filter_asvmf_mean: Adaptive Sigma Vector Median Filter based on Mean
  15) filter_asvmf_rank: Adaptive Sigma Vector Median Filter based on Rank
  16) filter_atvmf: Alpha-Trimmed Vector Median Filter
  17) filter_avmf: Adaptive Vector Median Filter
  18) filter_bvdf: Basic Vector Directional Filter
  19) filter_cbrf: Content-Based Rank Filter
  20) filter_cfmf: Combined Fuzzy Metric Filter
  21) filter_ddf: Directional Distance Filter
  22) filter_ebvdf: Entropy Basic Vector Directional Filter 
  23) filter_eddf: Entropy Directional Distance Filter 
  24) filter_evmf: Entropy Vector Median Filter 
  25) filter_exvmf: Extended Vector Median Filter
  26) filter_fddrhf: Fuzzy Vector Directional-Rational Hybrid Filter
  27) filter_ffnrf: Fast Fuzzy Noise Reduction Filter
  28) filter_fmvmf: Fast Modified Vector Median Filter
  29) filter_fmvdf: Fuzzy Metric Vector Directional Filter
  30) filter_fmddf: Fuzzy Metric Directional Distance Filter
  31) filter_fovdf: Fuzzy Ordered Vector Directional Filter
  32) filter_fovmf: Fuzzy Ordered Vector Median Filter
  33) filter_fpgf: Fast Peer Group Filter
  34) filter_fvdf: Fuzzy Vector Directional Filter
  35) filter_fvdrhf: Fuzzy Vector Directional-Rational Hybrid Filter 
  36) filter_fvmf: Fuzzy Vector Median Filter
  37) filter_fvmrhf: Fuzzy Vector Median-Rational Hybrid Filter
  38) filter_gvdf: Generalized Vector Directional Filter
  39) filter_hdf: Hybrid Directional Filter
  40) filter_kvmf: Kernel Vector Median Filter
  41) filter_mcwvmf: Modified Center-Weighted Vector Median Filter
  42) filter_mmf: Marginal (Component-Wise) Median Filter
  43) filter_pgf: Peer Group Filter
  44) filter_pvof: Pairwise Vector Ordering Filter
  45) filter_rodsvmf: Rank-Ordered Differences Statistic Based Vector Median Filter
  46) filter_sbvdf_mean: Sigma Basic Vector Directional Filter based on Mean
  47) filter_sbvdf_rank: Sigma Basic Vector Directional Filter based on Rank
  48) filter_sddf_mean: Sigma Directional Distance Filter based on Mean
  49) filter_sddf_rank: Sigma Directional Distance Filter based on Rank
  50) filter_svmf_mean: Sigma Vector Median Filter based on Mean
  51) filter_svmf_rank: Sigma Vector Median Filter based on Rank
  52) filter_vmf: Vector Median Filter
  53) filter_vmrhf: Vector Median-Rational Hybrid Filter
  54) filter_vsdromf: Vector Signal-Dependent Rank Order Mean Filter

Currently, we are in the process of migrating existing code to expand
the functionality of Fourier. The following is a list of already 
implemented (indicated by +) or planned (indicated by -) functionality 
to be included in future releases:

A. Image I/O
   1) Support for raw image format ( - )
   2) Support for plain (ASCII) PNM image format ( + )
   3) Support for TIFF format ( - )

B. Color Space Conversions
  1) Trilinear interpolation { standard, caching } ( + )
  2) Prism interpolation { standard, caching } ( + )
  3) Pyramidal interpolation { standard, caching } ( + )
  4) Tetrahedral interpolation { standard, caching } ( + )

C. Grayscale Image Smoothing & Noise Removal
   1) Meanshift filter ( + )

D. Grayscale Image Enhancement
   1) Fuzzy Histogram Hyperbolization ( + )
   2) Contrast Limited Adaptive Histogram Equalization ( + )

E. Thresholding (Binarization)
   1) Kittler-Illingworth { Minimum Error } ( + )
   2) Lloyd ( + )
   3) Unimodal Thresholding ( - )

F. Binary Image Processing ( + )
   1) Distance Transform ( + )
   
G. Shape Feature Extraction
   1) Perimeter ( - )
   2) Asymmetry ( + )
   3) Pattern Spectrum ( + )
   4) Fourier Descriptor ( + )
   5) Chebyshev { Tchebichef } Moments ( + )

H. Color Feature Extraction
   1) Color Histogram ( + )
   2) Color Coherence Vector ( + )
   3) Color Correlogram ( - )

I. Texture Feature Extraction
   1) GLCM-based Texture Features ( + )
   2) Grey-Tone Difference Matrix Features ( + )
   3) Law's Texture Measures ( - )
   4) Gabor Texture Features ( - )

J. Color Image Segmentation
   1) Mean-Shift Clustering ( - )
