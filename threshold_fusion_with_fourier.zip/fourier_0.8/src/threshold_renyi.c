
/** 
 * @file threshold_renyi.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** @cond INTERNAL_MACRO */
#define SWAP_INT( a, b ) { tmp_var = ( a ); ( a ) = ( b ); ( b ) = tmp_var; }

/** @endcond INTERNAL_MACRO */

/** 
 * @brief Implements Sahoo et al.'s thresholding method
 *
 * @param[in] img Image pointer { grayscale }
 *
 * @return Threshold value or INT_MIN
 *
 * @ref Sahoo P.K., Wilkins C., and Yeager J. (1997) "Threshold Selection
 *      Using Renyi's Entropy" Pattern Recognition, 30(1): 71-84
 *
 * @author M. Emre Celebi
 * @date 06.23.2007
 */

int
threshold_renyi ( const Image * img )
{
 SET_FUNC_NAME ( "threshold_renyi" );
 int ih, it;
 int threshold;
 int opt_threshold;
 int first_bin;			/* see below */
 int last_bin;			/* see below */
 int tmp_var;
 int t_star1, t_star2, t_star3;
 int beta1, beta2, beta3;
 double alpha;			/* alpha parameter of the method */
 double term;
 double tot_ent;		/* total entropy */
 double max_ent;		/* max entropy */
 double ent_back;		/* entropy of the background pixels at a given threshold */
 double ent_obj;		/* entropy of the object pixels at a given threshold */
 double omega;
 double *data;			/* normalized histogram data */
 double *P1;			/* cumulative normalized histogram */
 double *P2;			/* see below */
 Histo *norm_histo;		/* normalized histogram */

 if ( !is_gray_img ( img ) )
  {
   ERROR_RET ( "Not a grayscale image !", INT_MIN );
  }

 /* Calculate the normalized histogram */
 norm_histo = normalize_histo ( create_histo ( img ) );
 if ( IS_NULL ( norm_histo ) )
  {
   ERROR_RET ( "normalize_histo() failed !", INT_MIN );
  }

 data = get_histo_data ( norm_histo );

 /* Calculate the cumulative normalized histogram */
 P1 = accumulate_histo ( norm_histo );

 P2 = ( double * ) malloc ( NUM_GRAY * sizeof ( double ) );

 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   P2[ih] = 1.0 - P1[ih];
  }

 /* 
    Determine the first non-zero 
    bin starting from the first bin 
  */
 first_bin = 0;
 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   if ( !IS_ZERO ( P1[ih] ) )
    {
     first_bin = ih;
     break;
    }
  }

 /* 
    Determine the first non-one bin 
    starting from the last bin
  */
 last_bin = MAX_GRAY;
 for ( ih = MAX_GRAY; ih >= first_bin; ih-- )
  {
   if ( !IS_ZERO ( P2[ih] ) )
    {
     last_bin = ih;
     break;
    }
  }

 /* Maximum Entropy Thresholding - BEGIN */
 /* ALPHA = 1.0 */
 /* 
    Calculate the total entropy at each gray-level 
    and find the threshold that maximizes it 
  */
 threshold = INT_MIN;
 max_ent = 0.0;
 for ( it = first_bin; it <= last_bin; it++ )
  {
   /* Entropy of the background pixels */
   ent_back = 0.0;
   for ( ih = 0; ih <= it; ih++ )
    {
     if ( !IS_ZERO ( data[ih] ) )
      {
       ent_back -= ( data[ih] / P1[it] ) * log ( data[ih] / P1[it] );
      }
    }

   /* Entropy of the object pixels */
   ent_obj = 0.0;
   for ( ih = it + 1; ih < 256; ih++ )
    {
     if ( !IS_ZERO ( data[ih] ) )
      {
       ent_obj -= ( data[ih] / P2[it] ) * log ( data[ih] / P2[it] );
      }
    }

   /* Total entropy */
   tot_ent = ent_back + ent_obj;

   if ( tot_ent > max_ent )
    {
     max_ent = tot_ent;
     threshold = it;
    }
  }

 t_star2 = threshold;
 /* Maximum Entropy Thresholding - END */

 threshold = INT_MIN;
 max_ent = 0.0;
 alpha = 0.5;
 term = 1.0 / ( 1.0 - alpha );
 for ( it = first_bin; it <= last_bin; it++ )
  {
   /* Entropy of the background pixels */
   ent_back = 0.0;
   for ( ih = 0; ih <= it; ih++ )
    {
     ent_back += sqrt ( data[ih] / P1[it] );
    }

   /* Entropy of the object pixels */
   ent_obj = 0.0;
   for ( ih = it + 1; ih < 256; ih++ )
    {
     ent_obj += sqrt ( data[ih] / P2[it] );
    }

   /* Total entropy */
   tot_ent = term * SAFE_LOG ( ent_back * ent_obj );

   if ( tot_ent > max_ent )
    {
     max_ent = tot_ent;
     threshold = it;
    }
  }

 t_star1 = threshold;

 threshold = INT_MIN;
 max_ent = 0.0;
 alpha = 2.0;
 term = 1.0 / ( 1.0 - alpha );
 for ( it = first_bin; it <= last_bin; it++ )
  {
   /* Entropy of the background pixels */
   ent_back = 0.0;
   for ( ih = 0; ih <= it; ih++ )
    {
     ent_back += ( data[ih] * data[ih] ) / ( P1[it] * P1[it] );
    }

   /* Entropy of the object pixels */
   ent_obj = 0.0;
   for ( ih = it + 1; ih < 256; ih++ )
    {
     ent_obj += ( data[ih] * data[ih] ) / ( P2[it] * P2[it] );
    }

   /* Total entropy */
   tot_ent = term * SAFE_LOG ( ent_back * ent_obj );

   if ( tot_ent > max_ent )
    {
     max_ent = tot_ent;
     threshold = it;
    }
  }

 t_star3 = threshold;

 /* Sort t_star values */
 if ( t_star2 < t_star1 )
  {
   SWAP_INT ( t_star1, t_star2 );
  }
 if ( t_star3 < t_star2 )
  {
   SWAP_INT ( t_star2, t_star3 );
  }
 if ( t_star2 < t_star1 )
  {
   SWAP_INT ( t_star1, t_star2 );
  }

 /* Adjust beta values */
 if ( abs ( t_star1 - t_star2 ) <= 5 )
  {
   if ( abs ( t_star2 - t_star3 ) <= 5 )
    {
     beta1 = 1;
     beta2 = 2;
     beta3 = 1;
    }
   else
    {
     beta1 = 0;
     beta2 = 1;
     beta3 = 3;
    }
  }
 else
  {
   if ( abs ( t_star2 - t_star3 ) <= 5 )
    {
     beta1 = 3;
     beta2 = 1;
     beta3 = 0;
    }
   else
    {
     beta1 = 1;
     beta2 = 2;
     beta3 = 1;
    }
  }

 /* Determine the optimal threshold value */
 omega = P1[t_star3] - P1[t_star1];
 opt_threshold = t_star1 * ( P1[t_star1] + 0.25 * omega * beta1 )
  + 0.25 * t_star2 * omega * beta2
  + t_star3 * ( P2[t_star3] + 0.25 * omega * beta3 );

 free_histo ( norm_histo );
 free ( P1 );
 free ( P2 );

 return opt_threshold;
}

#undef SWAP_INT
