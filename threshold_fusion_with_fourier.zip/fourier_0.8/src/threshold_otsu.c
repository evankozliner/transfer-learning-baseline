
/** 
 * @file threshold_otsu.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Otsu's thresholding method
 *
 * @param[in] img Image pointer { grayscale }
 *
 * @return Threshold value or INT_MIN
 *
 * @ref Otsu N. (1979) "A Threshold Selection Method from Gray Level Histograms" 
 *      IEEE Trans. on Systems, Man and Cybernetics, 9(1): 62-66
 *
 * @author M. Emre Celebi
 * @date 06.15.2007
 */

int
threshold_otsu ( const Image * img )
{
 SET_FUNC_NAME ( "threshold_otsu" );
 int ih;
 int threshold;
 int first_bin;			/* see below */
 int last_bin;			/* see below */
 double total_mean;		/* mean gray-level for the whole image */
 double bcv;			/* between-class variance */
 double max_bcv;		/* max BCV */
 double *cnh;			/* cumulative normalized histogram */
 double *mean;			/* mean gray-level */
 double *data;			/* normalized histogram data */
 Histo *norm_histo;		/* normalized histogram */

 if ( !is_gray_img ( img ) )
  {
   ERROR_RET ( "Not a grayscale image !", INT_MIN );
  }

 /* Calculate the normalized histogram */
 norm_histo = normalize_histo ( create_histo ( img ) );
 if ( IS_NULL ( norm_histo ) )
  {
   ERROR_RET ( "normalize_histo() failed !", INT_MIN );
  }

 data = get_histo_data ( norm_histo );

 /* Calculate the cumulative normalized histogram */
 cnh = accumulate_histo ( norm_histo );

 mean = ( double * ) malloc ( NUM_GRAY * sizeof ( double ) );

 mean[0] = 0.0;
 for ( ih = 0 + 1; ih < NUM_GRAY; ih++ )
  {
   mean[ih] = mean[ih - 1] + ih * data[ih];
  }

 total_mean = mean[MAX_GRAY];

 /* 
    Determine the first non-zero 
    bin starting from the first bin 
  */
 first_bin = 0;
 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   if ( !IS_ZERO ( cnh[ih] ) )
    {
     first_bin = ih;
     break;
    }
  }

 /* 
    Determine the first non-one bin 
    starting from the last bin
  */
 last_bin = MAX_GRAY;
 for ( ih = MAX_GRAY; ih >= first_bin; ih-- )
  {
   if ( !IS_ZERO ( 1.0 - cnh[ih] ) )
    {
     last_bin = ih;
     break;
    }
  }

 /* 
    Calculate the BCV at each gray-level and
    find the threshold that maximizes it 
  */
 threshold = INT_MIN;
 max_bcv = 0.0;
 for ( ih = first_bin; ih <= last_bin; ih++ )
  {
   bcv = total_mean * cnh[ih] - mean[ih];
   bcv *= bcv / ( cnh[ih] * ( 1.0 - cnh[ih] ) );

   if ( max_bcv < bcv )
    {
     max_bcv = bcv;
     threshold = ih;
    }
  }

 free_histo ( norm_histo );
 free ( cnh );
 free ( mean );

 return threshold;
}
