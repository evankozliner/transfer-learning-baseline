
/** 
 * @file rectangularity.c
 * Routines for the calculation of MBR (Minimum Bounding Rectangle) and Rectangularity
 */

#include <image.h>

/** 
 * @brief Calculates the Minimum Area Bounding Rectangle of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 * @param[out] area Area of the bounding rectangle
 *
 * @return Corners of the Minimum Area Bounding Rectangle or NULL
 *         corner[0]: Upper Left,
 *         corner[1]: Upper Right, 
 *         corner[2]: Lower Right, 
 *         corner[3]: Lower Left
 *
 * @author Cyrill Stachniss
 * @date 11.18.2007
 */

PointList *
calc_min_area_rect ( const Image * img, const int label, const PointList * cont,
		     double *area )
{
 SET_FUNC_NAME ( "calc_min_area_rect" );
 int ik;
 int num_pts;
 double row_mean, col_mean;
 double row_delta, col_delta;
 double c1, c2, c3, c4;		/* Entries of the covariance matrix */
 double lambda1, lambda2;	/* Eigenvalues of the covariance matrix */
 double ev1_row, ev1_col;	/* Eigenvector #1 of the covariance matrix */
 double ev2_row, ev2_col;	/* Eigenvector #2 of the covariance matrix */
 double ev1_len, ev2_len;	/* Lengths of the eigenvectors */
 double dot_row, dot_col;
 double min_row, min_col;
 double max_row, max_col;
 Point *centroid;
 PointList *corner;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", NULL );
  }

 /* 
  * Calculate the object centroid. This is more robust 
  * than the contour centroid which is sensitive to noise. 
  */
 centroid = calc_obj_centroid ( img, label );
 row_mean = centroid->row;
 col_mean = centroid->col;

 num_pts = get_num_pts ( cont );

 /* Calculate the covariance matrix (c1 c2, c3 c4) */
 c1 = c2 = c4 = 0.0;

 for ( ik = 0; ik < num_pts; ik++ )
  {
   row_delta = cont->point[ik]->row - row_mean;
   col_delta = cont->point[ik]->col - col_mean;

   c1 += col_delta * col_delta;
   c2 += row_delta * col_delta;
   c4 += row_delta * row_delta;
  }

 c1 /= ( num_pts - 1 );
 c2 /= ( num_pts - 1 );
 c3 = c2;
 c4 /= ( num_pts - 1 );

 /* 
  * Calculate the eigenvectors
  * Catch 1 / 0 or sqrt ( < 0 )
  */
 if ( IS_ZERO ( c3 ) || IS_ZERO ( c2 ) ||
      IS_NEG ( c4 * c4 - 2 * c1 * c4 + c1 * c1 + 4 * c2 * c3 ) )
  {
   ERROR_RET ( "Covariance matrix is ill-conditioned !", NULL );
  }

 /* Calculate the eigenvalues */
 lambda1 =
  0.5 * ( c4 + c1 + sqrt ( c4 * c4 - 2 * c1 * c4 + c1 * c1 + 4 * c2 * c3 ) );
 lambda2 =
  0.5 * ( c4 + c1 - sqrt ( c4 * c4 - 2 * c1 * c4 + c1 * c1 + 4 * c2 * c3 ) );

 /* Calculate eigenvector 1 */
 ev1_row = ( c4 - lambda1 ) * ( c1 - lambda1 ) / ( c2 * c3 );
 ev1_col =
  -( c4 - lambda1 ) * ( c4 - lambda1 ) * ( c1 - lambda1 ) / ( c2 * c3 * c3 );

 /* Calculate eigenvector 2 */
 ev2_row = ( c4 - lambda2 ) * ( c1 - lambda2 ) / ( c2 * c3 );
 ev2_col =
  -( c4 - lambda2 ) * ( c4 - lambda2 ) * ( c1 - lambda2 ) / ( c2 * c3 * c3 );

 /* Normalize the eigenvectors */
 ev1_len = sqrt ( ev1_row * ev1_row + ev1_col * ev1_col );
 ev2_len = sqrt ( ev2_row * ev2_row + ev2_col * ev2_col );

 ev1_row /= ev1_len;
 ev1_col /= ev1_len;
 ev2_row /= ev2_len;
 ev2_col /= ev2_len;

 /* Determine the points with the maximum dot-product */
 min_row = min_col = DBL_MAX;
 max_row = max_col = DBL_MIN;

 for ( ik = 0; ik < num_pts; ik++ )
  {
   /* Dot-product of relative coordinates of every point */
   dot_row =
    ( cont->point[ik]->row - row_mean ) * ev2_row + ( cont->point[ik]->col -
						      col_mean ) * ev2_col;
   dot_col =
    ( cont->point[ik]->row - row_mean ) * ev1_row + ( cont->point[ik]->col -
						      col_mean ) * ev1_col;

   if ( dot_row < min_row )
    {
     min_row = dot_row;
    }
   if ( max_row < dot_row )
    {
     max_row = dot_row;
    }
   if ( dot_col < min_col )
    {
     min_col = dot_col;
    }
   if ( max_col < dot_col )
    {
     max_col = dot_col;
    }
  }

 /* Determine the corners of the bounding rectangle */
 corner = alloc_point_list ( 4 );

 /* Upper Left Corner */
 corner->point[0] =
  alloc_point ( row_mean + min_col * ev1_row + min_row * ev2_row,
		col_mean + min_col * ev1_col + min_row * ev2_col );

 /* Upper Right Corner */
 corner->point[1] =
  alloc_point ( row_mean + max_col * ev1_row + min_row * ev2_row,
		col_mean + max_col * ev1_col + min_row * ev2_col );

 /* Lower Right Corner */
 corner->point[2] =
  alloc_point ( row_mean + max_col * ev1_row + max_row * ev2_row,
		col_mean + max_col * ev1_col + max_row * ev2_col );

 /* Lower Left Corner */
 corner->point[3] =
  alloc_point ( row_mean + min_col * ev1_row + max_row * ev2_row,
		col_mean + min_col * ev1_col + max_row * ev2_col );

 /* Calculate the area of the bounding rectangle */
 *area =
  L2_DIST_2D ( corner->point[0]->row, corner->point[0]->col,
	       corner->point[3]->row,
	       corner->point[3]->col ) * L2_DIST_2D ( corner->point[0]->row,
						      corner->point[0]->col,
						      corner->point[1]->row,
						      corner->point[1]->col );

 return corner;
}

/** 
 * @brief Calculates the Rectangularity (ratio of the area of the object 
 *        to the area of its minimum bounding rectangle) of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 *
 * @return Rectangularity value or DBL_MIN
 *
 * @ref Rosin P.L. (2003) "Measuring Shape: Ellipticity, Rectangularity, 
 *      and Triangularity" Machine Vision and Applications, 14: 172-184.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_rectangularity ( const Image * img, const int label,
		      const PointList * cont )
{
 SET_FUNC_NAME ( "calc_rectangularity" );
 double rect_area;
 PointList *corner;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", DBL_MIN );
  }

 corner = calc_min_area_rect ( img, label, cont, &rect_area );
 if ( IS_NULL ( corner ) )
  {
   ERROR_RET ( "Error in minimum area bounding rectangle calculation !",
	       DBL_MIN );
  }

 free_point_list ( corner );

 return count_obj_pixels ( img, label ) / rect_area;
}
