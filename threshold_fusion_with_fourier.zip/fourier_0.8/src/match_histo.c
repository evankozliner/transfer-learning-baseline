
/** 
 * @file match_histo.c
 * Routines for Histogram Matching
 */

#include <image.h>

/** 
 * @brief Modifies the histogram of a grayscale image to match a given histogram
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] target_histo Target histogram { integer }
 *
 * @return Pointer to the histogram matched image or NULL
 * @ref Umbaugh S.E. (2005) "Computer Imaging: Digital Image 
 *      Analysis and Processing" CRC Press
 *
 * @author M. Emre Celebi
 * @date 02.09.2008
 */

Image *
match_histo ( const Image * in_img, const Histo * target_histo )
{
 SET_FUNC_NAME ( "match_histo" );
 byte *lut;
 byte *in_data;
 byte *out_data;
 int ih, ik;
 int num_rows, num_cols;
 int num_pixels;
 int index;
 double *source_histo_data;
 double *target_histo_data;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !is_int_histo ( target_histo ) )
  {
   ERROR_RET ( "Target histogram must be of integer type !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;

 /* Calculate the cumulative normalized histograms */
 source_histo_data =
  accumulate_histo ( normalize_histo ( create_histo ( in_img ) ) );
 target_histo_data = accumulate_histo ( normalize_histo ( target_histo ) );

 /* Allocate the lookup-table */
 lut = ( byte * ) malloc ( NUM_GRAY * sizeof ( byte ) );

 /* Match the histograms */
 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   index = MAX_GRAY;
   do
    {
     lut[ih] = index--;
    }
   while ( index >= 0 && source_histo_data[ih] <= target_histo_data[index] );
  }

 /* Allocate the output image */
 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 in_data = get_img_data_1d ( in_img );
 out_data = get_img_data_1d ( out_img );

 /* Apply the LUT to the input image */
 for ( ik = 0; ik < num_pixels; ik++ )
  {
   out_data[ik] = lut[in_data[ik]];
  }

 free ( source_histo_data );
 free ( target_histo_data );
 free ( lut );

 return out_img;
}
