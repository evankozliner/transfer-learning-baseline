
/** 
 * @file srm.c
 * Routines for statistical region merging segmentation
 */

#include <image.h>

typedef struct
{
 int reg1, reg2, delta;
} RegionPair;

static int find_set ( const int *parent, int i );
static int union_set ( const int i, const int j, int *parent, int *rank );
static RegionPair *bucket_sort ( const RegionPair * pair, const int num_elems );

/** @cond INTERNAL_FUNCTION */

static int
find_set ( const int *parent, int i )
{
 while ( parent[i] != i )
  {
   i = parent[i];
  }

 return i;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

static int
union_set ( const int i, const int j, int *parent, int *rank )
{
 if ( rank[i] > rank[j] )
  {
   parent[j] = i;
   return i;
  }

 parent[i] = j;
 if ( rank[i] == rank[j] )
  {
   rank[j]++;
  }

 return j;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

static RegionPair *
bucket_sort ( const RegionPair * pair, const int num_elems )
{
 int ih;
 int *histo;
 int *cum_histo;
 RegionPair *sorted;

 sorted = ( RegionPair * ) calloc ( num_elems, sizeof ( RegionPair ) );
 if ( IS_NULL ( sorted ) )
  {
   return NULL;
  }

 histo = ( int * ) calloc ( NUM_GRAY, sizeof ( int ) );
 cum_histo = ( int * ) malloc ( NUM_GRAY * sizeof ( int ) );

 /* Calculate histogram */
 for ( ih = 0; ih < num_elems; ih++ )
  {
   histo[pair[ih].delta]++;
  }

 /* Calculate cumulative histogram */
 cum_histo[0] = 0;
 for ( ih = 1; ih < NUM_GRAY; ih++ )
  {
   cum_histo[ih] = cum_histo[ih - 1] + histo[ih - 1];
  }

 /* Perform bucket sort */
 for ( ih = 0; ih < num_elems; ih++ )
  {
   sorted[cum_histo[pair[ih].delta]++] = pair[ih];
  }

 free ( histo );
 free ( cum_histo );

 return sorted;
}

/** @endcond INTERNAL_FUNCTION */

/** 
 * @brief Statistical Region Merging segmentation algorithm 
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] Q_value Q parameter of the algorithm (higher values result in 
 *                    more regions) { positive }
 * @param[in] size_factor Regions smaller than SIZE_FACTOR * (# pixels in the
 *                        image) pixels will be merged with others { [0,1] }
 *
 * @return Pointer to the segmented image or NULL
 * @reco For a typical image try Q_VALUE = 32 and SIZE_FACTOR = 0.001
 *
 * @ref Nock R. and Nielsen F. (2004) "Statistical Region Merging" IEEE 
 *      Trans. on Pattern Analysis and Machine Intelligence, 26(11): 1452-1458
 *      http://www.univ-ag.fr/~rnock/Articles/Drafts/tpami04-nn.pdf
 *
 * @author M. Emre Celebi
 * @date 06.22.2007
 */

Image *
srm ( const Image * in_img, const double Q_value, const double size_factor )
{
 SET_FUNC_NAME ( "srm" );
 byte *out_data;
 byte *in_data_1d;
 byte ***in_data_3d;
 int red, green, blue;
 int ir, ic, ik;
 int num_rows, num_cols;
 int num_pixels;
 int num_elems;
 int num_rows_m1, num_cols_m1;
 int cnt, idx;
 int num_edges;
 int reg1, reg2;
 int min_reg_size;		/* minimum region size */
 int root, total_size;
 int *size;			/* holds the region sizes */
 int *parent;			/* holds the parents */
 int *rank;			/* holds the ranks of the trees */
 double log_delta;
 double threshold;		/* threshold for merge operation */
 double thresh_factor;		/* constant used in the computation of the threshold */
 double *red_mean;		/* holds the mean red values of the regions */
 double *green_mean;		/* holds the mean green values of the regions */
 double *blue_mean;		/* holds the mean blue values of the regions */
 RegionPair *pair;		/* holds the region pairs */
 RegionPair *sorted;		/* holds the sorted region pairs */
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( IS_NEG ( Q_value ) )
  {
   ERROR ( "Q value ( %f ) must be positive !", Q_value );
   return NULL;
  }

 if ( !IS_IN_0_1 ( size_factor ) )
  {
   ERROR ( "Size factor ( %f ) must be in [0,1] range !", size_factor );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;
 num_elems = 3 * num_pixels;

 num_rows_m1 = num_rows - 1;
 num_cols_m1 = num_cols - 1;

 in_data_1d = get_img_data_1d ( in_img );
 in_data_3d = get_img_data_nd ( in_img );

 log_delta = 2.0 * log ( 6.0 * num_pixels );
 thresh_factor = ( NUM_GRAY * NUM_GRAY ) / ( 2.0 * Q_value );
 min_reg_size = size_factor * num_pixels;

 red_mean = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 green_mean = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 blue_mean = ( double * ) malloc ( num_pixels * sizeof ( double ) );
 size = ( int * ) malloc ( num_pixels * sizeof ( int ) );
 parent = ( int * ) malloc ( num_pixels * sizeof ( int ) );
 rank = ( int * ) calloc ( num_pixels, sizeof ( int ) );

 if ( IS_NULL ( red_mean ) || IS_NULL ( green_mean ) || IS_NULL ( blue_mean )
      || IS_NULL ( size ) || IS_NULL ( parent ) || IS_NULL ( rank ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* In the beginning, each pixel forms one region */
 cnt = 0;
 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red_mean[cnt] = in_data_1d[ik];
   green_mean[cnt] = in_data_1d[ik + 1];
   blue_mean[cnt] = in_data_1d[ik + 2];
   size[cnt] = 1;
   parent[cnt] = cnt;
   cnt++;
  }

 idx = 0;
 num_edges = 2 * num_cols_m1 * num_rows_m1 + num_rows_m1 + num_cols_m1;
 pair = ( RegionPair * ) calloc ( num_edges, sizeof ( RegionPair ) );
 if ( IS_NULL ( pair ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 cnt = 0;
 for ( ir = 0; ir < num_rows_m1; ir++ )
  {
   for ( ic = 0; ic < num_cols_m1; ic++ )
    {
     red = in_data_3d[ir][ic][0];
     green = in_data_3d[ir][ic][1];
     blue = in_data_3d[ir][ic][2];

     /* East neighbor */
     pair[idx].reg1 = cnt;
     pair[idx].reg2 = cnt + 1;
     pair[idx].delta = MAX_3 ( abs ( in_data_3d[ir][ic + 1][0] - red ),
			       abs ( in_data_3d[ir][ic + 1][1] - green ),
			       abs ( in_data_3d[ir][ic + 1][2] - blue ) );

     /* South neighbor */
     idx++;
     pair[idx].reg1 = cnt;
     pair[idx].reg2 = cnt + num_cols;
     pair[idx].delta = MAX_3 ( abs ( in_data_3d[ir + 1][ic][0] - red ),
			       abs ( in_data_3d[ir + 1][ic][1] - green ),
			       abs ( in_data_3d[ir + 1][ic][2] - blue ) );

     idx++;
     cnt++;
    }
   cnt++;
  }

 /* Last column of each row */
 cnt = num_cols_m1;
 for ( ir = 0; ir < num_rows_m1; ir++ )
  {
   pair[idx].reg1 = cnt;
   cnt += num_cols;
   pair[idx].reg2 = cnt;
   pair[idx].delta =
    MAX_3 ( abs
	    ( in_data_3d[ir + 1][num_cols_m1][0] -
	      in_data_3d[ir][num_cols_m1][0] ),
	    abs ( in_data_3d[ir + 1][num_cols_m1][1] -
		  in_data_3d[ir][num_cols_m1][1] ),
	    abs ( in_data_3d[ir + 1][num_cols_m1][2] -
		  in_data_3d[ir][num_cols_m1][2] ) );
   idx++;
  }

 /* Last row of each column */
 cnt = num_rows_m1 * num_cols;
 for ( ic = 0; ic < num_cols_m1; ic++ )
  {
   pair[idx].reg1 = cnt;
   cnt++;
   pair[idx].reg2 = cnt;
   pair[idx].delta =
    MAX_3 ( abs
	    ( in_data_3d[num_rows_m1][ic + 1][0] -
	      in_data_3d[num_rows_m1][ic][0] ),
	    abs ( in_data_3d[num_rows_m1][ic + 1][1] -
		  in_data_3d[num_rows_m1][ic][1] ),
	    abs ( in_data_3d[num_rows_m1][ic + 1][2] -
		  in_data_3d[num_rows_m1][ic][2] ) );
   idx++;
  }

 sorted = bucket_sort ( pair, num_edges );

 /* Merge similar regions */
 for ( ik = 0; ik < num_edges; ik++ )
  {
   reg1 = find_set ( parent, sorted[ik].reg1 );
   reg2 = find_set ( parent, sorted[ik].reg2 );

   if ( reg1 != reg2 )
    {
     threshold = sqrt ( thresh_factor
			*
			( ( ( MIN_2 ( NUM_GRAY, size[reg1] ) *
			      log ( 1.0 + size[reg1] ) +
			      log_delta ) / size[reg1] ) + ( ( MIN_2 ( NUM_GRAY,
								       size
								       [reg2] )
							       * log ( 1.0 +
								       size
								       [reg2] )
							       +
							       log_delta ) /
							     size[reg2] ) ) );

     if ( ( fabs ( red_mean[reg1] - red_mean[reg2] ) < threshold )
	  && ( fabs ( green_mean[reg1] - green_mean[reg2] ) < threshold )
	  && ( fabs ( blue_mean[reg1] - blue_mean[reg2] ) < threshold ) )
      {
       root = union_set ( reg1, reg2, parent, rank );
       total_size = size[reg1] + size[reg2];

       red_mean[root] =
	( size[reg1] * red_mean[reg1] +
	  size[reg2] * red_mean[reg2] ) / total_size;
       green_mean[root] =
	( size[reg1] * green_mean[reg1] +
	  size[reg2] * green_mean[reg2] ) / total_size;
       blue_mean[root] =
	( size[reg1] * blue_mean[reg1] +
	  size[reg2] * blue_mean[reg2] ) / total_size;
       size[root] = total_size;
      }
    }
  }

 /* Merge small regions */
 cnt = 0;
 for ( ir = 0; ir < num_rows; ir++ )
  {
   cnt++;
   for ( ic = 1; ic < num_cols; ic++ )
    {
     reg1 = find_set ( parent, cnt );
     reg2 = find_set ( parent, cnt - 1 );

     if ( ( reg1 != reg2 ) &&
	  ( ( size[reg2] < min_reg_size ) || ( size[reg1] < min_reg_size ) ) )
      {
       root = union_set ( reg1, reg2, parent, rank );
       total_size = size[reg1] + size[reg2];

       red_mean[root] =
	( size[reg1] * red_mean[reg1] +
	  size[reg2] * red_mean[reg2] ) / total_size;
       green_mean[root] =
	( size[reg1] * green_mean[reg1] +
	  size[reg2] * green_mean[reg2] ) / total_size;
       blue_mean[root] =
	( size[reg1] * blue_mean[reg1] +
	  size[reg2] * blue_mean[reg2] ) / total_size;
       size[root] = total_size;
      }
     cnt++;
    }
  }

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 /* Assign each output pixel the mean color of its region */
 cnt = 0;
 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   idx = find_set ( parent, cnt );
   out_data[ik] = red_mean[idx];
   out_data[ik + 1] = green_mean[idx];
   out_data[ik + 2] = blue_mean[idx];
   cnt++;
  }

 free ( red_mean );
 free ( green_mean );
 free ( blue_mean );
 free ( size );
 free ( parent );
 free ( rank );
 free ( pair );
 free ( sorted );

 return out_img;
}
