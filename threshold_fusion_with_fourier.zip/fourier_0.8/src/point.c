
/** 
 * @file point.c
 * Routines for Points
 */

#include <image.h>

/** 
 * @brief Allocates a point object
 * 
 * @param [in] row_val Initial row coordinate
 * @param [in] col_val Initial column coordinate
 *
 * @return Pointer to the point or NULL
 * @see #free_point
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

Point *
alloc_point ( const double row_val, const double col_val )
{
 Point *point = NULL;

 point = MALLOC_STRUCT ( Point );

 /* Initialize the coordinates */
 point->row = row_val;
 point->col = col_val;

 return point;
}

/** 
 * @brief Deallocates a point object
 *
 * @param[in,out] point Point pointer
 *
 * @return none
 *
 * @note nothing happens if the object is invalid
 * @see #alloc_point
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

void
free_point ( Point * point )
{
 if ( !IS_NULL ( point ) )
  {
   free ( point );
   point = NULL;
  }
}

/** 
 * @brief Allocates a point list object
 * 
 * @param [in] num_pts Number of points in the list
 *
 * @return Pointer to the list or NULL
 * @see #free_point_list
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

PointList *
alloc_point_list ( const int num_pts )
{
 SET_FUNC_NAME ( "alloc_point_list" );
 PointList *pnt_list;

 if ( num_pts <= 0 )
  {
   ERROR ( "Number of points ( %d ) must be positive !", num_pts );
   return NULL;
  }

 pnt_list = MALLOC_STRUCT ( PointList );
 pnt_list->num_pts = num_pts;
 /* Until the individual points are allocated the list is INVALID */
 pnt_list->type = GEN_INVALID;

 /* Allocate storage for point list pointer */
 pnt_list->point = ( Point ** ) malloc ( num_pts * sizeof ( Point * ) );
 if ( IS_NULL ( pnt_list->point ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 return pnt_list;
}

/** 
 * @brief Deallocates a point list object
 * 
 * @param [in] pnt_list Point list pointer
 *
 * @return none
 *
 * @note nothing happens if the object is invalid
 * @see #alloc_point_list
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

void
free_point_list ( PointList * pnt_list )
{
 if ( IS_VALID_OBJ ( pnt_list ) )
  {
   int ik;

   for ( ik = pnt_list->num_pts - 1; ik >= 0; ik-- )
    {
     free_point ( pnt_list->point[ik] );
     pnt_list->point[ik] = NULL;
    }

   pnt_list->num_pts = INT_MIN;
  }
}

/** 
 * @brief Returns the # points in a point list
 *
 * @param [in] pnt_list Point list pointer
 *
 * @return # rows if image is valid;
 *         INT_MIN otherwise
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

int
get_num_pts ( const PointList * pnt_list )
{
 SET_FUNC_NAME ( "get_num_pts" );

 if ( !IS_VALID_OBJ ( pnt_list ) )
  {
   ERROR_RET ( "Invalid point list object !", INT_MIN );
  }

 return pnt_list->num_pts;
}

/** 
 * @brief Creates a binary image from a point list
 *
 * @param[in] pnt_list Point list pointer
 * @param[in] num_rows # rows in the image { positive }
 * @param[in] num_cols # cols in the image { positive }
 *
 * @return Pointer to the image or NULL
 *
 * @note Out-of-limit points are ignored
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

Image *
point_list_to_img ( const PointList * pnt_list, const int num_rows,
		    const int num_cols )
{
 SET_FUNC_NAME ( "point_list_to_img" );
 byte **out_data;
 int ik;
 int num_pts;
 int row_val, col_val;
 Image *out_img;

 if ( !IS_VALID_OBJ ( pnt_list ) )
  {
   ERROR_RET ( "Invalid point list object !", NULL );
  }

 if ( num_rows <= 0 )
  {
   ERROR ( "Number of rows ( %d ) must be positive !", num_rows );
   return NULL;
  }

 if ( num_cols <= 0 )
  {
   ERROR ( "Number of cols ( %d ) must be positive !", num_cols );
   return NULL;
  }

 out_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );
 num_pts = get_num_pts ( pnt_list );

 for ( ik = 0; ik < num_pts; ik++ )
  {
   row_val = ( int ) pnt_list->point[ik]->row;	/* truncate */
   if ( row_val < 0 || row_val >= num_rows )
    {
     continue;			/* Ignore out-of-limit points */
    }

   col_val = ( int ) pnt_list->point[ik]->col;	/* truncate */
   if ( col_val < 0 || col_val >= num_cols )
    {
     continue;			/* Ignore out-of-limit points */
    }

   out_data[row_val][col_val] = OBJECT;
  }

 return out_img;
}

/** 
 * @brief Creates a point list from a chain
 *
 * @param[in] chain Chain pointer
 *
 * @return Pointer to the point list or NULL
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

PointList *
chain_to_point_list ( const Chain * chain )
{
 SET_FUNC_NAME ( "chain_to_point_list" );
 int ik;
 int num_pts;
 int *chain_row, *chain_col;
 PointList *pnt_list;

 if ( !IS_VALID_OBJ ( chain ) )
  {
   ERROR_RET ( "Invalid chain code object !", NULL );
  }

 num_pts = get_chain_len ( chain );
 chain_row = get_chain_rows ( chain );
 chain_col = get_chain_cols ( chain );
 pnt_list = alloc_point_list ( num_pts );
 for ( ik = 0; ik < num_pts; ik++ )
  {
   pnt_list->point[ik] = alloc_point ( chain_row[ik], chain_col[ik] );
  }

 pnt_list->type = GEN_VALID;

 return pnt_list;
}
