
/** 
 * @file filter_vmrhf.c
 * Routines for VMRHF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the VMRHF (Vector Median-Rational Hybrid Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] weight Center pixel weight { positive }
 * @param[in] h_value Ensures numerical stability in the rational filter { positive }
 * @param[in] k_value Regulates the nonlinearity of the rational filter { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco The authors recommend WEIGHT = H_VALUE = K_VALUE = 3.0
 *
 * @ref 1) Khriji L. and Gabbouj M. (1999) "A Class of Multichannel Image 
 *         Processing Filters" Electronics Letters, 35(4): 285-287
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
filter_vmrhf ( const Image * in_img, const double weight,
	       const double h_value, const double k_value )
{
 SET_FUNC_NAME ( "filter_vmrhf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 const int win_size = 3;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int min_index[4];
 int index1, index3;
 int *red, *green, *blue;
 int *valid1, *valid3;
 double weight_m1;
 double red_numer, green_numer, blue_numer;
 double denom;
 double dist_sum[4];
 double min_dist[4];
 double alpha[4];
 double **dist_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS ( weight ) )
  {
   ERROR ( "Weight ( %f ) must be positive !", weight );
   return NULL;
  }

 if ( !IS_POS ( h_value ) )
  {
   ERROR ( "H ( %f ) must be positive !", h_value );
   return NULL;
  }

 if ( !IS_POS ( k_value ) )
  {
   ERROR ( "K ( %f ) must be positive !", k_value );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;
 weight_m1 = weight - 1.0;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 valid1 = ( int * ) malloc ( ( center_pix + 1 ) * sizeof ( int ) );
 valid3 = ( int * ) malloc ( ( center_pix + 1 ) * sizeof ( int ) );

 dist_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* In sub-filter 1 only pixels {1, 3, 4, 5, 7} are valid */
 valid1[0] = 1;
 valid1[1] = 3;
 valid1[2] = 4;
 valid1[3] = 5;
 valid1[4] = 7;

 /* In sub-filter 3 only pixels {0, 2, 4, 6, 8} are valid */
 valid3[0] = 0;
 valid3[1] = 2;
 valid3[2] = 4;
 valid3[3] = 6;
 valid3[4] = 8;

 alpha[1] = alpha[3] = 1.0;
 alpha[2] = -2.0;

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the distances between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_mat[iwr][iwc] = DIST_FUNC ( red[iwr], green[iwr], blue[iwr],
					  red[iwc], green[iwc], blue[iwc] );
	}
      }

     /* Determine the output of sub-filter 2 (CWVMF) */
     min_dist[2] = DBL_MAX;
     min_index[2] = center_pix;

     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       dist_sum[2] = 0.0;

       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 dist_sum[2] += dist_mat[iwc][iwr];
	}

       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_sum[2] += dist_mat[iwr][iwc];
	}

       if ( iwr < center_pix )
	{
	 dist_sum[2] += weight_m1 * dist_mat[iwr][center_pix];
	}
       else
	{
	 dist_sum[2] += weight_m1 * dist_mat[center_pix][iwr];
	}

       if ( dist_sum[2] < min_dist[2] )
	{
	 min_dist[2] = dist_sum[2];
	 min_index[2] = iwr;
	}
      }

     /* Determine the outputs of sub-filters 1 and 3 (VMF) */
     min_dist[1] = min_dist[3] = DBL_MAX;
     min_index[1] = min_index[3] = center_pix;

     for ( iwr = 0; iwr <= center_pix; iwr++ )
      {
       dist_sum[1] = dist_sum[3] = 0.0;

       index1 = valid1[iwr];
       index3 = valid3[iwr];

       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 dist_sum[1] += dist_mat[valid1[iwc]][index1];
	 dist_sum[3] += dist_mat[valid3[iwc]][index3];
	}

       for ( iwc = iwr + 1; iwc <= center_pix; iwc++ )
	{
	 dist_sum[1] += dist_mat[index1][valid1[iwc]];
	 dist_sum[3] += dist_mat[index3][valid3[iwc]];
	}

       if ( dist_sum[1] < min_dist[1] )
	{
	 min_dist[1] = dist_sum[1];
	 min_index[1] = index1;
	}

       if ( dist_sum[3] < min_dist[3] )
	{
	 min_dist[3] = dist_sum[3];
	 min_index[3] = index3;
	}
      }

     /* Equation 8 */
     red_numer =
      alpha[1] * red[min_index[1]] + alpha[2] * red[min_index[2]] +
      alpha[3] * red[min_index[3]];
     green_numer =
      alpha[1] * green[min_index[1]] + alpha[2] * green[min_index[2]] +
      alpha[3] * green[min_index[3]];
     blue_numer =
      alpha[1] * blue[min_index[1]] + alpha[2] * blue[min_index[2]] +
      alpha[3] * blue[min_index[3]];

     denom =
      h_value + k_value * DIST_FUNC ( red[min_index[1]], green[min_index[1]],
				      blue[min_index[1]], red[min_index[3]],
				      green[min_index[3]], blue[min_index[3]] );

     /* Output */
     out_data[ir][ic][0] = red[min_index[2]] + red_numer / denom + .5;	/* round */
     out_data[ir][ic][1] = green[min_index[2]] + green_numer / denom + .5;	/* round */
     out_data[ir][ic][2] = blue[min_index[2]] + blue_numer / denom + .5;	/* round */

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( valid1 );
 free ( valid3 );
 free_nd ( dist_mat, 2 );

 return out_img;
}
