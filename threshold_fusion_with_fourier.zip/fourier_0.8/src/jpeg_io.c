
/** 
 * @file jpeg_io.c
 * Routines for reading JPEG pixel data
 */

#include <image.h>
#include "jinclude.h"
#include "jpeglib.h"

/** @cond INTERNAL_FUNCTION */

/** 
 * @brief Reads pixel data of a JPEG file
 *
 * @param[in,out] file_ptr File pointer
 *
 * @return Pointer to the image or NULL
 *
 * @ref Adapted from libjpeg's example.c program

 * @author Thomas G. Lane
 * @date 04.30.2008
 */

Image *
read_jpeg_data ( FILE * file_ptr )
{
 byte *data;
 int row_stride, row, index;
 int num_rows, num_cols;
 struct jpeg_decompress_struct cinfo;
 struct jpeg_error_mgr jerr;
 Image *img;
 JSAMPARRAY buffer;
 JSAMPROW ptr;

 /* Step 1: allocate and initialize JPEG decompression object */

 /* We set up the normal JPEG error routines, then override error_exit. */
 cinfo.err = jpeg_std_error ( &jerr );

 /* Now we can initialize the JPEG decompression object. */
 jpeg_create_decompress ( &cinfo );

 /* Step 2: specify data source (eg, a file) */
 jpeg_stdio_src ( &cinfo, file_ptr );

 /* Step 3: read file parameters with jpeg_read_header() */
 ( void ) jpeg_read_header ( &cinfo, TRUE );

 /* jpeg_calc_output_dimensions ( &cinfo ); */

 /* Step 4: Start decompressor */
 ( void ) jpeg_start_decompress ( &cinfo );

 num_rows = cinfo.output_height;
 num_cols = cinfo.output_width;

 img =
  alloc_img ( ( cinfo.out_color_space == JCS_GRAYSCALE ) ? PIX_GRAY : PIX_RGB,
	      num_rows, num_cols );
 if ( IS_NULL ( img ) )
  {
   return NULL;
  }

 data = get_img_data_1d ( img );

 /* JSAMPLEs per row in output buffer */
 row_stride = cinfo.output_width * cinfo.output_components;

 /* Make a one-row-high sample array that will go away when done with image */
 buffer = ( *cinfo.mem->alloc_sarray ) ( ( j_common_ptr ) & cinfo, JPOOL_IMAGE,
					 row_stride, 1 );

 /* Step 5: while (scan lines remain to be read) */
 /* 
    Here we use the library's state variable cinfo.output_scanline as 
    the loop counter, so that we don't have to keep track ourselves.
  */
 index = 0;
 while ( cinfo.output_scanline < cinfo.output_height )
  {
   ( void ) jpeg_read_scanlines ( &cinfo, buffer, 1 );
   ptr = buffer[0];

   for ( row = 0; row < row_stride; row++ )
    {
     data[index++] = ( byte ) GETJSAMPLE ( *ptr++ );
    }
  }

 /* Step 6: Finish decompression */
 ( void ) jpeg_finish_decompress ( &cinfo );

 /* Step 7: Release JPEG decompression object */
 ( void ) jpeg_destroy_decompress ( &cinfo );

 return img;
}

/** @endcond INTERNAL_FUNCTION */
