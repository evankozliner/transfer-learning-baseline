
/** 
 * @file filter_kuwahara.c
 * Routines for Kuwahara filtering of a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements the Kuwahara filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] k_value An integer that determines the window size ( w = 4 * k + 1 ) { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note 1) Pixels outside the convolution area are set to 0.
 *       2) The median of the minimum-variance sub-window can be used as an
 *          alternative to the mean
 * @ref 1) Kuwahara et al. (1976) "Digital Processing of Biomedical Images" 
 *         Plenum Press, pp. 187-203
 *      2) Young et al. (1998) "Fundamentals of Image Processing"
 *         http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Smoothin.html
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

Image *
filter_kuwahara ( const Image * in_img, const int k_value )
{
 SET_FUNC_NAME ( "filter_kuwahara" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int win_size;
 int half_win;
 int sub_win_count;		/* number of pixels in each sub-window */
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int gray_val;
 int sum[4];
 int sum_sq[4];
 int var[4];
 int min_var;
 int out_val;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( k_value < 1 )
  {
   ERROR ( "K value ( %d ) must be greater than 0 !", k_value );
   return NULL;
  }

 win_size = 4 * k_value + 1;
 half_win = win_size / 2;
 sub_win_count = ( half_win + 1 ) * ( half_win + 1 );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     sum[0] = sum_sq[0] = 0;
     sum[1] = sum_sq[1] = 0;

     for ( iwr = ir - half_win; iwr <= ir; iwr++ )
      {
       /* Sub-Window 0 */
       for ( iwc = ic - half_win; iwc <= ic; iwc++ )
	{
	 gray_val = in_data[iwr][iwc];
	 sum[0] += gray_val;
	 sum_sq[0] += gray_val * gray_val;
	}

       /* Sub-Window 1 */
       for ( iwc = ic; iwc <= ic + half_win; iwc++ )
	{
	 gray_val = in_data[iwr][iwc];
	 sum[1] += gray_val;
	 sum_sq[1] += gray_val * gray_val;
	}
      }

     /* 
        Note: To obtain the actual variances, var[0] and var[1] 
        should be divided by ( sub_win_count ^ 2 ). However, 
        we do not need the actual values to find the minimum one.
      */
     var[0] = ( sub_win_count * sum_sq[0] ) - sum[0] * sum[0];
     var[1] = ( sub_win_count * sum_sq[1] ) - sum[1] * sum[1];

     sum[2] = sum_sq[2] = 0;
     sum[3] = sum_sq[3] = 0;

     for ( iwr = ir; iwr <= ir + half_win; iwr++ )
      {
       /* Sub-Window 2 */
       for ( iwc = ic - half_win; iwc <= ic; iwc++ )
	{
	 gray_val = in_data[iwr][iwc];
	 sum[2] += gray_val;
	 sum_sq[2] += gray_val * gray_val;
	}

       /* Sub-Window 3 */
       for ( iwc = ic; iwc <= ic + half_win; iwc++ )
	{
	 gray_val = in_data[iwr][iwc];
	 sum[3] += gray_val;
	 sum_sq[3] += gray_val * gray_val;
	}
      }

     /* 
        Note: To obtain the actual variances, var[2] and var[3] 
        should be divided by ( sub_win_count ^ 2 ). However, 
        we do not need the actual values to find the minimum one.
      */
     var[2] = ( sub_win_count * sum_sq[2] ) - sum[2] * sum[2];
     var[3] = ( sub_win_count * sum_sq[3] ) - sum[3] * sum[3];

     /* The output is the mean of the minimum-variance sub-window */
     min_var = var[0];
     out_val = sum[0];
     if ( var[1] < min_var )
      {
       min_var = var[1];
       out_val = sum[1];
      }
     if ( var[2] < min_var )
      {
       min_var = var[2];
       out_val = sum[2];
      }
     if ( var[3] < min_var )
      {
       min_var = var[3];
       out_val = sum[3];
      }

     /* Assign the mean of the minimum-variance sub-window to the output pixel */
     out_data[ir][ic] = out_val / sub_win_count;
    }
  }

 return out_img;
}
