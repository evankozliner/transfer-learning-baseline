
/** 
 * @file threshold.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** 
 * @brief Thresholds a grayscale image to obtain a binary image
 *
 * @param[in] gray_img Image pointer { grayscale }
 * @param[in] threshold Threshold level { [0, MAX_GRAY] }
 *
 * @return Pointer to the binary image or NULL
 *
 * @author M. Emre Celebi
 * @date 10.15.2006
 */

Image *
threshold_img ( const Image * gray_img, const int threshold )
{
 SET_FUNC_NAME ( "threshold_img" );
 byte *gray_data;
 byte *bin_data;
 int ih;
 int num_rows, num_cols;
 int num_pixels;
 Image *bin_img;

 if ( !is_gray_img ( gray_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( ( threshold < 0 ) || ( threshold > MAX_GRAY ) )
  {
   ERROR ( "Threshold ( %d ) must be in [0, %d] range !", threshold, MAX_GRAY );
   return NULL;
  }

 num_rows = get_num_rows ( gray_img );
 num_cols = get_num_cols ( gray_img );
 num_pixels = num_rows * num_cols;

 gray_data = get_img_data_1d ( gray_img );

 bin_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( bin_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 bin_data = get_img_data_1d ( bin_img );

 /* Threshold pixels */
 for ( ih = 0; ih < num_pixels; ih++ )
  {
   bin_data[ih] = ( ( gray_data[ih] > threshold ) ? OBJECT : BACKGROUND );
  }

 return bin_img;
}
