
/** 
 * @file threshold_shanbhag.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Shanbhag's fuzzy thresholding method
 *
 * @param[in] img Image pointer { grayscale }
 *
 * @return Threshold value or INT_MIN
 *
 * @ref Shanbag A.G. (1994) "Utilization of Information Measure as a Means of
 *      Image Thresholding" Graphical Models and Image Processing, 56(5): 414-419
 *
 * @author M. Emre Celebi
 * @date 06.15.2007
 */

int
threshold_shanbhag ( const Image * img )
{
 SET_FUNC_NAME ( "threshold_shanbhag" );
 int ih, it;
 int threshold;
 int first_bin;			/* see below */
 int last_bin;			/* see below */
 double term;
 double tot_ent;		/* total fuzzy entropy */
 double min_ent;		/* min fuzzy entropy */
 double ent_back;		/* entropy of the background pixels at a given threshold */
 double ent_obj;		/* entropy of the object pixels at a given threshold */
 double *data;			/* normalized histogram data */
 double *P1;			/* cumulative normalized histogram */
 double *P2;			/* see below */
 Histo *norm_histo;		/* normalized histogram */

 if ( !is_gray_img ( img ) )
  {
   ERROR_RET ( "Not a grayscale image !", INT_MIN );
  }

 /* Calculate the normalized histogram */
 norm_histo = normalize_histo ( create_histo ( img ) );
 if ( IS_NULL ( norm_histo ) )
  {
   ERROR_RET ( "normalize_histo() failed !", INT_MIN );
  }

 data = get_histo_data ( norm_histo );

 /* Calculate the cumulative normalized histogram */
 P1 = accumulate_histo ( norm_histo );

 P2 = ( double * ) malloc ( NUM_GRAY * sizeof ( double ) );

 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   P2[ih] = 1.0 - P1[ih];
  }

 /* 
    Determine the first non-zero 
    bin starting from the first bin 
  */
 first_bin = 0;
 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   if ( !IS_ZERO ( P1[ih] ) )
    {
     first_bin = ih;
     break;
    }
  }

 /* 
    Determine the first non-one bin 
    starting from the last bin
  */
 last_bin = MAX_GRAY;
 for ( ih = MAX_GRAY; ih >= first_bin; ih-- )
  {
   if ( !IS_ZERO ( P2[ih] ) )
    {
     last_bin = ih;
     break;
    }
  }

 /* 
    Calculate the total fuzzy entropy at each gray-level 
    and find the threshold that minimizes it 
  */
 threshold = INT_MIN;
 min_ent = DBL_MAX;
 for ( it = first_bin; it <= last_bin; it++ )
  {
   /* Entropy of the background pixels */
   ent_back = 0.0;
   term = 0.5 / P1[it];
   for ( ih = 0 + 1; ih <= it; ih++ )
    {
     ent_back -= data[ih] * log ( 1.0 - term * P1[ih - 1] );
    }
   ent_back *= term;

   /* Entropy of the object pixels */
   ent_obj = 0.0;
   term = 0.5 / P2[it];
   for ( ih = it + 1; ih < NUM_GRAY; ih++ )
    {
     ent_obj -= data[ih] * log ( 1.0 - term * P2[ih] );
    }
   ent_obj *= term;

   /* Total fuzzy entropy */
   tot_ent = fabs ( ent_back - ent_obj );

   if ( tot_ent < min_ent )
    {
     min_ent = tot_ent;
     threshold = it;
    }
  }

 free_histo ( norm_histo );
 free ( P1 );
 free ( P2 );

 return threshold;
}
