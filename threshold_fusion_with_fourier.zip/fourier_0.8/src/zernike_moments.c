
/** 
 * @file zernike_moments.c
 * Routines for the rotation, scaling, translation invariant Zernike Moments
 */

#include <image.h>

static int calc_num_terms ( const int max_order );
static ZernikeBasis *alloc_zernike_basis ( const int max_order,
					   const int radius );

/* 
  if n is even ( n + 1 ) + n * n / 4
  else ( n + 1 ) * ( n * n - 1 ) / 4 
 */

static int
calc_num_terms ( const int max_order )
{
 return ( max_order + 1 ) +
  ( max_order * max_order - ( IS_ODD ( max_order ) ? 1 : 0 ) ) / 4;
}

static ZernikeBasis *
alloc_zernike_basis ( const int max_order, const int radius )
{
 SET_FUNC_NAME ( "alloc_zernike_basis" );
 ZernikeBasis *basis = NULL;

 if ( max_order <= 0 )
  {
   ERROR ( "Max order ( %d ) must be positive !", max_order );
   return NULL;
  }

 if ( radius <= 0 )
  {
   ERROR ( "Radius ( %d ) must be positive !", radius );
   return NULL;
  }

 basis = MALLOC_STRUCT ( ZernikeBasis );
 basis->max_order = max_order;
 basis->radius = radius;
 basis->num_terms = calc_num_terms ( max_order );

 /* Allocate storage for basis data */
 basis->data = alloc_nd ( sizeof ( Complex ), 3, basis->num_terms,
			  2 * radius + 1, 2 * radius + 1 );
 if ( IS_NULL ( basis->data ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 basis->type = GEN_INVALID;

 return basis;
}

/** 
 * @brief Deallocates a Zernike Basis object
 *
 * @param[in] basis Zernike Basis object
 *
 * @return none
 *
 * @note nothing happens if the object is invalid
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

void
free_zernike_basis ( ZernikeBasis * basis )
{
 if ( IS_VALID_OBJ ( basis ) )
  {
   free_nd ( basis->data, 3 );
   basis->data = NULL;

   basis->max_order = INT_MIN;
   basis->radius = INT_MIN;
   basis->num_terms = INT_MIN;

   basis->type = GEN_INVALID;
  }
}

/** 
 * @brief Calculates a Zernike Basis
 *
 * @param[in] max_order Maximum order of the Zernike polynomial { positive }
 * @param[in] radius Radius of the circle into which the object 
 *                   will be scaled to fit { positive }
 *
 * @return Pointer to the Zernike Basis
 *
 * @ref 1) Teague M.R. (1980) "Image Analysis Via the General theory of Moments" 
 *         Journal of Optical Society of America, 70(8): 920-930.
 *      2) Zhang D.S. and Lu G. (2003) "Evaluation of MPEG-7 Shape Descriptors 
 *         Against Other Shape Descriptors" Multimedia Systems, 9(1): 15-30.
 *      3) Zhang D.S. and Lu G. (2004) "Review of Shape Representation and 
 *         Description Techniques" Pattern Recognition, 37(1): 1-19.
 *
 * @author Dengsheng Zhang
 * @date 11.18.2007
 */

ZernikeBasis *
calc_zernike_basis ( const int max_order, const int radius )
{
 SET_FUNC_NAME ( "calc_zernike_basis" );
 int term;
 int n, k, rad, m;
 int ir, ic;
 int diameter;
 int rad_dist;
 double theta;
 double *factorial;
 double **rad_func;
 ZernikeBasis *basis;

 if ( max_order <= 0 )
  {
   ERROR ( "Max order ( %d ) must be positive !", max_order );
   return NULL;
  }

 if ( radius <= 0 )
  {
   ERROR ( "Radius ( %d ) must be positive !", radius );
   return NULL;
  }

 diameter = 2 * radius;

 basis = alloc_zernike_basis ( max_order, radius );
 if ( IS_NULL ( basis ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 rad_func = alloc_nd ( sizeof ( double ), 2, basis->num_terms, radius + 1 );
 if ( IS_NULL ( rad_func ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Pre-calculate the factorial values */
 factorial = ( double * ) malloc ( ( max_order + 1 ) * sizeof ( double ) );
 factorial[0] = 1;
 for ( n = 1; n <= max_order; n++ )
  {
   factorial[n] = n * factorial[n - 1];
  }

 /* Calculate the basis */
 term = 0;
 for ( n = 0; n <= max_order; n++ )
  {
   for ( k = n % 2; k <= n; k += 2 )
    {
     for ( rad = 0; rad < radius; rad++ )
      {
       for ( m = 0; m <= ( n - k ) / 2; m++ )	/* Calculate R(n, k, r) */
	{
	 rad_func[term][rad] += ( NEG_ONE_POW ( m ) * factorial[n - m] *
				  pow ( rad / ( double ) radius, n - 2 * m ) ) /
	  ( factorial[m] * factorial[( n + k ) / 2 - m] *
	    factorial[( n - k ) / 2 - m] );
	}
      }

     for ( ir = 0; ir < diameter; ir++ )
      {
       for ( ic = 0; ic < diameter; ic++ )
	{
	 rad_dist = L2_DIST_2D ( ir, ic, radius, radius );
	 theta = atan2 ( ir - radius, ic - radius );
	 if ( IS_NEG ( theta ) )
	  {
	   theta += TWO_PI;
	  }

	 /* Calculate V(n, k, r, theta), or V(n, k, x, y) */
	 if ( rad_dist <= radius )
	  {
	   basis->data[term][ir][ic].real =
	    rad_func[term][rad_dist] * cos ( k * theta );
	   basis->data[term][ir][ic].imag =
	    rad_func[term][rad_dist] * sin ( k * theta );
	  }
	}
      }

     basis->data[term][radius][radius].real = rad_func[term][0];
     basis->data[term][radius][radius].imag = 0.0;
     term++;
    }
  }

 free_nd ( rad_func, 2 );
 free ( factorial );

 basis->type = GEN_VALID;

 return basis;
}

/** 
 * @brief Calculates the Zernike Moments of an object
 *
 * @param[in] in_img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] basis Zernike Basis pointer
 *
 * @return Pointer to the Zernike Moments or NULL
 *
 * @note Number of terms in the descriptor is given by basis->num_terms
 *
 * @ref 1) Teague M.R. (1980) "Image Analysis Via the General theory of Moments" 
 *         Journal of Optical Society of America, 70(8): 920-930.
 *      2) Zhang D.S. and Lu G. (2003) "Evaluation of MPEG-7 Shape Descriptors 
 *         Against Other Shape Descriptors" Multimedia Systems, 9(1): 15-30.
 *      3) Zhang D.S. and Lu G. (2004) "Review of Shape Representation and 
 *         Description Techniques" Pattern Recognition, 37(1): 1-19.
 *
 * @author Dengsheng Zhang
 * @date 11.18.2007
 */

double *
calc_zernike_moments ( const Image * in_img, const int label,
		       const ZernikeBasis * basis )
{
 SET_FUNC_NAME ( "calc_zernike_moments" );
 byte **img_data;
 int max_order;
 int radius, diameter;
 int num_terms;
 int ir, ic;
 int ik;
 int pix_count;			/* # pixels in the object */
 int num_reps;
 int order;
 int index;
 int *repetition;		/* repetition for each term */
 double dist;
 double circle_area;
 double *zd;
 Complex *zm;
 Image *scaled_img;

 if ( !is_bin_or_label_img ( in_img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( !IS_VALID_OBJ ( basis ) )
  {
   ERROR ( "Invalid zernike basis object !", NULL );
  }

 max_order = basis->max_order;
 radius = basis->radius;
 diameter = 2 * radius;
 num_terms = basis->num_terms;

 /* Scale the object to fit it into a circle */
 scaled_img = circular_scale ( in_img, label, radius );

 /* Scaled image is always binary */
 img_data = get_img_data_nd ( scaled_img );

 zm = ( Complex * ) calloc ( num_terms, sizeof ( Complex ) );
 zd = ( double * ) calloc ( num_terms, sizeof ( double ) );
 if ( IS_NULL ( zm ) || IS_NULL ( zd ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Calculate the Zernike Moments */
 pix_count = 0;
 for ( ir = 0; ir < diameter; ir++ )
  {
   for ( ic = 0; ic < diameter; ic++ )
    {
     dist = L2_DIST_2D ( ir, ic, radius, radius );
     if ( dist < radius && img_data[ir][ic] == OBJECT )
      {
       for ( ik = 0; ik < num_terms; ik++ )
	{
	 zm[ik].real += basis->data[ik][ir][ic].real;
	 zm[ik].imag -= basis->data[ik][ir][ic].imag;
	}
       pix_count++;
      }
    }
  }

 /* Calculate the repetition for each term */
 repetition = ( int * ) malloc ( num_terms * sizeof ( int ) );
 if ( IS_NULL ( repetition ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 num_reps = 1;
 index = 0;
 for ( order = 0; order <= max_order; order++ )
  {
   for ( ik = index; ik < index + num_reps; ik++ )
    {
     repetition[ik] = order;
    }

   index += num_reps;
   if ( IS_ODD ( order ) )
    {
     num_reps++;
    }
  }

 /* Normalize the moments */
 circle_area = PI * radius * radius;
 zm[0].real *= ( repetition[0] + 1 ) / ( PI * circle_area );
 zm[0].imag *= ( repetition[0] + 1 ) / ( PI * circle_area );

 for ( ik = 1; ik < num_terms; ik++ )
  {
   zm[ik].real *= ( repetition[ik] + 1 ) / ( PI * pix_count );
   zm[ik].imag *= ( repetition[ik] + 1 ) / ( PI * pix_count );
  }

 /* Calculate the magnitudes of the moments */
 for ( ik = 0; ik < num_terms; ik++ )
  {
   zd[ik] = L2_NORM_2D ( zm[ik].real, zm[ik].imag );
  }

 free_img ( scaled_img );
 free ( zm );
 free ( repetition );

 return zd;
}
