
/** 
 * @file filter_sddf_rank.c
 * Routines for SDDF_RANK filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the SDDF_RANK (Sigma Directional Distance Filter based on Rank)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] win_size Dimension of the filtering window { positive-odd }
 * @param[in] lambda Tuning parameter { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @reco The authors recommend LAMBDA = 4.0
 *
 * @ref 1) Lukac R., Smolka B., Plataniotis K.N., and Venetsanopoulos A.N. (2006) 
 *         "Vector Sigma Filters for Noise Detection and Removal in Color Images" 
 *         Journal of Visual Communication and Image Representation, 17(1): 1-26
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
filter_sddf_rank ( const Image * in_img, const int win_size,
		   const double lambda )
{
 SET_FUNC_NAME ( "filter_sddf_rank" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int DDF_index;
 int *red, *green, *blue;
 double factor;
 double acos_arg;
 double dist_sum;
 double angle_sum;
 double min_prod;
 double prod_center;
 double product;
 double tolerance;
 double *vec_len;
 double **dist_mat;
 double **angle_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( !IS_POS ( lambda ) )
  {
   ERROR ( "Lambda ( %f ) must be positive !", lambda );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;
 factor = 1.0 + lambda / ( double ) ( win_count - 1 );
 /* 
    In order to avoid using sqrt in the product computations, 
    we need to square the FACTOR 
  */
 factor *= factor;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 vec_len = ( double * ) malloc ( win_count * sizeof ( double ) );

 dist_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );
 angle_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the vector lengths */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       vec_len[iwr] = L2_NORM_3D ( red[iwr], blue[iwr], green[iwr] );
      }

     /* Calculate the angles between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   if ( vec_len[iwc] > 0.0 )
	    {
	     /* Calculate the distance between the two color vectors */
	     dist_mat[iwr][iwc] = DIST_FUNC ( red[iwr], green[iwr], blue[iwr],
					      red[iwc], green[iwc], blue[iwc] );

	     /* ( dot product ) / ( || vector1 || * || vector2 || ) */
	     acos_arg =
	      ( red[iwr] * red[iwc] + green[iwr] * green[iwc] +
		blue[iwr] * blue[iwc] ) / ( vec_len[iwr] * vec_len[iwc] );

	     /* Calculate the angle between the two color vectors */
	     angle_mat[iwr][iwc] = ACOS ( acos_arg );
	    }
	   else
	    {
	     /* Idempotent value */
	     dist_mat[iwr][iwc] = 0.0;
	     angle_mat[iwr][iwc] = 0.0;
	    }
	  }
	}
      }

     /* 
        Calculate the product sums for each pixel and find the minimum.
        Omit the pixels with vector length 0 since their angles with 
        all the other pixels would be 0.0 automatically.
      */
     min_prod = DBL_MAX;
     DDF_index = center_pix;
     prod_center = DBL_MAX;	/* Needed when the center pixel is black */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       if ( vec_len[iwr] > 0.0 )
	{
	 dist_sum = 0.0;
	 angle_sum = 0.0;

	 for ( iwc = 0; iwc < iwr; iwc++ )
	  {
	   dist_sum += dist_mat[iwc][iwr];
	   angle_sum += angle_mat[iwc][iwr];
	  }

	 for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	  {
	   dist_sum += dist_mat[iwr][iwc];
	   angle_sum += angle_mat[iwr][iwc];
	  }

	 product = dist_sum * angle_sum;

	 if ( product < min_prod )
	  {
	   min_prod = product;
	   DDF_index = iwr;
	  }

	 if ( iwr == center_pix )
	  {
	   prod_center = product;
	  }
	}
      }

     tolerance = factor * min_prod;

     /* Center pixel is noise-free */
     if ( prod_center <= tolerance )
      {
       out_data[ir][ic][0] = red[center_pix];
       out_data[ir][ic][1] = green[center_pix];
       out_data[ir][ic][2] = blue[center_pix];
      }
     else			/* Center pixel is noisy => Replace it with DDF output */
      {
       out_data[ir][ic][0] = red[DDF_index];
       out_data[ir][ic][1] = green[DDF_index];
       out_data[ir][ic][2] = blue[DDF_index];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free ( vec_len );
 free_nd ( dist_mat, 2 );
 free_nd ( angle_mat, 2 );

 return out_img;
}
