
/** 
 * @file invariant_moments.c
 * Routines for Hu's RST (rotation, scaling, translation) Invariant Moments 
 * and Flusser's Affine Invariant Moments
 */

#include <image.h>

/** 
 * @brief Calculates the Geometric Moments of an object 
 *        up to the third order
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the Geometric Moments or NULL
 *
 * @ref Hu M.-K. (1962) "Visual Pattern Recognition by Moment Invariants" 
 *      IRE Trans. on Information Theory, IT-8: 179-187.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

/** @cond INTERNAL_MACRO */

#define CALC_GEO_MOMENTS( )\
for ( ir = 0; ir < num_rows; ir++ )\
  {\
   for ( ic = 0; ic < num_cols; ic++ )\
    {\
     if ( data[ir][ic] == label )\
      {\
       gm->m00 += 1.0;\
       gm->m01 += ir;\
       gm->m10 += ic;\
       gm->m11 += ir * ic;\
       gm->m20 += ic * ic;\
       gm->m02 += ir * ir;\
       gm->m12 += ic * ir * ir;\
       gm->m21 += ic * ic * ir;\
       gm->m30 += ic * ic * ic;\
       gm->m03 += ir * ir * ir;\
      }\
    }\
  }\


/** @endcond INTERNAL_MACRO */

GeoMoments *
calc_geo_moments ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_geo_moments" );
 int ir, ic;
 int num_rows, num_cols;
 GeoMoments *gm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 gm = CALLOC_STRUCT ( GeoMoments );

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_GEO_MOMENTS (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_GEO_MOMENTS (  );
  }

 return gm;
}

#undef CALC_GEO_MOMENTS

/** 
 * @brief Calculates the Central Moments of an object 
 *        up to the third order
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the Central Moments or NULL
 *
 * @ref Hu M.-K. (1962) "Visual Pattern Recognition by Moment Invariants" 
 *      IRE Trans. on Information Theory, IT-8: 179-187.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

/** @cond INTERNAL_MACRO */

#define CALC_CENTRAL_MOMENTS( )\
/* Calculate the centroid */\
r_bar = c_bar = 0.0;\
pix_count = 0;\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    if ( data[ir][ic] == label )\
     {\
      r_bar += ir;\
      c_bar += ic;\
      pix_count++;\
     }\
   }\
 }\
cm->m00 = pix_count;\
r_bar /= cm->m00;\
c_bar /= cm->m00;\
/* Calculate the central moments (up to third order)*/\
for ( ir = 0; ir < num_rows; ir++ )\
 {\
  r_dist = ir - r_bar;\
  r_dist_sq = r_dist * r_dist;\
  for ( ic = 0; ic < num_cols; ic++ )\
   {\
    if ( data[ir][ic] == label )\
     {\
      c_dist = ic - c_bar;\
      c_dist_sq = c_dist * c_dist;\
      cm->m02 += r_dist_sq;\
      cm->m03 += r_dist_sq * r_dist;\
      cm->m11 += r_dist * c_dist;\
      cm->m12 += r_dist_sq * c_dist;\
      cm->m21 += c_dist_sq * r_dist;\
      cm->m20 += c_dist_sq;\
      cm->m30 += c_dist_sq * c_dist;\
     }\
   }\
 }\


/** @endcond INTERNAL_MACRO */

GeoMoments *
calc_central_moments ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_central_moments" );
 int ir, ic;
 int num_rows, num_cols;
 int pix_count;
 double r_bar, c_bar;
 double r_dist, c_dist;
 double r_dist_sq, c_dist_sq;
 GeoMoments *cm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 num_rows = get_num_rows ( img );
 num_cols = get_num_cols ( img );

 cm = CALLOC_STRUCT ( GeoMoments );
 cm->m01 = cm->m10 = 0.0;

 if ( is_bin_img ( img ) )
  {
   byte **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }
 else
  {
   int **data = get_img_data_nd ( img );

   CALC_CENTRAL_MOMENTS (  );
  }

 return cm;
}

#undef CALC_CENTRAL_MOMENTS

#if 0

/* WARNING: Numerically unstable on big images */
static GeoMoments *
calc_central_moments_opt ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_central_moments_opt" );
 double r_bar, c_bar;
 GeoMoments *gm;
 GeoMoments *cm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 gm = calc_geo_moments ( img, label );
 r_bar = gm->m01 / gm->m00;	/* Centroid row coord. */
 c_bar = gm->m10 / gm->m00;	/* Centroid col coord. */

 cm = CALLOC_STRUCT ( GeoMoments );

 cm->m00 = gm->m00;
 cm->m01 = cm->m10 = 0.0;
 cm->m20 = gm->m20 - c_bar * gm->m10;
 cm->m02 = gm->m02 - r_bar * gm->m01;
 cm->m30 = gm->m30 - 3. * c_bar * gm->m20 + 2. * c_bar * c_bar * gm->m10;
 cm->m03 = gm->m03 - 3. * r_bar * gm->m02 + 2. * r_bar * r_bar * gm->m01;
 cm->m11 = gm->m11 - r_bar * gm->m10;
 cm->m12 = gm->m12 - 2. * r_bar * gm->m11 -
  c_bar * gm->m02 + 2. * r_bar * r_bar * gm->m10;
 cm->m21 = gm->m21 - 2. * c_bar * gm->m11 -
  r_bar * gm->m20 + 2. * c_bar * c_bar * gm->m01;

 free ( gm );

 return cm;
}
#endif

/** 
 * @brief Calculates the Normalized Central Moments of an object 
 *        up to the third order
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the Normalized Central Moments or NULL
 *
 * @ref Hu M.-K. (1962) "Visual Pattern Recognition by Moment Invariants" 
 *      IRE Trans. on Information Theory, IT-8: 179-187.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

GeoMoments *
calc_norm_central_moments ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_norm_central_moments" );
 double area_sq, area_sqrt_p5;
 GeoMoments *ncm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 ncm = calc_central_moments ( img, label );

 area_sq = ncm->m00 * ncm->m00;
 area_sqrt_p5 = area_sq * sqrt ( ncm->m00 );

 ncm->m11 /= area_sq;
 ncm->m20 /= area_sq;
 ncm->m02 /= area_sq;
 ncm->m21 /= area_sqrt_p5;
 ncm->m12 /= area_sqrt_p5;
 ncm->m30 /= area_sqrt_p5;
 ncm->m03 /= area_sqrt_p5;

 return ncm;
}

/** @cond INTERNAL_MACRO */
#define SQR( x ) ( ( x ) * ( x ) )

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */
#define CUBE( x ) ( ( x ) * ( x ) * ( x ) )

/** @endcond INTERNAL_MACRO */

/** 
 * @brief Calculates Hu's RST Invariant Moments of an object 
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the RST Invariant Moments or NULL
 *
 * @ref Hu M.-K. (1962) "Visual Pattern Recognition by Moment Invariants" 
 *      IRE Trans. on Information Theory, IT-8: 179-187.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

HuMoments *
calc_hu_moments ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_hu_moments" );
 GeoMoments *ncm;
 HuMoments *hm;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 ncm = calc_norm_central_moments ( img, label );

 hm = CALLOC_STRUCT ( HuMoments );

 hm->phi1 = ncm->m20 + ncm->m02;

 hm->phi2 = SQR ( ncm->m20 - ncm->m02 ) + 4 * SQR ( ncm->m11 );

 hm->phi3 = SQR ( ncm->m30 - 3 * ncm->m12 ) + SQR ( 3 * ncm->m21 - ncm->m03 );

 hm->phi4 = SQR ( ncm->m30 + ncm->m12 ) + SQR ( ncm->m21 + ncm->m03 );

 hm->phi5 = ( ncm->m30 - 3 * ncm->m12 ) * ( ncm->m30 + ncm->m12 ) *
  ( SQR ( ncm->m30 + ncm->m12 ) - 3 * SQR ( ncm->m21 + ncm->m03 ) ) +
  ( 3 * ncm->m21 - ncm->m03 ) * ( ncm->m21 + ncm->m03 ) *
  ( 3 * SQR ( ncm->m30 + ncm->m12 ) - SQR ( ncm->m21 + ncm->m03 ) );

 hm->phi6 = ( ncm->m20 - ncm->m02 ) *
  ( SQR ( ncm->m30 + ncm->m12 ) - SQR ( ncm->m21 + ncm->m03 ) ) +
  4 * ncm->m11 * ( ncm->m30 + ncm->m12 ) * ( ncm->m21 + ncm->m03 );

 hm->phi7 = ( 3 * ncm->m21 - ncm->m03 ) * ( ncm->m30 + ncm->m12 ) *
  ( SQR ( ncm->m30 + ncm->m12 ) - 3 * SQR ( ncm->m21 + ncm->m03 ) ) +
  ( 3 * ncm->m12 - ncm->m30 ) * ( ncm->m21 + ncm->m03 ) *
  ( 3 * SQR ( ncm->m12 + ncm->m30 ) - SQR ( ncm->m21 + ncm->m03 ) );

 free ( ncm );

 return hm;
}

/** 
 * @brief Calculates Flusser's Affine Invariant Moments of an object 
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 *
 * @return Pointer to the Affine Invariant Moments or NULL
 *
 * @ref Flusser J. and Suk T. (1993) "Pattern Recognition by Affine Moment 
 *      Invariants" Pattern Recognition, 26(1): 167-174.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

AffineMoments *
calc_affine_moments ( const Image * img, const int label )
{
 SET_FUNC_NAME ( "calc_affine_moments" );
 GeoMoments *cm;
 AffineMoments *am;

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 cm = calc_central_moments ( img, label );

 am = CALLOC_STRUCT ( AffineMoments );

 am->I1 = ( cm->m20 * cm->m02 - SQR ( cm->m11 ) ) / pow ( cm->m00, 4.0 );

 am->I2 =
  ( SQR ( cm->m30 * cm->m03 ) - 6 * cm->m30 * cm->m21 * cm->m12 * cm->m03 +
    4 * cm->m30 * CUBE ( cm->m12 ) + 4 * cm->m03 * CUBE ( cm->m21 ) -
    3 * SQR ( cm->m21 * cm->m12 ) ) / pow ( cm->m00, 10.0 );

 am->I3 = ( cm->m20 * ( cm->m21 * cm->m03 - SQR ( cm->m12 ) ) -
	    cm->m11 * ( cm->m30 * cm->m03 - cm->m21 * cm->m12 ) +
	    cm->m02 * ( cm->m30 * cm->m12 - SQR ( cm->m21 ) ) ) / pow ( cm->m00,
									7.0 );

 am->I4 = ( CUBE ( cm->m20 ) * SQR ( cm->m03 ) - 6 * SQR ( cm->m20 ) * cm->m03 *
	    ( cm->m11 * cm->m12 + cm->m02 * cm->m21 ) +
	    9 * SQR ( cm->m20 * cm->m12 ) * cm->m02 +
	    12 * cm->m20 * SQR ( cm->m11 ) * cm->m21 * cm->m03 +
	    6 * cm->m20 * cm->m11 * cm->m02 * ( cm->m30 * cm->m03 -
						3 * cm->m21 * cm->m12 ) -
	    8 * CUBE ( cm->m11 ) * cm->m30 * cm->m03 -
	    3 * cm->m20 * SQR ( cm->m02 ) * ( 2 * cm->m30 * cm->m12 -
					      3 * SQR ( cm->m21 ) ) +
	    6 * cm->m11 * cm->m02 * cm->m30 * ( 2 * cm->m11 * cm->m12 -
						cm->m02 * cm->m21 ) +
	    CUBE ( cm->m02 ) * SQR ( cm->m30 ) ) / pow ( cm->m00, 11.0 );

 free ( cm );

 return am;
}

#undef SQR
#undef CUBE
