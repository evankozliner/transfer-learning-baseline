
/** 
 * @file quant_neural.c
 * Routines for neural network quantization of a color image
 */

#include <image.h>

/* NeuQuant Neural-Net Quantization Algorithm
 * ------------------------------------------
 *
 * Copyright (c) 1994 Anthony Dekker
 *
 * NEUQUANT Neural-Net quantization algorithm by Anthony Dekker, 1994.
 * See "Kohonen neural networks for optimal colour quantization"
 * in "Network: Computation in Neural Systems" Vol. 5 (1994) pp 351-367.
 * for a discussion of the algorithm.
 * See also  http://members.ozemail.com.au/~dekker/NEUQUANT.HTML
 *
 * Any party obtaining a copy of these files from the author, directly or
 * indirectly, is granted, free of charge, a full and unrestricted irrevocable,
 * world-wide, paid up, royalty-free, nonexclusive right and license to deal
 * in this software and documentation files (the "Software"), including without
 * limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons who receive
 * copies from any such party to do so, with the only requirement being
 * that this copyright notice remain intact.
 */

/* 
  Four primes near 500 - assume no image has a length
  so large that it is divisible by all four primes 
 */
#define prime1		499
#define prime2		491
#define prime3		487
#define prime4		503

/* Network Definitions */

#define netbiasshift	4	/* bias for colour values */
#define ncycles		100	/* no. of learning cycles */

/* Defs for freq and bias */
#define intbiasshift    16	/* bias for fractions */
#define intbias		(((int) 1)<<intbiasshift)
#define gammashift  	10	/* gamma = 1024 */
#define gamma   	(((int) 1)<<gammashift)
#define betashift  	10
#define beta		(intbias>>betashift)	/* beta = 1/1024 */
#define betagamma	(intbias<<(gammashift-betashift))

/* Defs for decreasing radius factor */
#define radiusbiasshift	6	/* at 32.0 biased by 6 bits */
#define radiusbias	(((int) 1)<<radiusbiasshift)
#define radiusdec	30	/* factor of 1/30 each cycle */

/* Defs for decreasing alpha factor */
#define alphabiasshift	10	/* alpha starts at 1.0 */
#define initalpha	(((int) 1)<<alphabiasshift)	/* biased by 10 bits */

/* radbias and alpharadbias used for radpower calculation */
#define radbiasshift	8
#define radbias		(((int) 1)<<radbiasshift)
#define alpharadbshift  (alphabiasshift+radbiasshift)
#define alpharadbias    (((int) 1)<<alpharadbshift)

/* Types */

typedef int pixel[4];		/* BGRc */

static void initnet ( const int netsize, pixel * network, int *bias,
		      int *freq );
static void unbiasnet ( const int netsize, pixel * network );
static int contest ( const int b, const int g, const int r, const int netsize,
		     pixel * network, int *bias, int *freq );
static void altersingle ( const int alpha, const int i, const int b,
			  const int g, const int r, pixel * network );
static void alterneigh ( const int rad, const int i, const int b, const int g,
			 const int r, const int netsize, pixel * network,
			 int *radpower );
static void learn ( const int lengthcount, const int samplefac,
		    const int initradius, const int netsize, byte * p,
		    pixel * network, int *radpower, int *bias, int *freq );

/* Initialise network in range (0,0,0) to (255,255,255) and set parameters */

static void
initnet ( const int netsize, pixel * network, int *bias, int *freq )
{
 int i;
 int *p;

 for ( i = 0; i < netsize; i++ )
  {
   p = network[i];
   p[0] = p[1] = p[2] = ( i << ( netbiasshift + 8 ) ) / netsize;
   freq[i] = intbias / netsize;	/* 1/netsize */
   bias[i] = 0;
  }
}

/* Unbias network to give byte values 0..255 and record position i to prepare for sort */

static void
unbiasnet ( const int netsize, pixel * network )
{
 int i, j, temp;

 for ( i = 0; i < netsize; i++ )
  {
   for ( j = 0; j < 3; j++ )
    {
     temp = ( network[i][j] + ( 1 << ( netbiasshift - 1 ) ) ) >> netbiasshift;
     if ( temp > 255 )
      {
       temp = 255;
      }
     network[i][j] = temp;
    }
   network[i][3] = i;		/* record colour no */
  }
}

/* Search for biased BGR values */

static int
contest ( const int b, const int g, const int r, const int netsize,
	  pixel * network, int *bias, int *freq )
{
 /* finds closest neuron (min dist) and updates freq */
 /* finds best neuron (min dist-bias) and returns position */
 /* for frequently chosen neurons, freq[i] is high and bias[i] is negative */
 /* bias[i] = gamma*((1/netsize)-freq[i]) */

 int i, dist, a, biasdist, betafreq;
 int bestpos, bestbiaspos, bestd, bestbiasd;
 int *p, *f, *n;

 bestd = ~( ( ( int ) 1 ) << 31 );
 bestbiasd = bestd;
 bestpos = -1;
 bestbiaspos = bestpos;
 p = bias;
 f = freq;

 for ( i = 0; i < netsize; i++ )
  {
   n = network[i];
   dist = n[0] - b;
   if ( dist < 0 )
    {
     dist = -dist;
    }
   a = n[1] - g;
   if ( a < 0 )
    {
     a = -a;
    }
   dist += a;
   a = n[2] - r;
   if ( a < 0 )
    {
     a = -a;
    }
   dist += a;
   if ( dist < bestd )
    {
     bestd = dist;
     bestpos = i;
    }
   biasdist = dist - ( ( *p ) >> ( intbiasshift - netbiasshift ) );
   if ( biasdist < bestbiasd )
    {
     bestbiasd = biasdist;
     bestbiaspos = i;
    }
   betafreq = ( *f >> betashift );
   *f++ -= betafreq;
   *p++ += ( betafreq << gammashift );
  }
 freq[bestpos] += beta;
 bias[bestpos] -= betagamma;

 return ( bestbiaspos );
}

/* Move neuron i towards biased (b,g,r) by factor alpha */

static void
altersingle ( const int alpha, const int i, const int b, const int g,
	      const int r, pixel * network )
{
 int *n;

 n = network[i];		/* alter hit neuron */
 *n -= ( alpha * ( *n - b ) ) / initalpha;
 n++;
 *n -= ( alpha * ( *n - g ) ) / initalpha;
 n++;
 *n -= ( alpha * ( *n - r ) ) / initalpha;
}

/* Move adjacent neurons by precomputed alpha*(1-((i-j)^2/[r]^2)) in radpower[|i-j|] */

static void
alterneigh ( const int rad, const int i, const int b, const int g, const int r,
	     const int netsize, pixel * network, int *radpower )
{
 int j, k, lo, hi, a;
 int *p, *q;

 lo = i - rad;
 if ( lo < -1 )
  {
   lo = -1;
  }
 hi = i + rad;
 if ( hi > netsize )
  {
   hi = netsize;
  }

 j = i + 1;
 k = i - 1;
 q = radpower;
 while ( ( j < hi ) || ( k > lo ) )
  {
   a = ( *( ++q ) );
   if ( j < hi )
    {
     p = network[j];
     *p -= ( a * ( *p - b ) ) / alpharadbias;
     p++;
     *p -= ( a * ( *p - g ) ) / alpharadbias;
     p++;
     *p -= ( a * ( *p - r ) ) / alpharadbias;
     j++;
    }
   if ( k > lo )
    {
     p = network[k];
     *p -= ( a * ( *p - b ) ) / alpharadbias;
     p++;
     *p -= ( a * ( *p - g ) ) / alpharadbias;
     p++;
     *p -= ( a * ( *p - r ) ) / alpharadbias;
     k--;
    }
  }
}

/* Main Learning Loop */

static void
learn ( const int lengthcount, const int samplefac, const int initradius,
	const int netsize, byte * p, pixel * network, int *radpower, int *bias,
	int *freq )
{
 byte *lim;
 int i, j, b, g, r;
 int radius, rad, alpha, step, delta, samplepixels;
 int alphadec;

 alphadec = 30 + ( ( samplefac - 1 ) / 3 );
 lim = p + lengthcount;
 samplepixels = lengthcount / ( 3 * samplefac );
 delta = samplepixels / ncycles;
 alpha = initalpha;
 radius = initradius;

 rad = radius >> radiusbiasshift;
 if ( rad <= 1 )
  {
   rad = 0;
  }
 for ( i = 0; i < rad; i++ )
  {
   radpower[i] =
    alpha * ( ( ( rad * rad - i * i ) * radbias ) / ( rad * rad ) );
  }

 if ( ( lengthcount % prime1 ) != 0 )
  {
   step = 3 * prime1;
  }
 else
  {
   if ( ( lengthcount % prime2 ) != 0 )
    {
     step = 3 * prime2;
    }
   else
    {
     if ( ( lengthcount % prime3 ) != 0 )
      {
       step = 3 * prime3;
      }
     else
      {
       step = 3 * prime4;
      }
    }
  }

 i = 0;
 while ( i < samplepixels )
  {
   b = p[0] << netbiasshift;
   g = p[1] << netbiasshift;
   r = p[2] << netbiasshift;

   j = contest ( b, g, r, netsize, network, bias, freq );

   altersingle ( alpha, j, b, g, r, network );
   if ( rad )
    {
     alterneigh ( rad, j, b, g, r, netsize, network, radpower );	/* Alter neighbours */
    }

   p += step;
   if ( p >= lim )
    {
     p -= lengthcount;
    }

   i++;
   if ( i % delta == 0 )
    {
     alpha -= alpha / alphadec;
     radius -= radius / radiusdec;
     rad = radius >> radiusbiasshift;
     if ( rad <= 1 )
      {
       rad = 0;
      }
     for ( j = 0; j < rad; j++ )
      {
       radpower[j] =
	alpha * ( ( ( rad * rad - j * j ) * radbias ) / ( rad * rad ) );
      }
    }
  }
}

/** 
 * @brief Neural network quantization of a color image 
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] num_colors Number of quantization levels { positive }
 * @param[in] sampling_factor 1 / SAMPLING_FACTOR of the input image pixels 
 *                            are used in the learning phase { positive }
 *
 * @return Pointer to the quantized image
 *
 * @todo Perform dithering to improve the visual quality of the output.
 * @ref Dekker A. (1994) "Kohonen Neural Networks for Optimal Colour Quantization" Network: 
 *      Computation in Neural Systems, 5: 351-367
 *      http://members.ozemail.com.au/~dekker/NeuQuant.pdf
 *
 * @author M. Emre Celebi
 * @date 08.07.2007
 */

Image *
quant_neural ( const Image * in_img, const int num_colors,
	       const int sampling_factor )
{
 SET_FUNC_NAME ( "quant_neural" );
 byte *in_data;
 byte *out_data;
 int num_rows, num_cols;
 int num_elems;
 int netsize;
 int initrad, initradius;
 int i, j;
 int min_dist;
 int min_index = 0;
 int dist;
 int *bias;
 int *freq;
 int *radpower;
 pixel *network;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( num_colors <= 0 )
  {
   ERROR ( "Number of colors ( %d ) must be positive !", num_colors );
   return NULL;
  }

 if ( sampling_factor <= 0 )
  {
   ERROR ( "Sampling factor ( %d ) must be positive !", sampling_factor );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_1d ( in_img );
 num_elems = 3 * num_rows * num_cols;

 netsize = num_colors;
 initrad = netsize >> 3;
 initradius = initrad * radiusbias;

 network = ( pixel * ) calloc ( netsize, sizeof ( pixel ) );
 bias = ( int * ) calloc ( netsize, sizeof ( int ) );
 freq = ( int * ) calloc ( netsize, sizeof ( int ) );
 radpower = ( int * ) calloc ( initrad, sizeof ( int ) );

 initnet ( netsize, network, bias, freq );
 learn ( num_elems, sampling_factor, initradius, netsize, in_data, network,
	 radpower, bias, freq );
 unbiasnet ( netsize, network );

 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( i = 0; i < num_elems; i += 3 )
  {
   /* 
      Determine the colormap entry that is 
      closest to the current input color vector 
    */
   min_dist = INT_MAX;
   for ( j = 0; j < netsize; j++ )
    {
     dist = L2_DIST_3D_SQR ( in_data[i], in_data[i + 1], in_data[i + 2],
			     network[j][0], network[j][1], network[j][2] );
     if ( dist < min_dist )
      {
       min_dist = dist;
       min_index = j;
      }
    }

   out_data[i] = network[min_index][0];
   out_data[i + 1] = network[min_index][1];
   out_data[i + 2] = network[min_index][2];
  }

 free ( network );
 free ( bias );
 free ( freq );
 free ( radpower );

 return out_img;
}

#undef prime1
#undef prime2
#undef prime3
#undef prime4
#undef netbiasshift
#undef ncycles
#undef intbiasshift
#undef intbias
#undef gammashift
#undef gamma
#undef betashift
#undef beta
#undef betagamma
#undef radiusbiasshift
#undef radiusbias
#undef radiusdec
#undef alphabiasshift
#undef initalpha
#undef radbiasshift
#undef radbias
#undef alpharadbshift
#undef alpharadbias
