
/** 
 * @file histogram.c
 * Routines for histogram creation/manipulation
 */

#include <image.h>

/** 
 * @brief Returns the type of a histogram
 *
 * @param[in] histo Histogram pointer
 *
 * @return Histogram type if the histogram is valid;
 *         HISTO_INVALID otherwise
 *
 * @author M. Emre Celebi
 * @date 06.15.2007
 */

HistoType
get_histo_type ( const Histo * histo )
{
 SET_FUNC_NAME ( "get_histo_type" );

 if ( !IS_VALID_OBJ ( histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", HISTO_INVALID );
  }

 return histo->type;
}

/** 
 * @brief Checks whether or not a histogram is of integer type
 *
 * @param[in] histo Histogram pointer
 *
 * @return true if the histogram is of integer type;
 *         false otherwise
 *
 * @author M. Emre Celebi
 * @date 06.30.2007
 */

Bool
is_int_histo ( const Histo * histo )
{
 return ( !IS_NULL ( histo ) && histo->type == HISTO_INT );
}

/** 
 * @brief Checks whether or not a histogram is of double type
 *
 * @param[in] histo Histogram pointer
 *
 * @return true if the histogram is of double type;
 *         false otherwise
 *
 * @author M. Emre Celebi
 * @date 06.30.2007
 */

Bool
is_double_histo ( const Histo * histo )
{
 return ( !IS_NULL ( histo ) && histo->type == HISTO_DBL );
}

/** 
 * @brief Returns the # bins of a histogram
 *
 * @param[in] histo Histogram pointer
 *
 * @return # bins if the histogram is valid;
 *         INT_MIN otherwise
 *
 * @author M. Emre Celebi
 * @date 06.15.2007
 */

int
get_num_bins ( const Histo * histo )
{
 SET_FUNC_NAME ( "get_num_bins" );

 if ( !IS_VALID_OBJ ( histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", INT_MIN );
  }

 return histo->num_bins;
}

/** 
 * @brief Returns the # pixels in histogram
 *
 * @param[in] histo Histogram pointer
 *
 * @return # pixels if the histogram is valid;
 *         INT_MIN otherwise
 *
 * @author M. Emre Celebi
 * @date 06.16.2007
 */

int
get_num_pixels ( const Histo * histo )
{
 SET_FUNC_NAME ( "get_num_pixels" );

 if ( !IS_VALID_OBJ ( histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", INT_MIN );
  }

 return histo->num_pixels;
}

/** 
 * @brief Returns the data associated with a histogram
 *
 * @param[in] histo Histogram pointer
 *
 * @return Data if the histogram is valid;
 *         NULL otherwise
 *
 * @author M. Emre Celebi
 * @date 06.16.2007
 */

void *
get_histo_data ( const Histo * histo )
{
 SET_FUNC_NAME ( "get_histo_data" );

 if ( !IS_VALID_OBJ ( histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", NULL );
  }

 if ( get_histo_type ( histo ) == HISTO_INT )
  {
   return histo->data.int_data;
  }

 return histo->data.double_data;
}

/** 
 * @brief Allocates a histogram object
 *
 * @param[in] type Histogram data type
 * @param[in] num_bins # bins { positive }
 *
 * @return Pointer to the allocated histogram or NULL
 * 
 * @see #free_histo
 *
 * @author M. Emre Celebi
 * @date 06.15.2007
 */

Histo *
alloc_histo ( const HistoType type, const int num_bins )
{
 SET_FUNC_NAME ( "alloc_histo" );
 Histo *histo = NULL;

 if ( !type )
  {
   ERROR_RET ( "Invalid histogram type !", NULL );
  }

 if ( num_bins <= 0 )
  {
   ERROR ( "Number of bins ( %d ) must be positive !", num_bins );
   return NULL;
  }

 histo = MALLOC_STRUCT ( Histo );
 histo->type = type;
 histo->num_bins = num_bins;
 histo->num_pixels = INT_MIN;	/* Illegal value */

 /* Allocate storage for histogram data */
 if ( type == HISTO_INT )
  {
   histo->data.int_data = ( int * ) calloc ( num_bins, sizeof ( int ) );
   if ( IS_NULL ( histo->data.int_data ) )
    {
     ERROR_RET ( "Insufficient memory !", NULL );
    }
  }
 else
  {
   histo->data.double_data =
    ( double * ) calloc ( num_bins, sizeof ( double ) );
   if ( IS_NULL ( histo->data.double_data ) )
    {
     ERROR_RET ( "Insufficient memory !", NULL );
    }
  }

 return histo;
}

/** 
 * @brief Deallocates a histogram object
 *
 * @param[in,out] histo Histogram pointer
 *
 * @return none
 * 
 * @note nothing happens if the histogram object is invalid
 * @see #alloc_histo
 *
 * @author M. Emre Celebi
 * @date 06.15.2007
 */

void
free_histo ( Histo * histo )
{
 if ( IS_VALID_OBJ ( histo ) )
  {
   if ( get_histo_type ( histo ) == HISTO_INT )
    {
     free ( histo->data.int_data );
     histo->data.int_data = NULL;
    }
   else
    {
     free ( histo->data.double_data );
     histo->data.double_data = NULL;
    }

   histo->type = HISTO_INVALID;
   histo->num_bins = INT_MIN;
   histo->num_pixels = INT_MIN;
  }
}

/** 
 * @brief Creates the histogram of a grayscale image
 *
 * @param[in] img Image pointer { grayscale }
 *
 * @return Pointer to the histogram or NULL
 *
 * @author M. Emre Celebi
 * @date 06.14.2007
 */

Histo *
create_histo ( const Image * img )
{
 SET_FUNC_NAME ( "create_histo" );
 byte *img_data;
 int i;
 int num_pixels;
 int *histo_data;
 Histo *histo = NULL;

 if ( !is_gray_img ( img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 num_pixels = get_num_rows ( img ) * get_num_cols ( img );
 img_data = get_img_data_1d ( img );

 /* Allocate storage for the histogram */
 histo = alloc_histo ( HISTO_INT, NUM_GRAY );
 if ( IS_NULL ( histo ) )
  {
   ERROR_RET ( "alloc_histo() failed !", NULL );
  }

 histo->num_pixels = num_pixels;
 histo_data = get_histo_data ( histo );

 /* Populate the histogram */
 for ( i = 0; i < num_pixels; i++ )
  {
   histo_data[img_data[i]]++;
  }

 return histo;
}

/** 
 * @brief Normalizes an histogram
 *
 * @param[in] in_histo Histogram pointer
 *
 * @return Pointer to the normalized histogram or NULL
 *
 * @author M. Emre Celebi
 * @date 06.14.2007
 */

Histo *
normalize_histo ( const Histo * in_histo )
{
 SET_FUNC_NAME ( "normalize_histo" );
 int ih;
 int num_pixels;
 int num_bins;			/* number of bins in the histogram */
 int *in_data;			/* input histogram data */
 double term;
 double *out_data;		/* output histogram data */
 Histo *out_histo;

 if ( !is_int_histo ( in_histo ) )
  {
   ERROR_RET ( "Not an integer histogram !", NULL );
  }

 num_pixels = get_num_pixels ( in_histo );
 num_bins = get_num_bins ( in_histo );
 in_data = get_histo_data ( in_histo );

 /* Allocate storage for the histogram */
 out_histo = alloc_histo ( HISTO_DBL, num_bins );
 if ( IS_NULL ( out_histo ) )
  {
   ERROR_RET ( "alloc_histo() failed !", NULL );
  }

 out_histo->num_pixels = num_pixels;
 out_data = get_histo_data ( out_histo );

 term = 1.0 / ( double ) num_pixels;

 /* Calculate the normalized histogram */
 for ( ih = 0; ih < num_bins; ih++ )
  {
   out_data[ih] = term * in_data[ih];
  }

 return out_histo;
}

/** 
 * @brief Calculates the cumulative histogram of an histogram
 *
 * @param[in] histo Histogram pointer
 *
 * @return Pointer to the cumulative histogram data or NULL
 *
 * @author M. Emre Celebi
 * @date 06.14.2007
 */

void *
accumulate_histo ( const Histo * histo )
{
 SET_FUNC_NAME ( "accumulate_histo" );
 int ih;
 int num_bins;

 if ( !IS_VALID_OBJ ( histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", NULL );
  }

 num_bins = get_num_bins ( histo );

 /* Codes for the INT and DBL histograms are nearly identical */

 if ( get_histo_type ( histo ) == HISTO_INT )
  {
   int *histo_data;
   int *accum_data;

   histo_data = get_histo_data ( histo );

   accum_data = ( int * ) malloc ( num_bins * sizeof ( int ) );
   if ( IS_NULL ( accum_data ) )
    {
     ERROR_RET ( "Insufficient memory !", NULL );
    }

   accum_data[0] = histo_data[0];
   for ( ih = 1; ih < num_bins; ih++ )
    {
     accum_data[ih] = accum_data[ih - 1] + histo_data[ih];
    }

   return accum_data;
  }
 else
  {
   double *histo_data;
   double *accum_data;

   histo_data = get_histo_data ( histo );

   accum_data = ( double * ) malloc ( num_bins * sizeof ( double ) );
   if ( IS_NULL ( accum_data ) )
    {
     ERROR_RET ( "Insufficient memory !", NULL );
    }

   accum_data[0] = histo_data[0];
   for ( ih = 1; ih < num_bins; ih++ )
    {
     accum_data[ih] = accum_data[ih - 1] + histo_data[ih];
    }

   return accum_data;
  }

 /*@notreached@ */
}

/** 
 * @brief Creates a binary image from an histogram
 *
 * @param[in] histo Histogram pointer
 * @param[in] num_rows # rows { positive }
 * @param[in] bin_spacing Space (in pixels) between consecutive histogram bins { non-negative }
 *
 * @return Pointer to the histogram image or NULL
 *
 * @author M. Emre Celebi
 * @date 06.16.2007
 */

Image *
histo_to_img ( const Histo * histo, const int num_rows, const int bin_spacing )
{
 SET_FUNC_NAME ( "histo_to_img" );
 byte **img_data;
 int num_cols, num_bins;
 int min_bin, max_bin;
 int ir, ic, ih;
 int height_bin, width_bin;
 int *histo_data;
 double scale_factor;
 double *norm_data;
 Image *img;

 if ( !IS_VALID_OBJ ( histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", NULL );
  }

 if ( num_rows <= 0 )
  {
   ERROR ( "Number of rows ( %d ) must be positive !", num_rows );
   return NULL;
  }

 if ( bin_spacing < 0 )
  {
   ERROR ( "Bin spacing ( %d ) must be non-negative !", bin_spacing );
   return NULL;
  }

 num_bins = get_num_bins ( histo );

 if ( get_histo_type ( histo ) == HISTO_INT )
  {
   histo_data = get_histo_data ( histo );
  }
 else				/* HISTO_DBL */
  {
   int num_pixels = get_num_pixels ( histo );

   norm_data = get_histo_data ( histo );

   histo_data = ( int * ) calloc ( num_bins, sizeof ( int ) );
   if ( IS_NULL ( histo_data ) )
    {
     ERROR_RET ( "Insufficient memory !", NULL );
    }

   /* Convert the normalized histogram back to regular histogram */
   for ( ih = 0; ih < num_bins; ih++ )
    {
     histo_data[ih] = num_pixels * norm_data[ih];	/* truncate */
    }
  }

 /* Find the bins that contain the min and max number of pixels */
 min_bin = 0;
 max_bin = 0;
 for ( ih = 1; ih < num_bins; ih++ )
  {
   if ( histo_data[ih] > histo_data[max_bin] )
    {
     max_bin = ih;
    }
   if ( histo_data[ih] < histo_data[min_bin] )
    {
     min_bin = ih;
    }
  }

 /* Scaling factor for the min-max scaling */
 scale_factor =
  num_rows / ( double ) ( histo_data[max_bin] - histo_data[min_bin] );

 /* Each histogram bin is composed of 2 pixel bar + spacing */
 width_bin = 2 + bin_spacing;
 num_cols = num_bins * width_bin;

 /* Allocate storage for the histogram image */
 img = alloc_img ( PIX_BIN, num_rows, num_cols );
 img_data = get_img_data_nd ( img );

 ic = 0;			/* Column index of the image array */
 for ( ih = 0; ih < num_bins; ih++ )
  {
   /* Determine the height of the current bin */
   height_bin = ( int ) ( scale_factor * ( histo_data[ih] - histo_data[min_bin] ) );	/* truncate */

   /* Draw a 2 pixel thick bar that represents the current bin */
   for ( ir = num_rows - height_bin; ir < num_rows; ir++ )
    {
     img_data[ir][ic] = OBJECT;
     img_data[ir][ic + 1] = OBJECT;
    }

   /* Skip the spacing */
   ic += width_bin;
  }

 return img;
}

/** 
 * @brief Smoothes an histogram using local arithmetic averaging
 *
 * @param[in] in_histo Histogram pointer
 * @param[in] mask_size Size of the smoothing mask { positive-odd }
 *
 * @return Pointer to the smoothed histogram or NULL
 *
 * @ref Sonka M., Hlavac V., and Boyle R. (1998) "Image Processing, Analysis, 
 *      and Machine Vision (Second Edition)" Thompson-Engineering
 *
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Histo *
smooth_histo_local ( const Histo * in_histo, const int mask_size )
{
 SET_FUNC_NAME ( "smooth_histo_local" );
 int ih, im;
 int half_mask;
 int num_bins;
 int first_bin, last_bin;
 Histo *out_histo;

 if ( !IS_VALID_OBJ ( in_histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", NULL );
  }

 if ( !IS_POS_ODD ( mask_size ) )
  {
   ERROR ( "Mask size ( %d ) must be positive and odd !", mask_size );
   return NULL;
  }

 /* Center of the mask */
 half_mask = mask_size / 2;

 num_bins = get_num_bins ( in_histo );
 first_bin = half_mask;
 last_bin = num_bins - half_mask - 1;

 /* The codes for integer and double histograms are identical */

 if ( get_histo_type ( in_histo ) == HISTO_INT )
  {
   int sum;
   int *in_data;
   int *out_data;

   out_histo = alloc_histo ( HISTO_INT, num_bins );
   if ( IS_NULL ( out_histo ) )
    {
     ERROR_RET ( "alloc_histo() failed !", NULL );
    }

   in_data = get_histo_data ( in_histo );
   out_data = get_histo_data ( out_histo );

   /* Average the bin values within the mask */
   for ( ih = first_bin; ih <= last_bin; ih++ )
    {
     sum = 0;
     for ( im = -half_mask; im <= half_mask; im++ )
      {
       sum += in_data[ih + im];
      }
     out_data[ih] = ( sum / ( double ) mask_size ) + 0.5;	/* round */
    }
  }
 else
  {
   int sum;
   double *in_data;
   double *out_data;

   out_histo = alloc_histo ( HISTO_DBL, num_bins );
   if ( IS_NULL ( out_histo ) )
    {
     ERROR_RET ( "alloc_histo() failed !", NULL );
    }

   in_data = get_histo_data ( in_histo );
   out_data = get_histo_data ( out_histo );

   /* Average the bin values within the mask */
   for ( ih = first_bin; ih <= last_bin; ih++ )
    {
     sum = 0;
     for ( im = -half_mask; im <= half_mask; im++ )
      {
       sum += in_data[ih + im];
      }
     out_data[ih] = ( sum / ( double ) mask_size ) + 0.5;	/* round */
    }
  }

 return out_histo;
}

/** 
 * @brief Smoothes an histogram using a Gaussian-weighted mask
 *
 * @param[in] in_histo Histogram pointer
 * @param[in] sigma Stdev of the Gaussian mask { positive }
 *
 * @return Pointer to the smoothed histogram or NULL
 *
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Histo *
smooth_histo_gauss ( const Histo * in_histo, const double sigma )
{
 SET_FUNC_NAME ( "smooth_histo_gauss" );
 int ih, ik;
 int num_bins;
 int half_mask;
 int mask_size;			/* # pixels in the mask */
 double sum;
 double *mask;			/* 1D Gaussian mask */
 Histo *out_histo;

 if ( !IS_VALID_OBJ ( in_histo ) )
  {
   ERROR_RET ( "Invalid histogram object !", NULL );
  }

 if ( !IS_POS ( sigma ) )
  {
   ERROR ( "Sigma ( %f ) must be positive !", sigma );
   return NULL;
  }

 /* Create a 1D Gaussian mask */
 mask = gauss_1d ( sigma, &mask_size );
 if ( IS_NULL ( mask ) )
  {
   ERROR_RET ( "gauss_1d() failed !", NULL );
  }

 if ( IS_EVEN ( mask_size ) )
  {
   /* Make the mask size odd */
   mask_size++;
  }

 /* Center of the mask */
 half_mask = mask_size / 2;

 num_bins = get_num_bins ( in_histo );

 /* The codes for integer and double histograms are identical */

 if ( get_histo_type ( in_histo ) == HISTO_INT )
  {
   int *in_data;
   int *out_data;

   out_histo = alloc_histo ( HISTO_INT, num_bins );
   if ( IS_NULL ( out_histo ) )
    {
     ERROR_RET ( "alloc_histo() failed !", NULL );
    }

   in_data = get_histo_data ( in_histo );
   out_data = get_histo_data ( out_histo );

   /* Average the bin values within the mask using Gaussian weights */
   for ( ih = half_mask; ih < ( num_bins - half_mask ); ih++ )
    {
     sum = 0.0;
     for ( ik = -half_mask; ik <= half_mask; ik++ )
      {
       sum += mask[half_mask + ik] * in_data[ih + ik];
      }
     out_data[ih] = sum + 0.5;	/* round */
    }
  }
 else
  {
   double *in_data;
   double *out_data;

   out_histo = alloc_histo ( HISTO_DBL, num_bins );
   if ( IS_NULL ( out_histo ) )
    {
     ERROR_RET ( "alloc_histo() failed !", NULL );
    }

   in_data = get_histo_data ( in_histo );
   out_data = get_histo_data ( out_histo );

   /* Average the bin values within the mask using Gaussian weights */
   for ( ih = half_mask; ih < ( num_bins - half_mask ); ih++ )
    {
     sum = 0.0;
     for ( ik = -half_mask; ik <= half_mask; ik++ )
      {
       sum += mask[half_mask + ik] * in_data[ih + ik];
      }
     out_data[ih] = sum + 0.5;	/* round */
    }
  }

 return out_histo;
}

/** 
 * @brief Histogram Hyperbolization
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] c_value c parameter in the original paper { [0,1] }
 *
 * @return Pointer to the histogram hyperbolized image or NULL
 *
 * @reco C_VALUE = 0.5
 * @ref 1) Frei W. (1977) "Image Enhancement by Histogram Hyperbolization" 
 *         Computer Graphics and Image Processing, 6(3): 286-294
 *      2) Cobra D.T. (1995) "A Generalization of the Method of Quadratic 
 * 	   Hyperbolization of Image Histograms" Proc. of the 38th Midwest Symposium 
 * 	   on Circuits and Systems, 1: 141-144
 * 	3) Cobra D.T. (1998) "Image Histogram Modification Based on a New Model 
 * 	   of the Visual System Nonlinearity" Journal of Electronic Imaging, 7(4): 807-815
 * 
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Image *
hyperbolize_histo ( const Image * in_img, const double c_value )
{
 SET_FUNC_NAME ( "hyperbolize_histo" );
 byte *in_img_data;
 byte *out_img_data;
 int ih, ik;
 int num_rows, num_cols;
 int num_pixels;
 int *lut;			/* lookup table for the histogram transformation */
 double term;
 double *histo_data;		/* normalized histogram data */
 double *cnh;			/* cumulative normalized histogram */
 Histo *norm_histo;		/* normalized histogram */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_IN_0_1 ( c_value ) )
  {
   ERROR ( "c value ( %f ) must be in [0,1] !", c_value );
   return NULL;
  }

 /* Calculate the normalized histogram */
 norm_histo = normalize_histo ( create_histo ( in_img ) );
 if ( IS_NULL ( norm_histo ) )
  {
   ERROR_RET ( "normalize_histo() failed !", NULL );
  }

 histo_data = get_histo_data ( norm_histo );

 /* Calculate the cumulative normalized histogram */
 cnh = accumulate_histo ( norm_histo );

 /* Allocate storage for the LUT */
 lut = ( int * ) malloc ( NUM_GRAY * sizeof ( int ) );

 /* Populate the LUT */
 term = 1.0 + 1.0 / c_value;

 /* Equation (4) in Ref. 1 and (5) in Ref. 2 */
 for ( ih = 0; ih < NUM_GRAY; ih++ )
  {
   /* 
      The references assume that the gray values are normalized. 
      Therefore, the outputs are multiplied by MAX_GRAY to bring 
      them to the [0, MAX_GRAY] range.
    */
   lut[ih] = MAX_GRAY * c_value * ( pow ( term, cnh[ih] ) - 1 );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;

 /* Allocate the output image */
 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 in_img_data = get_img_data_1d ( in_img );
 out_img_data = get_img_data_1d ( out_img );

 /* Perform the histogram transformation */
 for ( ik = 0; ik < num_pixels; ik++ )
  {
   out_img_data[ik] = lut[in_img_data[ik]];
  }

 free_histo ( norm_histo );
 free ( cnh );
 free ( lut );

 return out_img;
}

/** 
 * @brief Histogram Equalization
 *
 * @param[in] in_img Image pointer { grayscale }
 *
 * @return Pointer to the histogram equalized image or NULL
 *
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Image *
equalize_histo ( const Image * in_img )
{
 SET_FUNC_NAME ( "equalize_histo" );
 byte *in_img_data;
 byte *out_img_data;
 int i;
 int num_rows, num_cols;
 int num_pixels;
 double *histo_data;		/* normalized histogram data */
 double *cnh;			/* cumulative normalized histogram */
 Histo *norm_histo;		/* normalized histogram */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 /* Calculate the normalized histogram */
 norm_histo = normalize_histo ( create_histo ( in_img ) );
 if ( IS_NULL ( norm_histo ) )
  {
   ERROR_RET ( "normalize_histo() failed !", NULL );
  }

 histo_data = get_histo_data ( norm_histo );

 /* Calculate the cumulative normalized histogram */
 cnh = accumulate_histo ( norm_histo );

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;

 /* Allocate the output image */
 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 in_img_data = get_img_data_1d ( in_img );
 out_img_data = get_img_data_1d ( out_img );

 /* Perform the histogram transformation */
 for ( i = 0; i < num_pixels; i++ )
  {
   out_img_data[i] = MAX_GRAY * cnh[in_img_data[i]];
  }

 free_histo ( norm_histo );
 free ( cnh );

 return out_img;
}
