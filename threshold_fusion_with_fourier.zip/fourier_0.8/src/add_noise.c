
/** 
 * @file add_noise.c
 * Routines for adding various types of noise to a grayscale / color image
 */

#include <image.h>

/** @cond INTERNAL_MACRO */
#define RAND_DBL_0_1( ) ( rand ( ) / ( double ) RAND_MAX )

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */
#define RAND_DBL_0_255( ) ( 255.0 * RAND_DBL_0_1 ( ) )

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */
#define HALF_RAND_MAX ( 0.5 * RAND_MAX )

/** @endcond INTERNAL_MACRO */

/** @cond INTERNAL_MACRO */
#define RAND_0_OR_255( ) ( rand ( ) < HALF_RAND_MAX ? 0 : 255 )

/** @endcond INTERNAL_MACRO */

static double rand_gaussian ( void );

/** 
 * @brief Generate a Normal Random Variable with 0 mean and
 *        1 standard deviation using Polar (Box-Mueller) method
 *
 * @return Random variable
 *
 * @ref http://c-faq.com/lib/gaussian.html
 *
 * @author GNU Scientific Library
 * @date 06.17.2007
 */

static double
rand_gaussian ( void )
{
 double x, y, r2;

 do
  {
   /* Choose x,y in uniform square (-1,-1) to (+1,+1) */

   x = -1.0 + 2.0 * RAND_DBL_0_1 (  );
   y = -1.0 + 2.0 * RAND_DBL_0_1 (  );

   /* See if it is in the unit circle */
   r2 = x * x + y * y;
  }
 while ( ( r2 > 1.0 ) || ( r2 == 0.0 ) );

 /* Box-Muller transform */
 return ( y * sqrt ( -2.0 * log ( r2 ) / r2 ) );
}

/** 
 * @brief Add Gaussian noise to an image
 *
 * @param[in] in_img Image pointer { grayscale, rgb }
 * @param[in] mean Mean of the noise { [0,1] }
 * @param[in] stdev Standard deviation of the noise { [0,1] }
 *
 * @return Pointer to the noise injected image or NULL
 *
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Image *
add_gaussian_noise ( const Image * in_img, const double mean,
		     const double stdev )
{
 SET_FUNC_NAME ( "add_gaussian_noise" );
 byte *in_data;
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 int value;
 double scaled_mean;
 double scaled_stdev;
 Image *out_img;

 if ( !is_gray_img ( in_img ) && !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale or color image !", NULL );
  }

 if ( !IS_IN_0_1 ( mean ) )
  {
   ERROR ( "Mean ( %f ) must be in [0,1] !", mean );
   return NULL;
  }

 if ( !IS_IN_0_1 ( stdev ) )
  {
   ERROR ( "Stdev ( %f ) must be in [0,1] !", stdev );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = get_num_bands ( in_img ) * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( get_pix_type ( in_img ), num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 scaled_mean = mean * MAX_GRAY;
 scaled_stdev = stdev * MAX_GRAY;

 for ( ik = 0; ik < num_elems; ik++ )
  {
   value = in_data[ik] + scaled_mean + scaled_stdev * rand_gaussian (  );
   out_data[ik] = CLAMP_BYTE ( value );
  }

 return out_img;
}

/** 
 * @brief Add Salt & Pepper noise to a grayscale image
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] prob Noise probability { [0,1] }
 *
 * @return Pointer to the noise injected image or NULL
 *
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Image *
add_saltpepper_noise ( const Image * in_img, const double prob )
{
 SET_FUNC_NAME ( "add_saltpepper_noise" );
 byte *in_data;
 byte *out_data;
 int i;
 int num_rows, num_cols;
 int num_pixels;
 int value;
 int prob_pepper;
 int prob_salt;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_IN_0_1 ( prob ) )
  {
   ERROR ( "Noise probability ( %f ) must be in [0,1] !", prob );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 prob_pepper = RAND_MAX * ( prob / 2.0 );
 prob_salt = 2.0 * prob_pepper;

 for ( i = 0; i < num_pixels; i++ )
  {
   value = rand (  );		/* [ 0, RAND_MAX ] */
   if ( value < prob_pepper )
    {
     out_data[i] = 0;		/* Pepper */
    }
   else if ( value < prob_salt )
    {
     out_data[i] = MAX_GRAY;	/* Salt */
    }
   else
    {
     out_data[i] = in_data[i];
    }
  }

 return out_img;
}

/** 
 * @brief Add Speckle noise to a grayscale image
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] stdev Noise probability { [0,1] }
 *
 * @return Pointer to the noise injected image or NULL
 *
 * @author M. Emre Celebi
 * @date 06.17.2007
 */

Image *
add_speckle_noise ( const Image * in_img, const double stdev )
{
 SET_FUNC_NAME ( "add_speckle_noise" );
 byte *in_data;
 byte *out_data;
 int i;
 int num_rows, num_cols;
 int num_pixels;
 int value;
 double term;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_IN_0_1 ( stdev ) )
  {
   ERROR ( "Stdev ( %f ) must be in [0,1] !", stdev );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 term = stdev * sqrt ( 12.0 );

 for ( i = 0; i < num_pixels; i++ )
  {
   value = in_data[i] + term * in_data[i] * ( RAND_DBL_0_1 (  ) - 0.5 );
   out_data[i] = CLAMP_BYTE ( value );
  }

 return out_img;
}

/** 
 * @brief Add uncorrelated impulsive noise to a color image
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] prob Noise probability { [0,1] }
 * @param[in] is_uniform If true noise will be a uniform random number between 0 and 255
 *                       ; otherwise it will be either 0 or 255 with equal probability
 *
 * @return Pointer to the noise injected image or NULL
 *
 * @author M. Emre Celebi
 * @date 08.10.2007
 */

Image *
add_uncorr_impulsive_noise ( const Image * in_img, const double prob,
			     const Bool is_uniform )
{
 SET_FUNC_NAME ( "add_uncorr_impulsive_noise" );
 byte *in_data;
 byte *out_data;
 int i;
 int num_rows, num_cols;
 int num_elems;
 int value;
 int chan_prob;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_IN_0_1 ( prob ) )
  {
   ERROR ( "Noise probability ( %f ) must be in [0,1] range !", prob );
   return NULL;
  }

 if ( !IS_BOOL ( is_uniform ) )
  {
   ERROR ( "Last argument must be either 'false' or 'true' !", NULL );
  }

 /* Channel contamination probability */
 chan_prob = RAND_MAX * ( 1.0 - cbrt ( 1.0 - prob ) ) + 0.5;	/* round */

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 if ( is_uniform )
  {
   for ( i = 0; i < num_elems; i++ )
    {
     value = rand (  );		/* [ 0, RAND_MAX ] */
     if ( value < chan_prob )
      {
       out_data[i] = RAND_DBL_0_255 (  );	/* Inject uniform random impulsive noise */
      }
     else
      {
       out_data[i] = in_data[i];	/* Keep the original */
      }
    }
  }
 else
  {
   for ( i = 0; i < num_elems; i++ )
    {
     value = rand (  );		/* [ 0, RAND_MAX ] */
     if ( value < chan_prob )
      {
       out_data[i] = RAND_0_OR_255 (  );	/* Inject salt & pepper impulsive noise */
      }
     else
      {
       out_data[i] = in_data[i];	/* Keep the original */
      }
    }
  }

 return out_img;
}

/** 
 * @brief Add correlated impulsive noise to a color image
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] overall_prob Overall noise probability { [0,1] }
 * @param[in] red_prob Red channel noise probability { [0,1] }
 * @param[in] green_prob Green channel noise probability { [0,1] }
 * @param[in] blue_prob Blue channel noise probability { [0,1] }
 * @param[in] is_uniform If true noise will be a uniform random number between 0 and 255
 *                       ; otherwise it will be either 0 or 255 with equal probability
 *
 * @return Pointer to the noise injected image or NULL
 * @note Sum of the channel noise probabilities must be less than or equal to 1.
 * @reco RED_PROB = GREEN_PROB = BLUE_PROB = 0.25
 *
 * @author M. Emre Celebi
 * @date 08.10.2007
 */

Image *
add_corr_impulsive_noise ( const Image * in_img, const double overall_prob,
			   const double red_prob, const double green_prob,
			   const double blue_prob, const Bool is_uniform )
{
 SET_FUNC_NAME ( "add_corr_impulsive_noise" );
 byte *in_data;
 byte *out_data;
 int i;
 int num_rows, num_cols;
 int num_elems;
 int value;
 int noise_prob;
 int red_cum_prob;
 int green_cum_prob;
 int blue_cum_prob;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !IS_IN_0_1 ( overall_prob ) )
  {
   ERROR ( "Overall noise probability ( %f ) must be in [0,1] range !",
	   overall_prob );
   return NULL;
  }

 if ( IS_NEG ( red_prob ) || IS_NEG ( green_prob ) || IS_NEG ( blue_prob ) ||
      IS_POS ( red_prob + green_prob + blue_prob - 1.0 ) )
  {
   ERROR
    ( "Channel noise probabilities ( %f, %f, %f ) must be in [0,1] range and their sum ( %f ) must be less than or equal to 1",
      red_prob, green_prob, blue_prob, red_prob + green_prob + blue_prob );
   return NULL;
  }

 if ( !IS_BOOL ( is_uniform ) )
  {
   ERROR ( "Last argument must be either 'false' or 'true' !", NULL );
  }

 /* Noise probability */
 noise_prob = RAND_MAX * overall_prob + 0.5;	/* round */

 /* Cumulative channel noise probabilities */
 red_cum_prob = RAND_MAX * overall_prob * red_prob + 0.5;	/* round */
 green_cum_prob = RAND_MAX * overall_prob * ( red_prob + green_prob ) + 0.5;	/* round */
 blue_cum_prob = RAND_MAX * overall_prob * ( red_prob + green_prob + blue_prob ) + 0.5;	/* round */

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 if ( is_uniform )
  {
   for ( i = 0; i < num_elems; i += 3 )
    {
     value = rand (  );		/* [ 0, RAND_MAX ] */
     if ( value < noise_prob )
      {
       if ( value < red_cum_prob )
	{
	 /* Inject uniform random impulsive noise to the red channel */
	 out_data[i] = RAND_DBL_0_255 (  );
	 out_data[i + 1] = in_data[i + 1];
	 out_data[i + 2] = in_data[i + 2];
	}
       else if ( value < green_cum_prob )
	{
	 /* Inject uniform random impulsive noise to the green channel */
	 out_data[i] = in_data[i];
	 out_data[i + 1] = RAND_DBL_0_255 (  );
	 out_data[i + 2] = in_data[i + 2];
	}
       else if ( value < blue_cum_prob )
	{
	 /* Inject uniform random impulsive noise to the blue channel */
	 out_data[i] = in_data[i];
	 out_data[i + 1] = in_data[i + 1];
	 out_data[i + 2] = RAND_DBL_0_255 (  );
	}
       else
	{
	 /* Inject uniform random impulsive noise to all 3 channels */
	 out_data[i] = RAND_DBL_0_255 (  );
	 out_data[i + 1] = RAND_DBL_0_255 (  );
	 out_data[i + 2] = RAND_DBL_0_255 (  );
	}
      }
     else			/* Keep the original */
      {
       out_data[i] = in_data[i];
       out_data[i + 1] = in_data[i + 1];
       out_data[i + 2] = in_data[i + 2];
      }
    }
  }
 else
  {
   for ( i = 0; i < num_elems; i += 3 )
    {
     value = rand (  );		/* [ 0, RAND_MAX ] */
     if ( value < noise_prob )
      {
       if ( value < red_cum_prob )
	{
	 /* Inject salt & pepper impulsive noise to the red channel */
	 out_data[i] = RAND_0_OR_255 (  );
	 out_data[i + 1] = in_data[i + 1];
	 out_data[i + 2] = in_data[i + 2];
	}
       else if ( value < green_cum_prob )
	{
	 /* Inject salt & pepper impulsive noise to the green channel */
	 out_data[i] = in_data[i];
	 out_data[i + 1] = RAND_0_OR_255 (  );
	 out_data[i + 2] = in_data[i + 2];
	}
       else if ( value < blue_cum_prob )
	{
	 /* Inject salt & pepper impulsive noise to the blue channel */
	 out_data[i] = in_data[i];
	 out_data[i + 1] = in_data[i + 1];
	 out_data[i + 2] = RAND_0_OR_255 (  );
	}
       else
	{
	 /* Inject salt & pepper impulsive noise to all 3 channels */
	 out_data[i] = RAND_0_OR_255 (  );
	 out_data[i + 1] = RAND_0_OR_255 (  );
	 out_data[i + 2] = RAND_0_OR_255 (  );
	}
      }
     else			/* Keep the original */
      {
       out_data[i] = in_data[i];
       out_data[i + 1] = in_data[i + 1];
       out_data[i + 2] = in_data[i + 2];
      }
    }
  }

 return out_img;
}

#undef RAND_DBL_0_1
#undef RAND_DBL_0_255
#undef RAND_0_OR_255

static double
calc_error_gray_ ( const ErrorMeasure err_meas, const Image * orig_img,
		   const Image * est_img, const int win_size )
{
 byte **orig_data;
 byte **est_data;
 int ir, ic;
 int num_rows, num_cols;
 int num_pixels;
 int half_win;
 double value;
 double error = DBL_MIN;

 half_win = win_size / 2;
 num_rows = get_num_rows ( orig_img ) - half_win;
 num_cols = get_num_cols ( orig_img ) - half_win;
 num_pixels = num_rows * num_cols;

 orig_data = get_img_data_nd ( orig_img );
 est_data = get_img_data_nd ( est_img );

 value = 0.0;

 if ( err_meas == EM_MAE )
  {
   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value += abs ( orig_data[ir][ic] - est_data[ir][ic] );
      }
    }

   error = value / num_pixels;
  }
 else if ( err_meas == EM_MSE || err_meas == EM_RMSE || err_meas == EM_PSNR )
  {
   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value +=
	( orig_data[ir][ic] - est_data[ir][ic] ) * ( orig_data[ir][ic] -
						     est_data[ir][ic] );
      }
    }

   error = value / num_pixels;

   if ( err_meas == EM_RMSE )
    {
     error = sqrt ( error );
    }
   else if ( err_meas == EM_PSNR )
    {
     error = 20.0 * log10 ( MAX_GRAY / sqrt ( error ) );
    }
  }
 else if ( err_meas == EM_NMSE )
  {
   double est_sq = 0.0;

   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value +=
	( orig_data[ir][ic] - est_data[ir][ic] ) * ( orig_data[ir][ic] -
						     est_data[ir][ic] );
       est_sq += est_data[ir][ic] * est_data[ir][ic];
      }
    }

   error = value / est_sq;
  }

 return error;
}

static double
calc_error_rgb_ ( const ErrorMeasure err_meas, const Image * orig_img,
		  const Image * est_img, const int win_size )
{
 byte ***orig_data;
 byte ***est_data;
 int ir, ic;
 int num_rows, num_cols;
 int num_elems;
 int half_win;
 double value;
 double error = DBL_MIN;

 half_win = win_size / 2;
 num_rows = get_num_rows ( orig_img ) - half_win;
 num_cols = get_num_cols ( orig_img ) - half_win;
 num_elems = 3 * num_rows * num_cols;

 orig_data = get_img_data_nd ( orig_img );
 est_data = get_img_data_nd ( est_img );

 value = 0.0;

 if ( err_meas == EM_MAE )
  {
   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value +=
	L1_DIST_3D ( orig_data[ir][ic][0], orig_data[ir][ic][1],
		     orig_data[ir][ic][2], est_data[ir][ic][0],
		     est_data[ir][ic][1], est_data[ir][ic][2] );

      }
    }

   error = value / num_elems;
  }
 else if ( err_meas == EM_MSE || err_meas == EM_RMSE || err_meas == EM_PSNR )
  {
   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value +=
	L2_DIST_3D_SQR ( orig_data[ir][ic][0], orig_data[ir][ic][1],
			 orig_data[ir][ic][2], est_data[ir][ic][0],
			 est_data[ir][ic][1], est_data[ir][ic][2] );

      }
    }

   error = value / num_elems;

   if ( err_meas == EM_RMSE )
    {
     error = sqrt ( error );
    }
   else if ( err_meas == EM_PSNR )
    {
     error = 20.0 * log10 ( MAX_GRAY / sqrt ( error ) );
    }
  }
 else if ( err_meas == EM_NMSE )
  {
   double est_sq = 0.0;

   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value +=
	L2_DIST_3D_SQR ( orig_data[ir][ic][0], orig_data[ir][ic][1],
			 orig_data[ir][ic][2], est_data[ir][ic][0],
			 est_data[ir][ic][1], est_data[ir][ic][2] );
       est_sq +=
	L2_NORM_3D_SQR ( est_data[ir][ic][0], est_data[ir][ic][1],
			 est_data[ir][ic][2] );

      }
    }

   error = value / est_sq;
  }
 else if ( err_meas == EM_NCD )
  {
   double norm_sum;
   double ***orig_data;
   double ***est_data;
   Image *orig_lab;
   Image *est_lab;

   orig_lab = rgb_to_lab ( orig_img );
   est_lab = rgb_to_lab ( est_img );
   orig_data = get_img_data_nd ( orig_lab );
   est_data = get_img_data_nd ( est_lab );

   norm_sum = 0.0;
   for ( ir = half_win; ir < num_rows; ir++ )
    {
     for ( ic = half_win; ic < num_cols; ic++ )
      {
       value +=
	L2_DIST_3D ( orig_data[ir][ic][0], orig_data[ir][ic][1],
		     orig_data[ir][ic][2], est_data[ir][ic][0],
		     est_data[ir][ic][1], est_data[ir][ic][2] );
       norm_sum +=
	L2_NORM_3D ( orig_data[ir][ic][0], orig_data[ir][ic][1],
		     orig_data[ir][ic][2] );
      }
    }

   error = value / norm_sum;

   free_img ( orig_lab );
   free_img ( est_lab );
  }

 return error;
}

/** 
 * @brief Calculate the error between an image and its estimate
 *
 * @param[in] err_meas Error measure { MAE, MSE, RMSE, PSNR, NMSE, NCD }
 * @param[in] orig_img Original image { grayscale, rgb }
 * @param[in] est_img Estimate image { grayscale, rgb }
 * @param[in] win_size WIN_SIZE / 2 rows from top and bottom & WIN_SIZE / 2
 *                     columns from left and right will be excluded. { positive-odd }
 *
 * @return Error value or DBL_MIN
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

double
calc_error_ ( const ErrorMeasure err_meas, const Image * orig_img,
	      const Image * est_img, const int win_size )
{
 SET_FUNC_NAME ( "calc_error_" );

 if ( !err_meas )
  {
   ERROR_RET ( "Invalid error measure !", DBL_MIN );
  }

 if ( !img_dims_agree ( orig_img, est_img ) )
  {
   ERROR_RET ( "Image dimensions must agree !", DBL_MIN );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return DBL_MIN;
  }

 if ( is_gray_img ( orig_img ) && is_gray_img ( est_img ) )
  {
   if ( err_meas == EM_NCD )
    {
     ERROR_RET ( "NCD is only applicable to color images !", DBL_MIN );
    }

   return calc_error_gray_ ( err_meas, orig_img, est_img, win_size );
  }
 else if ( is_rgb_img ( orig_img ) && is_rgb_img ( est_img ) )
  {
   return calc_error_rgb_ ( err_meas, orig_img, est_img, win_size );
  }
 else
  {
   ERROR_RET ( "Image types should be either both grayscale or both rgb !",
	       DBL_MIN );
  }
}

/** 
 * @brief Calculate the error between an image and its estimate
 *
 * @param[in] err_meas Error neasure { MAE, MSE, RMSE, PSNR, NMSE, NCD }
 * @param[in] orig_img Original image { grayscale, rgb }
 * @param[in] est_img Estimate image { grayscale, rgb }
 *
 * @return Error value or DBL_MIN
 *
 * @author M. Emre Celebi
 * @date 06.18.2007
 */

double
calc_error ( const ErrorMeasure err_meas, const Image * orig_img,
	     const Image * est_img )
{
 return calc_error_ ( err_meas, orig_img, est_img, 3 );
}
