
/* 
 * Note: The following routines in this file are adapted from the pymorph (release 0.8) software (http://sourceforge.net/projects/pymorph):
 *       h_minima_transform, h_maxima_transform, regional_minima, regional_maxima. The pymorph copyright notice is given below. 
 */

/* 
 * The BSD Licence
 * Copyright (c) 2003, Roberto A. Lotufo, UNICAMP-University of Campinas; CenPRA-Renato Archer Research Center, Rubens C. Machado. All rights reserved. 
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: 
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary 
 * form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided 
 * with the distribution. Neither the name of UNICAMP, CenPRA nor the names of its contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
 * THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** 
 * @file gray_morpho.c
 * Routines for various grayscale morphological operations
 */

#include <image.h>
#include <libmorpho.h>

#define GRAY_MORPH_OP( OP )\
 byte *in_data;\
 byte *out_data;\
 int num_rows, num_cols;\
 int ret_code;\
 Image *out_img;\
 \
 if ( !is_gray_img ( in_img ) )\
  {\
   ERROR_RET ( "Not a grayscale image !", NULL );\
  }\
 \
 if ( !IS_VALID_OBJ ( se ) )\
  {\
   ERROR_RET ( "Invalid structuring element object !", NULL );\
  }\
 \
 num_rows = get_num_rows ( in_img );\
 num_cols = get_num_cols ( in_img );\
 in_data = get_img_data_1d ( in_img );\
 \
 out_img = alloc_img ( PIX_GRAY, num_rows, num_cols );\
 if ( IS_NULL ( out_img ) )\
  {\
   ERROR_RET ( "Insufficient memory !", NULL );\
  }\
 \
 out_data = get_img_data_1d ( out_img );\
 \
 ret_code = MORPHO_ERROR;\
 \
 if ( se->type == STRL_LINE )\
  {\
   if ( se->num_rows == 1 )\
    {\
     ret_code = OP##ByAnchor_1D_horizontal ( in_data, out_data, num_cols, num_rows, se->num_cols );\
    }\
   else if ( se->num_cols == 1 )\
    {\
     ret_code = OP##ByAnchor_1D_vertical ( in_data, out_data, num_cols, num_rows, se->num_rows );\
    }\
   else\
    {\
     ret_code = OP##_arbitrary_SE ( in_data, out_data, num_cols, num_rows, se->data_1d, se->num_cols, se->num_rows, se->origin_col, se->origin_row );\
    }\
  }\
 else if ( se->type == STRL_RECT )\
  {\
   if ( se_origin_at_center ( se ) )\
    {\
     if ( se->num_rows == 1 )\
      {\
       ret_code = OP##ByAnchor_1D_horizontal ( in_data, out_data, num_cols, num_rows, se->num_cols );\
      }\
     else if ( se->num_cols == 1 )\
      {\
       ret_code = OP##ByAnchor_1D_vertical ( in_data, out_data, num_cols, num_rows, se->num_rows );\
      }\
     else\
      {\
       ret_code = OP##ByAnchor_2D ( in_data, out_data, num_cols, num_rows, se->num_cols, se->num_rows );\
      }\
    }\
   else\
    {\
     ret_code = OP##_arbitrary_SE ( in_data, out_data, num_cols, num_rows, se->data_1d, se->num_cols, se->num_rows, se->origin_col, se->origin_row );\
    }\
  }\
 else if ( se->type == STRL_DISK || se->type == STRL_FLAT )\
  {\
   ret_code = OP##_arbitrary_SE ( in_data, out_data, num_cols, num_rows, se->data_1d, se->num_cols, se->num_rows, se->origin_col, se->origin_row );\
  }\
 else if ( se->type == STRL_NONFLAT )\
  {\
   ERROR ( "Non-flat structuring elements are currently not supported !" );\
  }\
 else\
  {\
   ERROR ( "Invalid structuring element type !" );\
  }\
 \
 return ( ret_code == MORPHO_SUCCESS ? out_img : NULL );\

Image *
close_gray ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "close_gray" );
 GRAY_MORPH_OP ( closing );
}

Image *
dilate_gray ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "dilate_gray" );
 GRAY_MORPH_OP ( dilation );
}

Image *
erode_gray ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "erode_gray" );
 GRAY_MORPH_OP ( erosion );
}

Image *
open_gray ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "open_gray" );
 GRAY_MORPH_OP ( opening );
}

#undef GRAY_MORPH_OP

/** 
 * @brief Calculates the morphological gradient of an image
 *
 * @param[in] in_img Input image pointer { binary, grayscale }
 * @param[in] se Structuring element pointer
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
morpho_gradient ( const Image * in_img, const Strel * se )
{
 return sub_img ( dilate_gray ( in_img, se ), erode_gray ( in_img, se ) );
}

/** 
 * @brief Eliminates all minima in an image whose contrast is less than a given value
 *
 * @param[in] in_img Input image pointer { grayscale }
 * @param[in] se Structuring element pointer
 * @param[in] contrast Contrast value
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
h_minima_transform ( const Image * in_img, const Strel * se,
		     const int contrast )
{
 SET_FUNC_NAME ( "h_minima_transform" );

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image", NULL );
  }

 return sup_rec_img ( add_img_scalar ( in_img, contrast ), in_img, se );
}

/** 
 * @brief Eliminates all maxima in an image whose contrast is less than a given value
 *
 * @param[in] in_img Input image pointer { grayscale }
 * @param[in] se Structuring element pointer
 * @param[in] contrast Contrast value
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
h_maxima_transform ( const Image * in_img, const Strel * se,
		     const int contrast )
{
 SET_FUNC_NAME ( "h_maxima_transform" );

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image", NULL );
  }

 return inf_rec_img ( sub_img_scalar ( in_img, contrast ), in_img, se );
}

/** 
 * @brief Determine the regional minima of an image
 *
 * @param[in] in_img Input image pointer { grayscale }
 * @param[in] se Structuring element pointer
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
regional_minima ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "regional_minima" );

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image", NULL );
  }

 return
  union_img ( threshold_img
	      ( sub_img
		( sup_rec_img ( add_img_scalar ( in_img, 1 ), in_img, se ),
		  in_img ), 0 ), negate_img ( threshold_img ( in_img, 0 ) ) );
}

/** 
 * @brief Determine the regional maxima of an image
 *
 * @param[in] in_img Input image pointer { grayscale }
 * @param[in] se Structuring element pointer
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
regional_maxima ( const Image * in_img, const Strel * se )
{
 SET_FUNC_NAME ( "regional_maxima" );

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image", NULL );
  }

 return regional_minima ( negate_img ( in_img ), se );
}

/** 
 * @brief Determine the regional minima of the h-minima transform an image
 *
 * @param[in] in_img Input image pointer { grayscale }
 * @param[in] se Structuring element pointer
 * @param[in] contrast Contrast value for the h-minima transform
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
extended_minima_transform ( const Image * in_img, const Strel * se,
			    const int contrast )
{
 SET_FUNC_NAME ( "extended_minima_transform" );

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image", NULL );
  }

 return regional_minima ( h_minima_transform ( in_img, se, contrast ), se );
}

/** 
 * @brief Determine the regional maxima of the h-maxima transform an image
 *
 * @param[in] in_img Input image pointer { grayscale }
 * @param[in] se Structuring element pointer
 * @param[in] contrast Contrast value for the h-maxima transform
 *
 * @return Pointer to the output image or NULL
 * 
 * @author M. Emre Celebi
 * @date 01.20.2008
 */

Image *
extended_maxima_transform ( const Image * in_img, const Strel * se,
			    const int contrast )
{
 SET_FUNC_NAME ( "extended_maxima_transform" );

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image", NULL );
  }

 return regional_maxima ( h_maxima_transform ( in_img, se, contrast ), se );
}
