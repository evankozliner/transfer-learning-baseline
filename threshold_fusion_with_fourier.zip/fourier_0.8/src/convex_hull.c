
/** 
 * @file convex_hull.c
 * Routines for Convex Hull construction and calculation of convex hull related features
 */

/* http://cm.bell-labs.com/cm/cs/who/clarkson/2dch.c 
 * Ken Clarkson wrote this.  Copyright (c) 1996 by AT&T..
 * Permission to use, copy, modify, and distribute this software for any
 * purpose without fee is hereby granted, provided that this entire notice
 * is included in all copies of any software which is or includes a copy
 * or modification of this software and in all copies of the supporting
 * documentation for such software.
 * THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY.  IN PARTICULAR, NEITHER THE AUTHORS NOR AT&T MAKE ANY
 * REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
 * OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
 */

/*
 * Two-dimensional convex hull
 * Works in O(n log n); I think a bit faster than Graham scan;
 * somewhat like Procedure 8.2 in Edelsbrunner's "Algorithms in Combinatorial Geometry".
 */

#include <image.h>

static int cmpl ( const void *a, const void *b );
static int cmph ( const void *a, const void *b );
static int make_chain ( const int num_pts,
			int ( *cmp ) ( const void *, const void * ),
			Point ** point );

/** @cond INTERNAL_MACRO */
#define CMPM( A, B, field )\
delta = ( * ( Point ** ) A )->field - ( * ( Point ** ) B )->field;\
if ( delta > 0 ) return 1;\
if ( delta < 0 ) return -1;\


/** @endcond INTERNAL_MACRO */

static int
cmpl ( const void *a, const void *b )
{
 double delta;

 /* Compare the row values */
 CMPM ( a, b, row );
 /* If they are equal, compare the column values */
 CMPM ( b, a, col );

 return 0;
}

#undef CMPM

static int
cmph ( const void *a, const void *b )
{
 return cmpl ( b, a );
}

/** @cond INTERNAL_MACRO */

/* True if points i, j, k counterclockwise */
#define CCW( X, i, j, k )\
( ( X[i]->row - X[j]->row ) * ( X[k]->col - X[j]->col ) - ( X[i]->col - X[j]->col ) * ( X[k]->row - X[j]->row ) <= 0 )

/** @endcond INTERNAL_MACRO */

static int
make_chain ( const int num_pts, int ( *cmp ) ( const void *, const void * ),
	     Point ** point )
{
 int i, j, s = 1;
 Point *tmp_point;

 qsort ( point, num_pts, sizeof ( Point * ), cmp );

 for ( i = 2; i < num_pts; i++ )
  {
   for ( j = s; j >= 1 && CCW ( point, i, j, j - 1 ); j-- )
    {
     /* Empty body */
     ;
    }
   s = j + 1;

   /* Swap points point[i] and point[s] */
   tmp_point = point[s];
   point[s] = point[i];
   point[i] = tmp_point;
  }

 return s;
}

#undef CCW

/** 
 * @brief Calculates the convex hull of an object
 *
 * @param[in] cont Contour pointer for the object
 *
 * @return Pointer to the list of convex hull points
 *
 * @ref Andrew A.M. (1979) "Another Efficient Algorithm for Convex Hulls in 
 *      Two Dimensions" Information Processing Letters, 9(5): 216-219.
 *
 * @author Ken Clarkson
 * @date 11.18.2007
 */

PointList *
calc_2d_convex_hull ( const PointList * cont )
{
 SET_FUNC_NAME ( "calc_2d_convex_hull" );
 int ik;
 int num_low;
 int num_pts;
 PointList *hull;

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", NULL );
  }

 num_pts = get_num_pts ( cont );

 /* Clone the input point list (the extra slot is for duplicating the first point) */
 hull = alloc_point_list ( num_pts + 1 );
 for ( ik = 0; ik < num_pts; ik++ )
  {
   hull->point[ik] = alloc_point ( cont->point[ik]->row, cont->point[ik]->col );
  }
 hull->type = GEN_VALID;

 /* Constuct the lower hull */
 num_low = make_chain ( num_pts, cmpl, hull->point );

 /* Duplicate the first point at the end */
 hull->point[num_pts] = alloc_point ( cont->point[0]->row,
				      cont->point[0]->col );

 /* Construct the upper hull and update the number of points on the complete hull */
 hull->num_pts =
  num_low + make_chain ( num_pts - num_low + 1, cmph, hull->point + num_low );

 return hull;
}

/** 
 * @brief Calculates the maximum diameter of an object
 *
 * @param[in] cont Contour pointer for the object
 *
 * @return Maximum Diameter value or DBL_MIN
 *
 * @note 1) The computational time can be reduced by passing as input 
 *       only the points on the convex hull. 
 *       2) This method is O(n^2). If the convex hull is already computed,
 *       the Rotating Calipers method can be used to determine the maximum 
 *       diameter in O(n) time. See Toussaint G.T. (1983) "Solving Geometric 
 *       Problems with the Rotating Calipers" Proc. of the IEEE MELECON'83 Conf.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_max_diameter ( const PointList * cont )
{
 SET_FUNC_NAME ( "calc_max_diameter" );
 int aa, bb;
 int num_pts;
 double dist;
 double diam;

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", DBL_MIN );
  }

 num_pts = get_num_pts ( cont );

 /* Find the minimum distance between any pair of points */
 diam = 0.0;

 for ( aa = 0; aa < num_pts; aa++ )
  {
   for ( bb = aa + 1; bb < num_pts; bb++ )
    {
     dist = L2_DIST_2D_SQR ( cont->point[aa]->row, cont->point[aa]->col,
			     cont->point[bb]->row, cont->point[bb]->col );
     if ( diam < dist )
      {
       diam = dist;
      }
    }
  }

 return sqrt ( diam );
}

/** 
 * @brief Calculates the compactness of an object
 *
 * @param[in] img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] cont Contour pointer for the object
 *
 * @return Compactness value or DBL_MIN
 *
 * @note The computational time can be reduced by passing as input 
 *       only the points on the convex hull. 
 *
 * @ref Russ J.C. (2007) "The Image Processing Handbook (5th Ed.)" CRC Press
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_compactness ( const Image * img, const int label, const PointList * cont )
{
 SET_FUNC_NAME ( "calc_compactness" );

 if ( !is_bin_or_label_img ( img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 if ( !IS_VALID_OBJ ( cont ) )
  {
   ERROR_RET ( "Invalid point list object !", DBL_MIN );
  }

 return ( calc_equi_diameter ( img, label ) / calc_max_diameter ( cont ) );
}

/** 
 * @brief Calculates the solidity of an object
 *
 * @param[in] in_img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] hull Pointer to the set of convex hull points
 *
 * @return Solidity value or DBL_MIN
 *
 * @ref Sonka M., Hlavac V., and Boyle R. (1999) "Image 
 *      Processing, Analysis, and Machine Vision" PWS Pub.
 *
 * @author M. Emre Celebi
 * @date 11.18.2007
 */

double
calc_solidity ( const Image * in_img, const int label, const PointList * hull )
{
 SET_FUNC_NAME ( "calc_solidity" );
 int num_rows, num_cols;
 int ik;
 int num_pts;
 double obj_area, hull_area;
 Point *centroid;
 Image *hull_img;

 if ( !is_bin_or_label_img ( in_img ) )
  {
   ERROR_RET ( "Not a binary or label image !", DBL_MIN );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return DBL_MIN;
  }

 if ( !IS_VALID_OBJ ( hull ) )
  {
   ERROR_RET ( "Invalid point list object !", DBL_MIN );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 hull_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( hull_img ) )
  {
   ERROR_RET ( "Insufficient memory !", DBL_MIN );
  }

 num_pts = get_num_pts ( hull );

 /* Draw the Convex Hull so that you can seed fill it */
 for ( ik = 0; ik < num_pts - 1; ik++ )
  {
   draw_line ( hull->point[ik], hull->point[ik + 1], OBJECT, hull_img );
  }

 /* The line between the last and first points */
 draw_line ( hull->point[num_pts - 1], hull->point[0], OBJECT, hull_img );

 /* Seed fill the convex hull object using the centroid */
 centroid = calc_obj_centroid ( hull_img, OBJECT );
 fill_region ( ( int ) centroid->row, ( int ) centroid->col, OBJECT, hull_img );

 obj_area = count_obj_pixels ( in_img, label );
 hull_area = count_obj_pixels ( hull_img, OBJECT );

 free_img ( hull_img );

 return ( obj_area / hull_area );
}
