
/** 
 * @file gen_fourier_desc.c
 * Routines for the rotation, scaling, translation invariant Generic Fourier Descriptor
 */

#include <image.h>

static Complex **calc_gen_fourier_basis ( const Image * img, const int rad_res,
					  const int ang_res, const int radius );

/* This routine always receives a binary image */
static Complex **
calc_gen_fourier_basis ( const Image * img, const int rad_res,
			 const int ang_res, const int radius )
{
 byte **data;
 int ir, ic;
 int rad, ang;
 int diameter;
 double factor;
 double theta;
 double dist;
 double angle;
 Complex **basis;

 diameter = 2 * radius;
 factor = TWO_PI / radius;

 data = get_img_data_nd ( img );
 basis = alloc_nd ( sizeof ( Complex ), 2, rad_res, ang_res );

 for ( rad = 0; rad < rad_res; rad++ )
  {
   for ( ang = 0; ang < ang_res; ang++ )
    {
     for ( ir = 0; ir < diameter; ir++ )
      {
       for ( ic = 0; ic < diameter; ic++ )
	{
	 dist = L2_DIST_2D ( ir, ic, radius, radius );
	 theta = atan2 ( ir - radius, ic - radius );
	 if ( IS_NEG ( theta ) )
	  {
	   theta += TWO_PI;
	  }

	 if ( dist <= radius && data[ir][ic] == OBJECT )
	  {
	   angle = factor * dist * rad + theta * ang;
	   basis[rad][ang].real += cos ( angle );
	   basis[rad][ang].imag -= sin ( angle );
	  }
	}
      }
    }
  }

 return basis;
}

/** 
 * @brief Calculates the rotation, scaling, translation invariant Generic Fourier Descriptor
 *
 * @param[in] in_img Image pointer { binary or label }
 * @param[in] label Label of the object { positive }
 * @param[in] rad_res Radial resolution { positive }
 * @param[in] ang_res Angular resolution { positive }
 * @param[in] radius Radius of the circle into which the object 
 *                   will be scaled to fit { positive }
 *
 * @return Pointer to the Generic Fourier Descriptor coefficients or NULL
 *
 * @note The number of coefficients in the descriptor is ( RAD_RES * ANG_RES )
 *
 * @ref 1) Zhang D.S. and Lu G. (2002) "Generic Fourier Descriptor for Shape-Based
 *         Image Retrieval" Proc. of the IEEE ICME'02 Conf., 1: 425-428.
 *      2) Zhang D.S. and Lu G. (2004) "Review of Shape Representation and Description 
 *         Techniques" Pattern Recognition, 37(1): 1-19.
 *
 * @author Dengsheng Zhang
 * @date 11.18.2007
 */

double *
calc_gen_fourier_desc ( const Image * in_img, const int label,
			const int rad_res, const int ang_res, const int radius )
{
 SET_FUNC_NAME ( "calc_gen_fourier_desc" );
 int rad, ang;
 int term;
 double norm;
 double *gfd;
 Complex **basis;
 Image *scaled_img;

 if ( !is_bin_or_label_img ( in_img ) )
  {
   ERROR_RET ( "Not a binary or label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( rad_res <= 0 )
  {
   ERROR ( "Radial resolution ( %d ) must be positive !", rad_res );
   return NULL;
  }

 if ( ang_res <= 0 )
  {
   ERROR ( "Angular resolution ( %d ) must be positive !", ang_res );
   return NULL;
  }

 if ( radius <= 0 )
  {
   ERROR ( "Radius ( %d ) must be positive !", radius );
   return NULL;
  }

 /* Scale the object to fit it into a circle */
 scaled_img = circular_scale ( in_img, label, radius );

 /* Calculate the Generic Fourier Descriptor Basis */
 basis = calc_gen_fourier_basis ( scaled_img, rad_res, ang_res, radius );

 gfd = ( double * ) malloc ( rad_res * ang_res * sizeof ( double ) );
 if ( IS_NULL ( gfd ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Calculate the Generic Fourier Descriptor */
 term = 0;
 norm = basis[0][0].real;
 for ( rad = 0; rad < rad_res; rad++ )
  {
   for ( ang = 0; ang < ang_res; ang++ )
    {
     if ( rad == 0 && ang == 0 )
      {
       basis[0][0].real /= PI * radius * radius;
       basis[0][0].imag /= PI * radius * radius;
      }
     else
      {
       basis[rad][ang].real /= norm;
       basis[rad][ang].imag /= norm;
      }

     gfd[term] = L2_NORM_2D ( basis[rad][ang].real, basis[rad][ang].imag );
     term++;
    }
  }

 free_img ( scaled_img );
 free_nd ( basis, 2 );

 return gfd;
}
