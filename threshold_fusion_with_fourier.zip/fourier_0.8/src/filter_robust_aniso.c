
/** 
 * @file filter_robust_aniso.c
 * Routines for Robust Anisotropic Diffusion filtering of a grayscale image
 */

#include <image.h>

/** @cond INTERNAL_FUNCTION */

static double
tukey ( const double x, const double sigma )
{
 if ( fabs ( x ) < sigma )
  {
   double ratio = x / sigma;
   double term = 1.0 - ratio * ratio;

   return x * term * term;
  }

 return 0.0;
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

static int
calc_mad ( byte ** in_data, const int num_rows, const int num_cols )
{
 SET_FUNC_NAME ( "calc_mad" );
 int ir, ic, ik;
 int num_elems;
 int r_begin, r_end;
 int c_begin, c_end;
 int index;
 int center_val;
 int median, mad;
 int *grad;
 int *abs_grad;

 r_begin = 1;
 r_end = num_rows - 1;
 c_begin = 1;
 c_end = num_cols - 1;
 num_elems = 4 * ( r_end - r_begin ) * ( c_end - c_begin );

 grad = ( int * ) calloc ( num_elems, sizeof ( int ) );
 abs_grad = ( int * ) calloc ( num_elems, sizeof ( int ) );
 if ( IS_NULL ( grad ) || IS_NULL ( abs_grad ) )
  {
   ERROR_RET ( "Insufficient memory !", DBL_MIN );
  }

 /* Calculate the gradient at each pixel */
 index = 0;
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     center_val = in_data[ir][ic];

     /* East */
     grad[index++] = in_data[ir][ic - 1] - center_val;

     /* North */
     grad[index++] = in_data[ir - 1][ic] - center_val;

     /* West */
     grad[index++] = in_data[ir][ic + 1] - center_val;

     /* South */
     grad[index++] = in_data[ir + 1][ic] - center_val;
    }
  }

 /* Calculate the gradient magnitudes */
 for ( ik = 0; ik < num_elems; ik++ )
  {
   abs_grad[ik] = abs ( grad[ik] );
  }

 /* Calculate the median of the gradient magnitudes */
 median = find_median ( num_elems, abs_grad );

 free ( abs_grad );

 /* Calculate the absolute deviations from the median gradient magnitude */
 for ( ik = 0; ik < num_elems; ik++ )
  {
   grad[ik] = abs ( grad[ik] - median );
  }

 /* Calculate the median absolute deviation */
 mad = find_median ( num_elems, grad );

 free ( grad );

 return mad;
}

/** @endcond INTERNAL_FUNCTION */

/** 
 * @brief Implements the Robust Anisotropic Diffusion filter
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] num_iters Number of iterations { positive }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note Pixels outside the convolution area are set to 0.
 * @ref Black M.J., Sapiro G., Marimont D., Heeger D. (1998) "Robust 
 *      Anisotropic Diffusion" IEEE Trans. on Image Processing, 7(3): 421-432
 *      http://www.cs.brown.edu/~black/Papers/transip.7.3.1998.pdf
 *
 * @author M. Emre Celebi
 * @date 05.02.2008
 */

Image *
filter_robust_aniso ( const Image * in_img, const int num_iters )
{
 SET_FUNC_NAME ( "filter_robust_aniso" );
 int num_rows, num_cols;
 int it, ir, ic;
 int r_begin, r_end;
 int c_begin, c_end;
 int mad;
 double conv_sum;
 double center_val;
 double sigma, sigma_e;
 double lambda;
 double **in_data;
 double **out_data;
 Image *in_dbl_img;
 Image *out_dbl_img;
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( num_iters <= 0 )
  {
   ERROR ( "Number of iterations ( %d ) must be positive !", num_iters );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 /* Convert the input image to double type */
 in_dbl_img = byte_to_dbl_img ( in_img );
 in_data = get_img_data_nd ( in_dbl_img );

 out_dbl_img = alloc_img ( PIX_DBL_1B, num_rows, num_cols );
 if ( IS_NULL ( out_dbl_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_dbl_img );

 /* Calculate the median absolute deviation */
 mad = calc_mad ( get_img_data_nd ( in_img ), num_rows, num_cols );

 /* Calculate the robust scale estimate */
 sigma_e = 1.4826 * mad;
 sigma = sigma_e * sqrt ( 5.0 );
 lambda = 0.25 * ( 1.0 / tukey ( sigma_e, sigma ) );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = 1;
 r_end = num_rows - 1;
 c_begin = 1;
 c_end = num_cols - 1;

 for ( it = 0; it < num_iters; it++ )
  {
   for ( ir = r_begin; ir < r_end; ir++ )
    {
     for ( ic = c_begin; ic < c_end; ic++ )
      {
       conv_sum = 0.0;
       center_val = in_data[ir][ic];

       /* 4-nearest-neighbor discretization of the Laplacian operator */
       out_data[ir][ic] = center_val +
	lambda * ( tukey ( in_data[ir][ic - 1] - center_val, sigma ) +
		   tukey ( in_data[ir - 1][ic] - center_val, sigma ) +
		   tukey ( in_data[ir][ic + 1] - center_val, sigma ) +
		   tukey ( in_data[ir + 1][ic] - center_val, sigma ) );
      }
    }

   /* Assign the output of current iteration to the input of next iteration */
   in_data = out_data;
  }

 /* Convert the output image to byte type */
 out_img = dbl_to_byte_img ( out_dbl_img );

 free_img ( in_dbl_img );
 free_img ( out_dbl_img );

 return out_img;
}
