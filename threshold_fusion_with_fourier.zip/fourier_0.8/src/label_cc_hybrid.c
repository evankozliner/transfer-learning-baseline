
/** 
 * @file label_cc_hybrid.c
 * Routines for labeling the connected components in a binary image
 */

#include <image.h>

static void label_4 ( const int num_cols, const int cur_label, int n,
		      int *out_data_1d );
static void label_8 ( const int num_cols, const int cur_label, int ir, int ic,
		      int **out_data_2d );

/** @cond INTERNAL_FUNCTION */

/* This function is not used */

/* 
  Handles the boundary conditions 
  (objects can touch the image walls) 
 */
static void
label_4_boundary ( const int num_cols, const int cur_label, int n,
		   int *out_data_1d )
{
 int m;
 int num_cols_t2;

 num_cols_t2 = num_cols * 2;

 while ( ( n % num_cols ) && out_data_1d[n - 1] < 0 )
  {
   n--;
  }

 m = n;

 do
  {
   out_data_1d[m++] = cur_label;
  }
 while ( ( m % num_cols ) && ( out_data_1d[m] < 0 ) );

 n -= num_cols;
 m -= num_cols;
 while ( n < m )
  {
   if ( ( n > 0 ) && ( out_data_1d[n] < 0 ) )
    {
     label_4_boundary ( num_cols, cur_label, n, out_data_1d );
    }
   if ( n < ( num_cols - 2 ) * num_cols && out_data_1d[n + num_cols_t2] < 0 )
    {
     label_4_boundary ( num_cols, cur_label, n + num_cols_t2, out_data_1d );
    }
   n++;
  }
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/* 
  Does not handle the boundary conditions 
  (objects cannot touch the image walls) 
 */
static void
label_4 ( const int num_cols, const int cur_label, int n, int *out_data_1d )
{
 int m;
 int num_cols_t2;

 m = n;
 num_cols_t2 = num_cols * 2;

 while ( out_data_1d[--n] < 0 )
  {
   out_data_1d[n] = cur_label;
  }

 while ( out_data_1d[m] < 0 )
  {
   out_data_1d[m++] = cur_label;
  }

 n -= num_cols;
 m -= num_cols;
 while ( ++n < m )
  {
   if ( out_data_1d[n] < 0 )
    {
     label_4 ( num_cols, cur_label, n, out_data_1d );
    }
   if ( out_data_1d[n + num_cols_t2] < 0 )
    {
     label_4 ( num_cols, cur_label, n + num_cols_t2, out_data_1d );
    }
  }
}

/** @endcond INTERNAL_FUNCTION */

/** @cond INTERNAL_FUNCTION */

/* 
  Does not handle the boundary conditions 
  (objects cannot touch the image walls) 
 */
static void
label_8 ( const int num_cols, const int cur_label, int ir, int ic,
	  int **out_data_2d )
{
 int m;

 while ( out_data_2d[ir][--ic] < 0 )
  {
   /* Empty body */ ;
  }

 m = ic;

 while ( out_data_2d[ir][++m] < 0 )
  {
   out_data_2d[ir][m] = cur_label;
  }

 ir--;

 while ( ic <= m )
  {
   if ( out_data_2d[ir][ic] < 0 )
    {
     label_8 ( num_cols, cur_label, ir, ic, out_data_2d );
    }

   if ( out_data_2d[ir + 2][ic] < 0 )
    {
     label_8 ( num_cols, cur_label, ir + 2, ic, out_data_2d );
    }
   ic++;
  }
}

/** @endcond INTERNAL_FUNCTION */

/** 
 * @brief Labels the connected components in a binary image using
 *        the hybrid method
 *
 * @param[in] in_img Image pointer { binary }
 * @param[in] connectivity Connectivity { 4 or 8 }
 *
 * @return Label image or NULL
 *
 * @note 1) If there is any object touching the walls, the Union-Find based method is called.
 *       2) Background is labeled as 0. Connected component labels range from 1 to NUM_CC.
 * @ref Martin-Herrero J. (2007) "Hybrid Object Labelling in Digital 
 *      Images" Machine Vision and Applications, 18(1): 1-15. 
 *
 * @see #label_cc, #label_cc_trace
 *
 * @author Martin-Herrero J.
 * @date 06.19.2007
 */

Image *
label_cc_hybrid ( const Image * in_img, const int connectivity )
{
 SET_FUNC_NAME ( "label_cc_hybrid" );
 byte *in_data;
 int num_rows, num_cols;
 int num_pixels;
 int n;
 int cur_label;
 int ir, ic;
 int *out_data_1d;
 int **out_data_2d;
 Image *out_img;

 if ( !is_bin_img ( in_img ) )
  {
   ERROR_RET ( "Not a binary image !", NULL );
  }

 if ( connectivity != 4 && connectivity != 8 )
  {
   ERROR ( "Connectivity ( %d ) must be either 4 or 8 !", connectivity );
   return NULL;
  }

 /* Cannot handle objects touching the walls */
 if ( obj_touch_walls ( in_img ) )
  {
   return label_cc ( in_img, connectivity );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_pixels = num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Label image is of INT_1B type */
 out_img = alloc_img ( PIX_INT_1B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data_1d = get_img_data_1d ( out_img );
 out_data_2d = get_img_data_nd ( out_img );

 for ( n = 0; n < num_pixels; n++ )
  {
   if ( in_data[n] == OBJECT )
    {
     /* Initialize the output pixels with an invalid label */
     out_data_1d[n] = -1;
    }
  }

 /* Start from label 0 */
 cur_label = 0;

 if ( connectivity == 4 )
  {
   for ( n = num_cols; n < num_pixels - num_cols; n++ )
    {
     if ( out_data_1d[n] < 0 )
      {
       cur_label++;
       label_4 ( num_cols, cur_label, n, out_data_1d );
      }
    }
  }
 else
  {
   for ( ir = 1; ir < num_rows - 1; ir++ )
    {
     for ( ic = 1; ic < num_cols - 1; ic++ )
      {
       if ( out_data_2d[ir][ic] < 0 )
	{
	 cur_label++;
	 label_8 ( num_cols, cur_label, ir, ic, out_data_2d );
	}
      }
    }
  }

 /* Determine the number of connected components */
 out_img->num_cc = cur_label;

 return out_img;
}
