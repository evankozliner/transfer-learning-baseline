
/** 
 * @file scale.c
 * Routines for scaling an image
 */

#include <image.h>

#define	filter_support		(1.0)

static double
filter ( t )
     double t;
{
 /* f(t) = 2|t|^3 - 3|t|^2 + 1, -1 <= t <= 1 */
 if ( t < 0.0 )
  t = -t;
 if ( t < 1.0 )
  return ( ( 2.0 * t - 3.0 ) * t * t + 1.0 );
 return ( 0.0 );
}

#define	box_support		(0.5)

static double
box_filter ( t )
     double t;
{
 if ( ( t > -0.5 ) && ( t <= 0.5 ) )
  return ( 1.0 );
 return ( 0.0 );
}

#define	triangle_support	(1.0)

static double
triangle_filter ( t )
     double t;
{
 if ( t < 0.0 )
  t = -t;
 if ( t < 1.0 )
  return ( 1.0 - t );
 return ( 0.0 );
}

#define	bell_support		(1.5)

static double
bell_filter ( t )		/* box (*) box (*) box */
     double t;
{
 if ( t < 0 )
  t = -t;
 if ( t < .5 )
  return ( .75 - ( t * t ) );
 if ( t < 1.5 )
  {
   t = ( t - 1.5 );
   return ( .5 * ( t * t ) );
  }
 return ( 0.0 );
}

#define	B_spline_support	(2.0)

static double
B_spline_filter ( t )		/* box (*) box (*) box (*) box */
     double t;
{
 double tt;

 if ( t < 0 )
  t = -t;
 if ( t < 1 )
  {
   tt = t * t;
   return ( ( .5 * tt * t ) - tt + ( 2.0 / 3.0 ) );
  }
 else if ( t < 2 )
  {
   t = 2 - t;
   return ( ( 1.0 / 6.0 ) * ( t * t * t ) );
  }
 return ( 0.0 );
}

static double
sinc ( x )
     double x;
{
 x *= PI;
 if ( x != 0 )
  return ( sin ( x ) / x );
 return ( 1.0 );
}

#define	Lanczos3_support	(3.0)

static double
Lanczos3_filter ( t )
     double t;
{
 if ( t < 0 )
  t = -t;
 if ( t < 3.0 )
  return ( sinc ( t ) * sinc ( t / 3.0 ) );
 return ( 0.0 );
}

#define	Mitchell_support	(2.0)

#define	B	(1.0 / 3.0)
#define	C	(1.0 / 3.0)

static double
Mitchell_filter ( t )
     double t;
{
 double tt;

 tt = t * t;
 if ( t < 0 )
  t = -t;
 if ( t < 1.0 )
  {
   t = ( ( ( 12.0 - 9.0 * B - 6.0 * C ) * ( t * tt ) )
	 + ( ( -18.0 + 12.0 * B + 6.0 * C ) * tt ) + ( 6.0 - 2 * B ) );
   return ( t / 6.0 );
  }
 else if ( t < 2.0 )
  {
   t = ( ( ( -1.0 * B - 6.0 * C ) * ( t * tt ) )
	 + ( ( 6.0 * B + 30.0 * C ) * tt )
	 + ( ( -12.0 * B - 48.0 * C ) * t ) + ( 8.0 * B + 24 * C ) );
   return ( t / 6.0 );
  }
 return ( 0.0 );
}

/*
 *	image rescaling routine
 */

typedef struct
{
 int pixel;
 double weight;
} CONTRIB;

typedef struct
{
 int n;				/* number of contributors */
 CONTRIB *p;			/* pointer to list of contributions */
} CLIST;

						    /* CLIST    *contrib; *//* array of contribution lists */

/* 
	calc_x_contrib()
	
	Calculates the filter weights for a single target column.
	contribX->p must be freed afterwards.

	Returns -1 if error, 0 otherwise.
*/
static int
calc_x_contrib ( contribX, xscale, fwidth, dstwidth, srcwidth, filterf, i )
     CLIST *contribX;		/* Receiver of contrib info */
     double xscale;		/* Horizontal zooming scale */
     double fwidth;		/* Filter sampling width */
     int dstwidth;		/* Target bitmap width */
     int srcwidth;		/* Source bitmap width */
     double ( *filterf ) ( double );	/* Filter proc */
     int i;			/* Pixel column in source bitmap being processed */
{
 double width;
 double fscale;
 double center, left, right;
 double weight;
 int j, k, n;

 if ( xscale < 1.0 )
  {
   /* Shrinking image */
   width = fwidth / xscale;
   fscale = 1.0 / xscale;

   contribX->n = 0;
   contribX->p = ( CONTRIB * ) calloc ( ( int ) ( width * 2 + 1 ),
					sizeof ( CONTRIB ) );
   if ( contribX->p == NULL )
    return -1;

   center = ( double ) i / xscale;
   left = ceil ( center - width );
   right = floor ( center + width );
   for ( j = ( int ) left; j <= right; ++j )
    {
     weight = center - ( double ) j;
     weight = ( *filterf ) ( weight / fscale ) / fscale;
     if ( j < 0 )
      n = -j;
     else if ( j >= srcwidth )
      n = ( srcwidth - j ) + srcwidth - 1;
     else
      n = j;

     k = contribX->n++;
     contribX->p[k].pixel = n;
     contribX->p[k].weight = weight;
    }

  }
 else
  {
   /* Expanding image */
   contribX->n = 0;
   contribX->p = ( CONTRIB * ) calloc ( ( int ) ( fwidth * 2 + 1 ),
					sizeof ( CONTRIB ) );
   if ( contribX->p == NULL )
    return -1;
   center = ( double ) i / xscale;
   left = ceil ( center - fwidth );
   right = floor ( center + fwidth );

   for ( j = ( int ) left; j <= right; ++j )
    {
     weight = center - ( double ) j;
     weight = ( *filterf ) ( weight );
     if ( j < 0 )
      {
       n = -j;
      }
     else if ( j >= srcwidth )
      {
       n = ( srcwidth - j ) + srcwidth - 1;
      }
     else
      {
       n = j;
      }
     k = contribX->n++;
     contribX->p[k].pixel = n;
     contribX->p[k].weight = weight;
    }
  }
 return 0;
}				/* calc_x_contrib */

#define	WHITE_PIXEL ( 255 )
#define	BLACK_PIXEL ( 0 )

#define CLAMP( v, l, h ) ( ( v ) < ( l ) ? ( l ) : ( v ) > ( h ) ? ( h ) : v )

/*
	zoom()

	Resizes bitmaps while resampling them.
*/
static Image *
zoom ( src, dst_num_rows, dst_num_cols, filterf, fwidth )
     const Image *src;
     int dst_num_rows;
     int dst_num_cols;
     double ( *filterf ) ( double );
     double fwidth;
{
 byte *tmp;
 byte **src_data;
 byte **dst_data;
 double xscale, yscale;		/* zoom scale factors */
 int xx;
 int i, j, k;			/* loop variables */
 int n;				/* pixel number */
 double center, left, right;	/* filter calculation variables */
 double width, fscale, weight;	/* filter calculation variables */
 byte pel, pel2;
 Bool bPelDelta;
 CLIST *contribY;		/* array of contribution lists */
 CLIST contribX;
 Image *dst;

 src_data = get_img_data_nd ( src );
 dst = alloc_img ( get_pix_type ( src ), dst_num_rows, dst_num_cols );
 dst_data = get_img_data_nd ( dst );

 /* create intermediate column to hold horizontal dst column zoom */
 tmp = ( byte * ) malloc ( src->num_rows * sizeof ( byte ) );
 if ( tmp == NULL )
  return NULL;

 xscale = ( double ) dst->num_cols / ( double ) src->num_cols;

 /* Build y weights */
 /* pre-calculate filter contributions for a column */
 contribY = ( CLIST * ) calloc ( dst->num_rows, sizeof ( CLIST ) );
 if ( contribY == NULL )
  {
   free ( tmp );
   return NULL;
  }

 yscale = ( double ) dst->num_rows / ( double ) src->num_rows;

 if ( yscale < 1.0 )
  {
   width = fwidth / yscale;
   fscale = 1.0 / yscale;
   for ( i = 0; i < dst->num_rows; ++i )
    {
     contribY[i].n = 0;
     contribY[i].p = ( CONTRIB * ) calloc ( ( int ) ( width * 2 + 1 ),
					    sizeof ( CONTRIB ) );
     if ( contribY[i].p == NULL )
      {
       free ( tmp );
       free ( contribY );
       return NULL;
      }
     center = ( double ) i / yscale;
     left = ceil ( center - width );
     right = floor ( center + width );
     for ( j = ( int ) left; j <= right; ++j )
      {
       weight = center - ( double ) j;
       weight = ( *filterf ) ( weight / fscale ) / fscale;
       if ( j < 0 )
	{
	 n = -j;
	}
       else if ( j >= src->num_rows )
	{
	 n = ( src->num_rows - j ) + src->num_rows - 1;
	}
       else
	{
	 n = j;
	}
       k = contribY[i].n++;
       contribY[i].p[k].pixel = n;
       contribY[i].p[k].weight = weight;
      }
    }
  }
 else
  {
   for ( i = 0; i < dst->num_rows; ++i )
    {
     contribY[i].n = 0;
     contribY[i].p = ( CONTRIB * ) calloc ( ( int ) ( fwidth * 2 + 1 ),
					    sizeof ( CONTRIB ) );
     if ( contribY[i].p == NULL )
      {
       free ( tmp );
       free ( contribY );
       return NULL;
      }
     center = ( double ) i / yscale;
     left = ceil ( center - fwidth );
     right = floor ( center + fwidth );
     for ( j = ( int ) left; j <= right; ++j )
      {
       weight = center - ( double ) j;
       weight = ( *filterf ) ( weight );
       if ( j < 0 )
	{
	 n = -j;
	}
       else if ( j >= src->num_rows )
	{
	 n = ( src->num_rows - j ) + src->num_rows - 1;
	}
       else
	{
	 n = j;
	}
       k = contribY[i].n++;
       contribY[i].p[k].pixel = n;
       contribY[i].p[k].weight = weight;
      }
    }
  }

 for ( xx = 0; xx < dst->num_cols; xx++ )
  {
   if ( 0 != calc_x_contrib ( &contribX, xscale, fwidth,
			      dst->num_cols, src->num_cols, filterf, xx ) )
    {
     goto __zoom_cleanup;
    }
   /* Apply horz filter to make dst column in tmp. */
   for ( k = 0; k < src->num_rows; ++k )
    {
     weight = 0.0;
     bPelDelta = false;
     pel = src_data[k][contribX.p[0].pixel];
     for ( j = 0; j < contribX.n; ++j )
      {
       pel2 = src_data[k][contribX.p[j].pixel];
       if ( pel2 != pel )
	bPelDelta = true;
       weight += pel2 * contribX.p[j].weight;
      }
     weight = bPelDelta ? ROUND ( weight ) : pel;

     tmp[k] = ( byte ) CLAMP ( weight, BLACK_PIXEL, WHITE_PIXEL );
    }				/* next row in temp column */

   free ( contribX.p );

   /* The temp column has been built. Now stretch it 
      vertically into dst column. */
   for ( i = 0; i < dst->num_rows; ++i )
    {
     weight = 0.0;
     bPelDelta = false;
     pel = tmp[contribY[i].p[0].pixel];

     for ( j = 0; j < contribY[i].n; ++j )
      {
       pel2 = tmp[contribY[i].p[j].pixel];
       if ( pel2 != pel )
	bPelDelta = true;
       weight += pel2 * contribY[i].p[j].weight;
      }
     weight = bPelDelta ? ROUND ( weight ) : pel;
     dst_data[i][xx] = ( byte ) CLAMP ( weight, BLACK_PIXEL, WHITE_PIXEL );
    }				/* next dst row */
  }				/* next dst column */

__zoom_cleanup:
 free ( tmp );

 /* free the memory allocated for vertical filter weights */
 for ( i = 0; i < dst->num_rows; ++i )
  free ( contribY[i].p );
 free ( contribY );

 return dst;
}				/* zoom */

#undef WHITE_PIXEL
#undef BLACK_PIXEL
#undef CLAMP

/** 
 * @brief Scales an image
 *
 * @param[in] in_img Image pointer { byte }
 * @param[in] num_rows Number of rows in the scaled image
 * @param[in] num_cols Number of columns in the scaled image
 *
 * @return Pointer to the scaled image or NULL
 *
 * @note Bilinear interpolation is used.
 * @ref Schumacher D. (1992) "General Filtered Image Rescaling"
 *      Graphics Gems III, Academic Press, pp. 8-16
 *
 * @author Dale Schumacher & Ray Gardener
 * @date 02.09.2008
 */

Image *
scale_img ( const Image * in_img, const int num_rows, const int num_cols )
{
 SET_FUNC_NAME ( "scale_img" );
 double ( *filter ) (  ) = triangle_filter;
 double support = triangle_support;
 PixelType pix_type;

 if ( num_rows <= 0 || num_cols <= 0 )
  {
   ERROR ( "Dimensions of the output image ( %d, %d ) must be positive !",
	   num_rows, num_cols );
   return NULL;
  }

 pix_type = get_pix_type ( in_img );

 if ( pix_type == PIX_BIN || pix_type == PIX_GRAY )
  {
   return zoom ( in_img, num_rows, num_cols, filter, support );
  }
 else if ( pix_type == PIX_RGB )
  {
   Image *in_red, *in_green, *in_blue;
   Image *out_red, *out_green, *out_blue;
   Image *out_img;

   /* Extract the red, green, blue bands */
   get_rgb_bands ( in_img, &in_red, &in_green, &in_blue );

   /* Scale the individual bands */
   out_red = zoom ( in_red, num_rows, num_cols, filter, support );
   out_green = zoom ( in_green, num_rows, num_cols, filter, support );
   out_blue = zoom ( in_blue, num_rows, num_cols, filter, support );

   /* Combine the red, green, blue bands to get the output image */
   out_img = combine_rgb_bands ( out_red, out_green, out_blue );

   /* Free the intermediate images */
   free_img ( in_red );
   free_img ( in_green );
   free_img ( in_blue );
   free_img ( out_red );
   free_img ( out_green );
   free_img ( out_blue );

   return out_img;
  }

 ERROR_RET ( "Not a byte image !", NULL );
}

#undef filter_support
#undef box_support
#undef triangle_support
#undef bell_support
#undef B_spline_support
#undef Lanczos3_support
#undef Mitchell_support
