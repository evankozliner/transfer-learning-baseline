
/** 
 * @file threshold_bernsen.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Bernsen's thresholding method
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the thresholding window { positive-odd }
 * @param[in] contrast_threshold Contrast threshold { non-negative }
 *            
 * @return Pointer to the resulting binary image or NULL
 *
 * @reco Bernsen recommends WIN_SIZE = 31 and CONTRAST_THRESHOLD = 15.
 *
 * @ref 1) Bernsen J. (1986) "Dynamic Thresholding of Grey-Level Images" 
 *      Proc. of the 8th Int. Conf. on Pattern Recognition, pp. 1251-1255
 *      2) Sezgin M. and Sankur B. (2004) "Survey over Image Thresholding 
 *         Techniques and Quantitative Performance Evaluation" Journal of 
 *         Electronic Imaging, 13(1): 146-165 
 *         http://citeseer.ist.psu.edu/sezgin04survey.html
 *
 * @author M. Emre Celebi
 * @date 07.26.2007
 */

Image *
threshold_bernsen ( const Image * in_img, const int win_size,
		    const int contrast_threshold )
{
 SET_FUNC_NAME ( "threshold_bernsen" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int gray_val;
 int min_gray, max_gray;	/* min and max gray values in a particular window */
 int mid_gray;			/* mid range of gray values in a particular window */
 int local_contrast;		/* contrast in a particular window */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 if ( contrast_threshold < 0 )
  {
   ERROR ( "Contrast threshold ( %d ) must be non-negative !",
	   contrast_threshold );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     min_gray = MAX_GRAY;
     max_gray = 0;
     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Determine the min and max gray values */
	 gray_val = in_data[iwr][iwc];
	 if ( gray_val < min_gray )
	  {
	   min_gray = gray_val;
	  }
	 if ( max_gray < gray_val )
	  {
	   max_gray = gray_val;
	  }
	}
      }

     /* Calculate the local contrast and mid range */
     local_contrast = max_gray - min_gray;
     mid_gray = 0.5 * ( min_gray + max_gray );

     /* Determine the output pixel value */
     if ( local_contrast < contrast_threshold )
      {
       /* Low contrast region */
       out_data[ir][ic] = ( mid_gray >= 128 ) ? OBJECT : BACKGROUND;
      }
     else
      {
       out_data[ir][ic] = ( in_data[ir][ic] >= mid_gray ) ? OBJECT : BACKGROUND;
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 return out_img;
}
