
/** 
 * @file filter_vsdromf.c
 * Routines for VSDROMF filtering of a color image
 */

#include <image.h>

/** 
 * @brief Implements the VSDROMF (Vector Signal-Dependent Rank Order Mean Filter)
 *
 * @param[in] in_img Image pointer { rgb }
 * @param[in] t0 Threshold 0 { positive }
 * @param[in] t1 Threshold 1 { t0 < }
 * @param[in] t2 Threshold 2 { t1 < }
 * @param[in] t3 Threshold 3 { t2 < }
 *
 * @return Pointer to the filtered image or NULL
 *
 * @note 1) Filtering window is taken as 3x3.
 *       2) Pixels outside the convolution area are set to 0.
 * @reco T0 = 35, T1 = 40, T2 = 45, T3 = 50
 *
 * @ref 1) Moore M.S., Gabbouj M., and Mitra S.K. (1999) "Vector SD-ROM Filter 
 *         for Removal of Impulse Noise from Color Images" Proc. of the 2nd EURASIP 
 *         Conf. focused on DSP for Multimedia Communications and Services (ECMCS�99)
 *      2) Celebi M.E., Kingravi H.A., and Aslandogan Y.A. (2007) "Nonlinear 
 *         Vector Filtering for Impulsive Noise Removal from Color Images" 
 *         Journal of Electronic Imaging, 16(3): tbd
 *         http://www.lsus.edu/faculty/~ecelebi/publications.htm
 *
 * @author M. Emre Celebi
 * @date 08.06.2007
 */

Image *
filter_vsdromf ( const Image * in_img, const double t0, const double t1,
		 const double t2, const double t3 )
{
 SET_FUNC_NAME ( "filter_vsdromf" );
 byte ***in_data;
 byte ***out_data;
 int num_rows, num_cols;
 const int win_size = 3;
 int half_win;
 int win_count;			/* # pixels in the filtering window */
 int center_pix;
 int ir, ic;
 int iwr, iwc;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int wr_begin, wr_end;		/* vertical limits of the filtering window */
 int wc_begin, wc_end;		/* horizontal limits of the filtering window */
 int count;
 int idx_key;
 int *red, *green, *blue;
 int *dist_index;
 double data_key;
 double dist_center;
 double thresh[4];
 double *dist_sum;
 double **dist_mat;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 if ( !( IS_POS ( t0 ) && t0 < t1 && t1 < t2 && t2 < t3 ) )
  {
   ERROR
    ( "Thresholds ( %f, %f, %f, %f ) must be a positive and increasing sequence !",
      t0, t1, t2, t3 );
   return NULL;
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );

 in_data = get_img_data_nd ( in_img );
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 out_data = get_img_data_nd ( out_img );

 half_win = win_size / 2;
 win_count = win_size * win_size;
 center_pix = win_count / 2;

 thresh[0] = t0;
 thresh[1] = t1;
 thresh[2] = t2;
 thresh[3] = t3;

 red = ( int * ) malloc ( win_count * sizeof ( int ) );
 green = ( int * ) malloc ( win_count * sizeof ( int ) );
 blue = ( int * ) malloc ( win_count * sizeof ( int ) );
 dist_sum = ( double * ) malloc ( win_count * sizeof ( double ) );
 dist_index = ( int * ) malloc ( win_count * sizeof ( int ) );

 dist_mat = alloc_nd ( sizeof ( double ), 2, win_count, win_count );

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win;
 r_end = num_rows - half_win;
 c_begin = half_win;
 c_end = num_cols - half_win;

 /* Initialize the vertical limits of the filtering window */
 wr_begin = 0;
 wr_end = win_size;

 /* For each image row */
 for ( ir = r_begin; ir < r_end; ir++ )
  {
   /* Initialize the horizontal limits of the filtering window */
   wc_begin = 0;
   wc_end = win_size;

   /* For each image column */
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     count = 0;

     /* For each window row */
     for ( iwr = wr_begin; iwr < wr_end; iwr++ )
      {
       /* For each window column */
       for ( iwc = wc_begin; iwc < wc_end; iwc++ )
	{
	 /* Store the red, green, blue values */
	 red[count] = in_data[iwr][iwc][0];
	 green[count] = in_data[iwr][iwc][1];
	 blue[count] = in_data[iwr][iwc][2];
	 count++;
	}
      }

     /* Calculate the distances between pairwise color vectors */
     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_mat[iwr][iwc] = DIST_FUNC ( red[iwr], green[iwr], blue[iwr],
					  red[iwc], green[iwc], blue[iwc] );
	}
      }

     /* Calculate the cumulative distance for each pixel */
     memset ( dist_sum, 0, win_count * sizeof ( double ) );

     for ( iwr = 0; iwr < win_count; iwr++ )
      {
       dist_index[iwr] = iwr;

       for ( iwc = 0; iwc < iwr; iwc++ )
	{
	 dist_sum[iwr] += dist_mat[iwc][iwr];
	}

       for ( iwc = iwr + 1; iwc < win_count; iwc++ )
	{
	 dist_sum[iwr] += dist_mat[iwr][iwc];
	}
      }

     /* Sort the pixels according to their cumulative distances (preserve indices) */
     for ( iwc = 1; iwc < win_count;
	   dist_sum[iwr + 1] = data_key, dist_index[iwr + 1] = idx_key, iwc++ )
      {
       for ( data_key = dist_sum[iwc], idx_key = iwc, iwr = iwc - 1;
	     iwr >= 0 && dist_sum[iwr] > data_key;
	     dist_sum[iwr + 1] = dist_sum[iwr], dist_index[iwr + 1] =
	     dist_index[iwr], iwr-- );
      }

     for ( iwr = 0; iwr < center_pix; iwr++ )
      {
       if ( dist_index[iwr] < center_pix )
	{
	 dist_center = dist_mat[dist_index[iwr]][center_pix];
	}
       else
	{
	 dist_center = dist_mat[center_pix][dist_index[iwr]];
	}

       if ( dist_center > thresh[iwr] )	/* Center pixel is noisy */
	{
	 break;
	}
      }

     /* None of the thresholds were exceeded => Center pixel is noise-free */
     if ( iwr == center_pix )
      {
       out_data[ir][ic][0] = red[center_pix];
       out_data[ir][ic][1] = green[center_pix];
       out_data[ir][ic][2] = blue[center_pix];
      }
     else			/* Center pixel is noisy => Replace it with VMF output */
      {
       out_data[ir][ic][0] = red[dist_index[0]];
       out_data[ir][ic][1] = green[dist_index[0]];
       out_data[ir][ic][2] = blue[dist_index[0]];
      }

     /* Update the horizontal limits of the filtering window */
     wc_begin++;
     wc_end++;
    }

   /* Update the vertical limits of the filtering window */
   wr_begin++;
   wr_end++;
  }

 free ( red );
 free ( green );
 free ( blue );
 free_nd ( dist_mat, 2 );

 return out_img;
}
