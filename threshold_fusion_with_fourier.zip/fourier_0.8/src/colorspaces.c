
/** 
 * @file colorspaces.c
 * Routines for color space conversions
 */

#include <image.h>

static double *calc_gamma_lut ( void );

#define ONE_OVER_3 ( 0.33333333333333333333333333333333 )
#define TWO_OVER_3 ( 0.66666666666666666666666666666667 )
#define FOUR_OVER_3 ( 1.3333333333333333333333333333333 )
#define TWO_PI_OVER_3 ( 2.0943951023931954923084289221863 )
#define FOUR_PI_OVER_3 ( 4.1887902047863909846168578443727 )

/** 
 * @brief RGB to Normalized RGB (Chromaticity Coordinates) conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the normalized RGB image or NULL
 *
 * @note 1) The output values are in [0,1]. 
 *       2) The output values are undefined when R = G = B = 0.
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Gevers T. (2001) "Color in Image Search Engines" in Principles of Visual Information 
 *         Retrieval, M.S. Lew (Editor), Springer-Verlag
 *         http://staff.science.uva.nl/~gevers/pub/survey_color.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_nrgb ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_nrgb" );
 byte *in_data;
 int red, green, blue;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 int sum;
 double norm_term;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   sum = red + green + blue;
   if ( sum == 0 )
    {
     /* Singular case */
     out_data[ik] = undefined;
     out_data[ik + 1] = undefined;
     out_data[ik + 2] = undefined;
    }
   else
    {
     norm_term = 1.0 / ( double ) sum;

     /* Substitute divisions with multiplications */
     out_data[ik] = norm_term * red;
     out_data[ik + 1] = norm_term * green;
     out_data[ik + 2] = norm_term * blue;
    }
  }

 return out_img;
}

/** 
 * @brief RGB to Ohta (I1I2I3) space conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 *
 * @return Pointer to the Ohta image or NULL
 *
 * @note I1 is in [0, 255], whereas I2 and I3 are in [-127.5, 127.5].
 * @ref 1) Ohta Y., Kanade T., and Sakai T. (1980) "Color Information for Region Segmentation" 
 *         Computer Graphics and Image Processing, 13(3): 222-241
 *         http://www.ri.cmu.edu/pub_files/pub4/ohta_y_1980_1/ohta_y_1980_1.pdf
 *      2) Gevers T. (2001) "Color in Image Search Engines" in Principles of Visual Information 
 *         Retrieval, M.S. Lew (Editor), Springer-Verlag
 *         http://staff.science.uva.nl/~gevers/pub/survey_color.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_ohta ( const Image * in_img )
{
 SET_FUNC_NAME ( "rgb_to_ohta" );
 byte *in_data;
 int red, green, blue;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   /* Avoid divisions by 3.0, 2.0, and 4.0 */
   out_data[ik] = ONE_OVER_3 * ( red + green + blue );
   out_data[ik + 1] = 0.5 * ( red - blue );
   out_data[ik + 2] = 0.25 * ( 2 * green - red - blue );
  }

 return out_img;
}

/** 
 * @brief Ohta (I1I2I3) space to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @ref 1) Ohta Y., Kanade T., and Sakai T. (1980) "Color Information for Region Segmentation" 
 *         Computer Graphics and Image Processing, 13(3): 222-241
 *      2) Gevers T. (2001) "Color in Image Search Engines" in Principles of Visual Information 
 *         Retrieval, M.S. Lew (Editor), Springer-Verlag
 *         http://staff.science.uva.nl/~gevers/pub/survey_color.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
ohta_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "ohta_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double I1, I2, I3;
 double *in_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   I1 = in_data[ik];
   I2 = in_data[ik + 1];
   I3 = in_data[ik + 2];

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation
    */

   out_data[ik] = ( I1 + I2 - TWO_OVER_3 * I3 ) + 0.5;
   out_data[ik + 1] = ( I1 + FOUR_OVER_3 * I3 ) + 0.5;
   out_data[ik + 2] = ( I1 - I2 - TWO_OVER_3 * I3 ) + 0.5;
  }

 return out_img;
}

#define NORM_C_1 ( 0.0039215686274509803921568627450980 )	/* 1 / 255 */
#define NORM_C_2 ( 0.0019569471624266144814090019569472 )	/* 1 / 511 */
#define NORM_C_3 ( 0.0013071895424836601307189542483660 )	/* 1 / 765 */

/** 
 * @brief RGB to HSI (Hue-Saturation-Intensity) conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the HSI image or NULL
 *
 * @note 1) Hue is in [0, 2*pi], saturation is in [0,1], intensity is in [0, 255].
 *       2) Hue is undefined when R = G = B. 
 *       3) Saturation is undefined when R = G = B = 0.
 * @ref 1) Smith A.R. (1978) "Color Gamut Transform Pairs" Computer Graphics, 12(3): 12-19
 *         ftp://ftp.alvyray.com/Acrobat/Color78.pdf
 *      2) Gonzalez R.C. and Woods R.E. (2002) "Digital Image Processing" Prentice-Hall
 *      3) Shih T-Y. (1995) "The Reversibility of Six Geometric Color Spaces" Photogrammetric 
 *         Engineering and Remote Sensing, 61(10): 1223-1232
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_hsi ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_hsi" );
 byte *in_data;
 int red, green, blue;
 int min;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   if ( ( red == green ) && ( green == blue ) )	/* Achromatic case */
    {
     out_data[ik] = undefined;
     if ( red == 0 )		/* RED = GREEN = BLUE = 0 */
      {
       out_data[ik + 1] = undefined;
       out_data[ik + 2] = 0.0;
      }
     else
      {
       out_data[ik + 1] = 0.0;
       out_data[ik + 2] = NORM_C_1 * red;	/* could be GREEN or BLUE */
      }
    }
   else
    {
     out_data[ik] = acos ( ( 0.5 * ( ( red - green ) + ( red - blue ) ) ) /
			   sqrt ( ( red - green ) * ( red - green )
				  + ( red - blue ) * ( green - blue ) ) );

     if ( green < blue )
      {
       out_data[ik] = TWO_PI - out_data[ik];
      }

     /* Find the minimum of RED, GREEN, and BLUE */
     min = red;
     if ( green < min )
      {
       min = green;
      }
     if ( blue < min )
      {
       min = blue;
      }

     out_data[ik + 1] = 1.0 - ( 3.0 * min / ( red + green + blue ) );
     out_data[ik + 2] = NORM_C_3 * ( red + green + blue );
    }
  }

 return out_img;
}

/** 
 * @brief RGB to HSI (Hue-Saturation-Intensity) conversion using Kender's formulation
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the HSI image or NULL
 *
 * @note 1) This is a fast and exact version of the original RGB to HSI transformation.
 *       2) Hue is in [0, 2*pi], saturation is in [0,1], intensity is in [0, 255].
 *       3) Hue is undefined when R = G = B. 
 *       4) Saturation is undefined when R = G = B = 0.
 * @ref 1) Kender J.R. (1976) "Saturation, Hue, and Normalized Color: Calculation, 
 *         Digitization Effects, and Use" Carnegie-Mellon University Computer Science 
 *         Dept. Technical Report
 *      2) Kender J.R. (1977) "Instabilities in Color Transformations" Proc. of the 1st
 *         IEEE Computer Society Conf. on Pattern Recognition and Image Processing, pp. 266-274
 *      3) Palus, H.; Bereska, D. (1995) "The Comparison Between Transformations from RGB 
 *         Colour Space to IHS Colour Space, Used for Object Recognition" Proc. of the 5th
 *         Int. Conf. on Image Processing and its Applications, pp. 825-827
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_hsi_kender ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_hsi_kender" );
 byte *in_data;
 int red, green, blue;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   if ( ( red > blue ) && ( green >= blue ) )	/* min = BLUE */
    {
     out_data[ik] =
      PI_OVER_3 + atan2 ( SQRT3 * ( green - red ),
			  ( green - blue + red - blue ) );
     out_data[ik + 1] = 1.0 - ( 3.0 * blue / ( red + green + blue ) );
     /* Take the average of RED, GREEN, BLUE and normalize it to [0,1] */
     out_data[ik + 2] = NORM_C_3 * ( red + green + blue );
    }
   else if ( green > red )	/* min = RED */
    {
     out_data[ik] =
      PI + atan2 ( SQRT3 * ( blue - green ), ( blue - red + green - red ) );
     out_data[ik + 1] = 1.0 - ( 3.0 * red / ( red + green + blue ) );
     /* Take the average of RED, GREEN, BLUE and normalize it to [0,1] */
     out_data[ik + 2] = NORM_C_3 * ( red + green + blue );
    }
   else if ( blue > green )	/* min = GREEN */
    {
     out_data[ik] =
      FIVE_PI_OVER_3 + atan2 ( SQRT3 * ( red - blue ),
			       ( red - green + blue - green ) );
     out_data[ik + 1] = 1.0 - ( 3.0 * green / ( red + green + blue ) );
     /* Take the average of RED, GREEN, BLUE and normalize it to [0,1] */
     out_data[ik + 2] = NORM_C_3 * ( red + green + blue );
    }
   else if ( red > blue )	/* RED > BLUE = GREEN :: hue = 0 or hue = 2pi */
    {
     out_data[ik] = 0.0;
     out_data[ik + 1] = 1.0 - ( 3.0 * blue / ( red + green + blue ) );
     /* Take the average of RED, GREEN, BLUE and normalize it to [0,1] */
     out_data[ik + 2] = NORM_C_3 * ( red + green + blue );
    }
   else				/* RED = GREEN = BLUE : Achromatic case */
    {
     out_data[ik] = undefined;

     if ( red == 0 )		/* RED = GREEN = BLUE = 0 */
      {
       out_data[ik + 1] = undefined;
       out_data[ik + 2] = 0.0;
      }
     else
      {
       out_data[ik + 1] = 0.0;
       out_data[ik + 2] = NORM_C_1 * red;	/* could be GREEN or BLUE */
      }
    }
  }

 return out_img;
}

/** 
 * @brief HSI (Hue-Saturation-Intensity) to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @note 1) Hue is in [0, 2*pi], saturation is in [0,1], intensity is in [0, 255].
 *       2) Hue is undefined when R = G = B. 
 *       3) Saturation is undefined when R = G = B = 0.
 * @ref 1) Smith A.R. (1978) "Color Gamut Transform Pairs" Computer Graphics, 12(3): 12-19
 *         ftp://ftp.alvyray.com/Acrobat/Color78.pdf
 *      2) Gonzalez R.C. and Woods R.E. (2002) "Digital Image Processing" Prentice-Hall
 *      3) Shih T-Y. (1995) "The Reversibility of Six Geometric Color Spaces" Photogrammetric 
 *         Engineering and Remote Sensing, 61(10): 1223-1232
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
hsi_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "hsi_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *in_data;
 Image *out_img;
 double H, S, I;
 double red, green, blue;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   H = in_data[ik];
   S = in_data[ik + 1];
   I = in_data[ik + 2];

   if ( 0.0 <= H && H < TWO_PI_OVER_3 )	/* RG sector */
    {
     red = I * ( 1.0 + S * cos ( H ) / cos ( PI_OVER_3 - H ) );
     blue = I * ( 1.0 - S );
     green = 3.0 * I - ( red + blue );
    }
   else if ( TWO_PI_OVER_3 <= H && H < FOUR_PI_OVER_3 )	/* GB sector */
    {
     H -= TWO_PI_OVER_3;
     red = I * ( 1.0 - S );
     green = I * ( 1.0 + S * cos ( H ) / cos ( PI_OVER_3 - H ) );
     blue = 3.0 * I - ( red + green );
    }
   else				/* BR sector */
    {
     H -= FOUR_PI_OVER_3;
     green = I * ( 1.0 - S );
     blue = I * ( 1.0 + S * cos ( H ) / cos ( PI_OVER_3 - H ) );
     red = 3.0 * I - ( blue + green );
    }

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation (except for the singular cases) 
    */

   out_data[ik] = red * MAX_GRAY + .5;
   out_data[ik + 1] = green * MAX_GRAY + .5;
   out_data[ik + 2] = blue * MAX_GRAY + .5;
  }

 return out_img;
}

/** 
 * @brief RGB to HSV (Hue-Saturation-Value) conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the HSV image or NULL
 *
 * @note 1) HSV color model is also called as HSB (Hue-Saturation-Brightness). 
 *       2) Hue, saturation, and value are in [0,1].
 *       3) Hue is undefined when R = G = B. 
 * @ref 1) Smith A.R. (1978) "Color Gamut Transform Pairs" Computer Graphics, 12(3): 12-19
 *         ftp://ftp.alvyray.com/Acrobat/Color78.pdf
 *      2) Shih T-Y. (1995) "The Reversibility of Six Geometric Color Spaces" Photogrammetric 
 *         Engineering and Remote Sensing, 61(10): 1223-1232
 *      3) Foley J.D., van Dam A., Feiner S.K., and Hughes J.F. (1995) "Computer Graphics: 
 *         Principles and Practice" Addison-Wesley
 *      4) http://www.easyrgb.com/math.php?MATH=M20#text20
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_hsv ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_hsv" );
 byte *in_data;
 int red, green, blue;
 int min, max;
 int delta;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   max = MAX_3 ( red, green, blue );
   min = MIN_3 ( red, green, blue );
   delta = max - min;

   out_data[ik + 2] = NORM_C_1 * max;

   if ( delta == 0 )		/* Achromatic case */
    {
     out_data[ik] = undefined;
     out_data[ik + 1] = 0.0;
    }
   else
    {
     out_data[ik + 1] = delta / ( double ) max;

     if ( max == red )
      {
       out_data[ik] = ( green - blue ) / ( 6.0 * delta );

       /* Adjust the Hue value */
       if ( IS_NEG ( out_data[ik] ) )
	{
	 out_data[ik] += 1.0;
	}
      }
     else if ( max == green )
      {
       out_data[ik] = ONE_OVER_3 + ( blue - red ) / ( 6.0 * delta );
      }
     else			/* MAX == BLUE */
      {
       out_data[ik] = TWO_OVER_3 + ( red - green ) / ( 6.0 * delta );
      }
    }
  }

 return out_img;
}

/** 
 * @brief HSV (Hue-Saturation-Value) to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @note HSV color model is also called as HSB (Hue-Saturation-Brightness).
 * @ref 1) Smith A.R. (1978) "Color Gamut Transform Pairs" Computer Graphics, 12(3): 12-19
 *         ftp://ftp.alvyray.com/Acrobat/Color78.pdf
 *      2) Shih T-Y. (1995) "The Reversibility of Six Geometric Color Spaces" Photogrammetric 
 *         Engineering and Remote Sensing, 61(10): 1223-1232
 *      3) Foley J.D., van Dam A., Feiner S.K., and Hughes J.F. (1995) "Computer Graphics: 
 *         Principles and Practice" Addison-Wesley
 *      4) http://www.easyrgb.com/math.php?MATH=M21#text21
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
hsv_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "hsv_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double H, S, V;
 double fract, p, q, t;
 double red, green, blue;
 double *in_data;
 Image *out_img;
 int sextant;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   H = in_data[ik];
   S = in_data[ik + 1];
   V = in_data[ik + 2];

   if ( IS_ZERO ( S ) )		/* Achromatic case */
    {
     red = green = blue = V;
    }
   else
    {
     H *= 6.0;
     sextant = floor ( H );	/* Sector number of the hue */
     fract = H - sextant;	/* Hue value in each sector */
     p = V * ( 1.0 - S );
     q = V * ( 1.0 - S * fract );
     t = V * ( 1.0 - S * ( 1.0 - fract ) );

     switch ( sextant )
      {
       case 0:

	red = V;
	green = t;
	blue = p;
	break;

       case 1:

	red = q;
	green = V;
	blue = p;
	break;

       case 2:

	red = p;
	green = V;
	blue = t;
	break;

       case 3:

	red = p;
	green = q;
	blue = V;
	break;

       case 4:

	red = t;
	green = p;
	blue = V;
	break;

       case 5:

	red = V;
	green = p;
	blue = q;
	break;

       default:
	ERROR_RET ( "Invalid hue value !", NULL );
      }
    }

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation (except for the singular cases) 
    */

   out_data[ik] = red * MAX_GRAY + .5;
   out_data[ik + 1] = green * MAX_GRAY + .5;
   out_data[ik + 2] = blue * MAX_GRAY + .5;
  }

 return out_img;
}

/** 
 * @brief RGB to HSL (Hue-Saturation-Lightness) conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the HSL image or NULL
 *
 * @note 1) Hue, saturation, and value are in [0,1].
 *       3) Hue is undefined when R = G = B.
 * @ref 1) Levkowitz H. and Herman G.T. (1993) "GLHS: A Generalized Lightness, Hue, and Saturation 
 *         Color Model" CVGIP: Graphical Models and Image Processing, 55(4): 271-285
 *         http://www.cs.uml.edu/~haim/publications/glhs.ps
 *      2) Shih T-Y. (1995) "The Reversibility of Six Geometric Color Spaces" Photogrammetric 
 *         Engineering and Remote Sensing, 61(10): 1223-1232
 *      3) Weeks A.R. (1996) "Fundamentals of Electronic Image Processing" SPIE/IEEE Press
 *      4) Rogers D.F. (1998) "Procedural Elements for Computer Graphics" McGraw-Hill
 *      5) http://www.easyrgb.com/math.php?MATH=M18#text18
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_hsl ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_hsl" );
 byte *in_data;
 int red, green, blue;
 int min, max;
 int delta;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   max = MAX_3 ( red, green, blue );
   min = MIN_3 ( red, green, blue );
   delta = max - min;

   out_data[ik + 2] = NORM_C_2 * ( max + min );

   if ( delta == 0 )		/* Achromatic case */
    {
     out_data[ik] = undefined;
     out_data[ik + 1] = 0.0;
    }
   else
    {
     if ( out_data[ik + 2] < 0.5 )	/* 0 < L < 0.5 */
      {
       out_data[ik + 1] = delta / ( double ) ( max + min );
      }
     else			/* 0.5 <= L < 1.0 */
      {
       out_data[ik + 1] = delta / ( 511.0 - ( max + min ) );
      }

     if ( max == red )
      {
       out_data[ik] = ( green - blue ) / ( 6.0 * delta );

       /* Adjust the Hue value */
       if ( IS_NEG ( out_data[ik] ) )
	{
	 out_data[ik] += 1.0;
	}
      }
     else if ( max == green )
      {
       out_data[ik] = ONE_OVER_3 + ( blue - red ) / ( 6.0 * delta );
      }
     else			/* MAX == BLUE */
      {
       out_data[ik] = TWO_OVER_3 + ( red - green ) / ( 6.0 * delta );
      }
    }
  }

 return out_img;
}

/** 
 * @brief HSL (Hue-Saturation-Lightness) to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @ref 1) Levkowitz H. and Herman G.T. (1993) "GLHS: A Generalized Lightness, Hue, and Saturation 
 *         Color Model" CVGIP: Graphical Models and Image Processing, 55(4): 271-285
 *         http://www.cs.uml.edu/~haim/publications/glhs.ps
 *      2) Shih T-Y. (1995) "The Reversibility of Six Geometric Color Spaces" Photogrammetric 
 *         Engineering and Remote Sensing, 61(10): 1223-1232
 *      3) Weeks A.R. (1996) "Fundamentals of Electronic Image Processing" SPIE/IEEE Press
 *      4) Rogers D.F. (1998) "Procedural Elements for Computer Graphics" McGraw-Hill
 *      5) http://www.easyrgb.com/math.php?MATH=M19#text19
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
hsl_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "hsl_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 int sextant;
 double H, S, L;
 double v;
 double m;
 double sv;
 double fract, vsf, mid1, mid2;
 double red, green, blue;
 double *in_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   H = in_data[ik];
   S = in_data[ik + 1];
   L = in_data[ik + 2];

   if ( IS_ZERO ( S ) )		/* Achromatic case */
    {
     red = green = blue = L;
    }
   else
    {
     v = ( L <= 0.5 ) ? ( L * ( 1.0 + S ) ) : ( L + S - L * S );
     if ( v <= 0.0 )
      {
       red = green = blue = 0.0;
      }
     else
      {
       m = L + L - v;
       sv = ( v - m ) / v;
       H *= 6.0;
       sextant = floor ( H );	/* Sector number of the hue */
       fract = H - sextant;	/* Hue value in each sector */
       vsf = v * sv * fract;
       mid1 = m + vsf;
       mid2 = v - vsf;

       switch ( sextant )
	{
	 case 0:

	  red = v;
	  green = mid1;
	  blue = m;
	  break;

	 case 1:

	  red = mid2;
	  green = v;
	  blue = m;
	  break;

	 case 2:

	  red = m;
	  green = v;
	  blue = mid1;
	  break;

	 case 3:

	  red = m;
	  green = mid2;
	  blue = v;
	  break;

	 case 4:

	  red = mid1;
	  green = m;
	  blue = v;
	  break;

	 case 5:

	  red = v;
	  green = m;
	  blue = mid2;
	  break;

	 default:
	  ERROR_RET ( "Invalid hue value !", NULL );
	}
      }
    }

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation (except for the singular cases) 
    */

   out_data[ik] = red * MAX_GRAY + .5;
   out_data[ik + 1] = green * MAX_GRAY + .5;
   out_data[ik + 2] = blue * MAX_GRAY + .5;
  }

 return out_img;
}

#undef NORM_C_1
#undef NORM_C_2
#undef NORM_C_3

/** @cond INTERNAL_FUNCTION */

#define LUT_C ( 2.2222222222222222222222222222222 )	/* 1 / 0.45 */
static double *
calc_gamma_lut ( void )
{
 int ik;
 double *LUT;

 LUT = ( double * ) malloc ( NUM_GRAY * sizeof ( double ) );

 /* Rec. 709 Inverse Gamma Correction Function */

 /* ( ik / 255 ) < 0.081 => ik < 20.655 */
 for ( ik = 0; ik < 21; ik++ )
  {
   LUT[ik] = ( ik / ( double ) MAX_GRAY ) / 4.5;
  }

 /* ik > 20.655 */
 for ( ik = 21; ik < NUM_GRAY; ik++ )
  {
   LUT[ik] = pow ( ( ( ik / ( double ) MAX_GRAY ) + 0.099 ) / 1.099, LUT_C );
  }

 return LUT;
}

#undef LUT_C

/** @endcond INTERNAL_FUNCTION */

/* 
  CIE 2' D65 (Daylight) Illuminant
  Ref: Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
       Wiley-Interscience
 */
#define D65_Xn ( 0.950456 )
#define D65_Yn ( 1.0 )		/* This is true for every illuminant */
#define D65_Zn ( 1.089058 )

/** 
 * @brief RGB to CIE-LAB conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 *
 * @return Pointer to the LAB image or NULL
 *
 * @note 1) Inverse gamma correction is performed using a lookup table (LUT) 
 *          (inverse of the Rec. 709 transfer function).
 *       2) The RGB encoding is assumed to be Rec. 709 RGB.
 *       3) The white point is taken as CIE 2' D65 (Daylight) Illuminant.
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Poynton C. (2006) "Frequently Asked Questions about Color" 
 *         http://www.poynton.com/PDFs/ColorFAQ.pdf
 *      3) Ford A. and Roberts A. (1998) "Colour Space Conversions"
 *         http://www.poynton.com/PDFs/coloureq.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

#define RGB_LAB_C ( 0.13793103448275862068965517241379 )	/* = 16 / 116 */
Image *
rgb_to_lab ( const Image * in_img )
{
 SET_FUNC_NAME ( "rgb_to_lab" );
 byte *in_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 const double term_X = 1.0 / D65_Xn;
 const double term_Z = 1.0 / D65_Zn;
 double red, green, blue;
 double X, Y, Z;
 double *LUT;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 /* Rec. 709 Inverse Gamma Correction */
 LUT = calc_gamma_lut (  );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   /* Inverse Gamma Correction: Nonlinear RGB to linear RGB conversion */
   red = LUT[in_data[ik]];
   green = LUT[in_data[ik + 1]];
   blue = LUT[in_data[ik + 2]];

   /* Linear RGB to XYZ conversion */
   X = ( 0.412391 * red + 0.357584 * green + 0.180481 * blue ) * term_X;
   /* Coefficients of Y must sum to unity */
   Y = ( 0.212639 * red + 0.715169 * green + 0.072192 * blue );
   Z = ( 0.019331 * red + 0.119195 * green + 0.950532 * blue ) * term_Z;

   X = ( X > 0.008856 ) ? cbrt ( X ) : ( 7.787 * X ) + RGB_LAB_C;
   Y = ( Y > 0.008856 ) ? cbrt ( Y ) : ( 7.787 * Y ) + RGB_LAB_C;
   Z = ( Z > 0.008856 ) ? cbrt ( Z ) : ( 7.787 * Z ) + RGB_LAB_C;

   /* XYZ to CIE-LAB conversion */
   out_data[ik] = ( 116.0 * Y ) - 16.0;
   out_data[ik + 1] = 500.0 * ( X - Y );
   out_data[ik + 2] = 200.0 * ( Y - Z );
  }

 return out_img;
}

#undef RGB_LAB_C

/** 
 * @brief CIE-LAB to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @note 1) Gamma correction is performed using the Rec. 709 transfer function.
 *       2) The RGB encoding is assumed to be Rec. 709 RGB.
 *       3) The white point is taken as CIE 2' D65 (Daylight) Illuminant.
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Poynton C. (2006) "Frequently Asked Questions about Color" 
 *         http://www.poynton.com/PDFs/ColorFAQ.pdf
 *      3) Ford A. and Roberts A. (1998) "Colour Space Conversions"
 *         http://www.poynton.com/PDFs/coloureq.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

/** @cond INTERNAL_MACRO */
#define GAMMA_709( x )\
 ( ( ( x ) <= 0.018 ) ? ( ( x ) * 4.5 ) : ( 1.099 * pow ( ( x ), 0.45 ) - 0.099 ) )

/** @endcond INTERNAL_MACRO */

#define LAB_RGB_C1 ( 0.20689303442296382304584543185565 )	/* 0.008856^(1/3) */
#define LAB_RGB_C2 ( 0.13793103448275862068965517241379 )	/* 16 / 116 */
#define LAB_RGB_C3 ( 0.12841916013869269294978810838577 )	/* 1 / 7.787 */

Image *
lab_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "lab_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double red, green, blue;
 double L_star, a_star, b_star;
 double X, Y, Z;
 double *in_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   L_star = in_data[ik];
   a_star = in_data[ik + 1];
   b_star = in_data[ik + 2];

   /* CIE-LAB to XYZ conversion */
   Y = ( L_star + 16.0 ) / 116.0;
   X = ( a_star / 500.0 ) + Y;
   Z = Y - ( b_star / 200.0 );

   /* Reference Y (Yn) is always 1.0, so we can omit the multiplication */
   Y = ( ( Y > LAB_RGB_C1 ) ? Y * Y * Y : ( Y - LAB_RGB_C2 ) * LAB_RGB_C3 );
   X =
    D65_Xn * ( ( X > LAB_RGB_C1 ) ? X * X * X : ( X - LAB_RGB_C2 ) *
	       LAB_RGB_C3 );
   Z =
    D65_Zn * ( ( Z > LAB_RGB_C1 ) ? Z * Z * Z : ( Z - LAB_RGB_C2 ) *
	       LAB_RGB_C3 );

   /* XYZ to linear RGB conversion */
   red = 3.240966 * X - 1.537379 * Y - 0.498612 * Z;
   green = -0.969242 * X + 1.875965 * Y + 0.041556 * Z;
   blue = 0.055630 * X - 0.203977 * Y + 1.056972 * Z;

   /* Gamma Correction: Linear RGB to nonlinear RGB conversion */
   red = GAMMA_709 ( red );
   green = GAMMA_709 ( green );
   blue = GAMMA_709 ( blue );

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation (except for the singular cases) 
    */

   out_data[ik] = red * MAX_GRAY + .5;
   out_data[ik + 1] = green * MAX_GRAY + .5;
   out_data[ik + 2] = blue * MAX_GRAY + .5;
  }

 return out_img;
}

#undef LAB_RGB_C1
#undef LAB_RGB_C2
#undef LAB_RGB_C3

/** 
 * @brief RGB to CIE-LUV conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 *
 * @return Pointer to the LUV image or NULL
 *
 * @note 1) Inverse gamma correction is performed using a lookup table (LUT) 
 *          (inverse of the Rec. 709 transfer function).
 *       2) The RGB encoding is assumed to be Rec. 709 RGB.
 *       3) The white point is taken as CIE 2' D65 (Daylight) Illuminant.
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Poynton C. (2006) "Frequently Asked Questions about Color" 
 *         http://www.poynton.com/PDFs/ColorFAQ.pdf
 *      3) Ford A. and Roberts A. (1998) "Colour Space Conversions"
 *         http://www.poynton.com/PDFs/coloureq.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_luv ( const Image * in_img )
{
 SET_FUNC_NAME ( "rgb_to_luv" );
 byte *in_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;

 /* Premultiply REF_U and REF_V by 13.0 */
 const double ref_u =
  ( 52.0 * D65_Xn ) / ( D65_Xn + 15.0 * D65_Yn + 3.0 * D65_Zn );
 const double ref_v =
  ( 117.0 * D65_Yn ) / ( D65_Xn + 15.0 * D65_Yn + 3.0 * D65_Zn );
 double red, green, blue;
 double X, Y, Z;
 double denom;
 double *LUT;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 /* Rec. 709 Inverse Gamma Correction Function */
 LUT = calc_gamma_lut (  );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   /* Inverse Gamma Correction: Nonlinear RGB to linear RGB conversion */
   red = LUT[in_data[ik]];
   green = LUT[in_data[ik + 1]];
   blue = LUT[in_data[ik + 2]];

   /* Linear RGB to XYZ conversion */
   X = 0.412391 * red + 0.357584 * green + 0.180481 * blue;
   Y = 0.212639 * red + 0.715169 * green + 0.072192 * blue;
   Z = 0.019331 * red + 0.119195 * green + 0.950532 * blue;

   /* XYZ to CIE-LUV conversion */
   out_data[ik] = ( Y > 0.008856 ) ?
    ( 116.0 * cbrt ( Y ) ) - 16.0 : 903.292 * Y;

   denom = X + 15.0 * Y + 3.0 * Z;
   if ( IS_ZERO ( denom ) )	/* Singular case */
    {
     out_data[ik + 1] = 0.0;
     out_data[ik + 2] = 0.0;
    }
   else
    {
     out_data[ik + 1] = out_data[ik] * ( ( ( 52.0 * X ) / denom ) - ref_u );
     out_data[ik + 2] = out_data[ik] * ( ( ( 117.0 * Y ) / denom ) - ref_v );
    }
  }

 free ( LUT );

 return out_img;
}

/** 
 * @brief CIE-LUV to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @note 1) Gamma correction is performed using the Rec. 709 transfer function.
 *       2) The RGB encoding is assumed to be Rec. 709 RGB.
 *       3) The white point is taken as CIE 2' D65 (Daylight) Illuminant.
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Poynton C. (2006) "Frequently Asked Questions about Color" 
 *         http://www.poynton.com/PDFs/ColorFAQ.pdf
 *      3) Ford A. and Roberts A. (1998) "Colour Space Conversions"
 *         http://www.poynton.com/PDFs/coloureq.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

#define LUV_RGB_C ( 7.99959199306380347331807009518 )	/* 116 * 0.008856^(1/3) - 16 */
Image *
luv_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "luv_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 const double ref_u =
  ( 4.0 * D65_Xn ) / ( D65_Xn + 15.0 * D65_Yn + 3.0 * D65_Zn );
 const double ref_v =
  ( 9.0 * D65_Yn ) / ( D65_Xn + 15.0 * D65_Yn + 3.0 * D65_Zn );
 double red, green, blue;
 double L_star, u_star, v_star;
 double u_prime, v_prime;
 double X, Y, Z;
 double *in_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   L_star = in_data[ik];
   u_star = in_data[ik + 1];
   v_star = in_data[ik + 2];

   /* CIE-LUV to XYZ conversion */
   if ( L_star > LUV_RGB_C )
    {
     Y = ( L_star + 16.0 ) / 116.0;
     Y = Y * Y * Y;
    }
   else
    {
     Y = L_star / 903.292;
    }

   if ( IS_ZERO ( L_star ) )
    {
     u_prime = ref_u;
     v_prime = ref_v;
    }
   else
    {
     u_prime = ( u_star / ( 13.0 * L_star ) ) + ref_u;
     v_prime = ( v_star / ( 13.0 * L_star ) ) + ref_v;
    }

   X = 2.25 * Y * u_prime / v_prime;
   Z = ( -X / 3.0 ) - ( 5.0 * Y ) + ( 3.0 * Y / v_prime );

   /* XYZ to linear RGB conversion (with D65 white point) */
   red = 3.240966 * X - 1.537379 * Y - 0.498612 * Z;
   green = -0.969242 * X + 1.875965 * Y + 0.041556 * Z;
   blue = 0.055630 * X - 0.203977 * Y + 1.056972 * Z;

   /* Gamma Correction: Linear RGB to nonlinear RGB conversion */
   red = GAMMA_709 ( red );
   green = GAMMA_709 ( green );
   blue = GAMMA_709 ( blue );

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation (except for the singular cases) 
    */

   out_data[ik] = red * MAX_GRAY + .5;
   out_data[ik + 1] = green * MAX_GRAY + .5;
   out_data[ik + 2] = blue * MAX_GRAY + .5;
  }

 return out_img;
}

#undef LUV_RGB_C
#undef GAMMA_709

/** 
 * @brief RGB to SCT (Spherical Coordinate Transform) space conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the SCT image or NULL
 *
 * @note 1) The first component is in [0, 255*sqrt(3)] and the other two are in [0, pi/2].
 *       2) The second component is undefined when R = G = B = 0.
 *       3) The third component is undefined when R = G = 0.
 * @ref 1) Umbaugh S.E., Moss R.H., and Stoecker W.V. (1989) "Automatic Color Segmentation of 
 *         Images with Application to Detection of Variegated Coloring in Skin Tumors" IEEE 
 *         Engineering in Medicine and Biology Magazine, 8(4): 43-52
 *      2) Umbaugh S.E. (2005) "Computer Imaging: Digital Image Analysis and Processing" CRC Press
 *      3) Minten B.W., Murphy R.R., Hyams J., and Micire M. (2001) "Low-Order-Complexity 
 *         Vision-Based Docking" IEEE Trans. on Robotics and Automation, 17(6): 922-930
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_sct ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_sct" );
 byte *in_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 int red, green, blue;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   if ( ( red == 0 ) && ( green == 0 ) )	/* Singular case */
    {
     out_data[ik] = blue;	/* BLUE can be zero */
     out_data[ik + 1] = ( blue == 0 ) ? undefined : 0.0;
     out_data[ik + 2] = undefined;
    }
   else
    {
     out_data[ik] = sqrt ( red * red + green * green + blue * blue );
     out_data[ik + 1] = acos ( blue / out_data[ik] );
     out_data[ik + 2] = atan2 ( green, red );
    }
  }

 return out_img;
}

/** 
 * @brief SCT (Spherical Coordinate Transform) space to RGB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the RGB image or NULL
 *
 * @ref 1) Umbaugh S.E., Moss R.H., and Stoecker W.V. (1989) "Automatic Color Segmentation of 
 *         Images with Application to Detection of Variegated Coloring in Skin Tumors" IEEE 
 *         Engineering in Medicine and Biology Magazine, 8(4): 43-52
 *      2) Umbaugh S.E. (2005) "Computer Imaging: Digital Image Analysis and Processing" CRC Press
 *      3) Minten B.W., Murphy R.R., Hyams J., and Micire M. (2001) "Low-Order-Complexity 
 *         Vision-Based Docking" IEEE Trans. on Robotics and Automation, 17(6): 922-930
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
sct_to_rgb ( const Image * in_img )
{
 SET_FUNC_NAME ( "sct_to_rgb" );
 byte *out_data;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double length, angle_A, angle_B;
 double dist_to_blue_axis;
 double *in_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_RGB, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   length = in_data[ik];
   angle_A = in_data[ik + 1];
   angle_B = in_data[ik + 2];

   dist_to_blue_axis = length * sin ( angle_A );

   /* 
      Note that rounding, i.e. "+ .5", is necessary to obtain 
      perfect inverse transformation (except for the singular cases) 
    */

   out_data[ik] = dist_to_blue_axis * cos ( angle_B ) + 0.5;
   out_data[ik + 1] = dist_to_blue_axis * sin ( angle_B ) + 0.5;
   out_data[ik + 2] = length * cos ( angle_A ) + 0.5;
  }

 return out_img;
}

/** 
 * @brief CIE-LAB to CIE-LCH conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the LCH image or NULL
 *
 * @note 1) Hue is undefined when A and B are both 0.
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Poynton C. (2006) "Frequently Asked Questions about Color" 
 *         http://www.poynton.com/PDFs/ColorFAQ.pdf
 *      3) Ford A. and Roberts A. (1998) "Colour Space Conversions"
 *         http://www.poynton.com/PDFs/coloureq.pdf
 *      4) http://www.easyrgb.com/math.php?MATH=M9#text9
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
lab_to_lch ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "lab_to_lch" );
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double a_star, b_star;
 double H_star;
 double *in_data;
 double *out_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   a_star = in_data[ik + 1];
   b_star = in_data[ik + 2];

   if ( IS_ZERO ( a_star ) && IS_ZERO ( b_star ) )
    {
     /* Singular case */
     H_star = undefined;
    }
   else
    {
     H_star = atan2 ( b_star, a_star );
     /* atan2 returns a value in radians, in the range of -pi to pi */
     if ( IS_NEG ( H_star ) )
      {
       H_star += TWO_PI;
      }
    }

   out_data[ik] = in_data[ik];	/* L_STAR remains the same */
   out_data[ik + 1] = sqrt ( a_star * a_star + b_star * b_star );	/* C_STAR */
   out_data[ik + 2] = H_star;
  }

 return out_img;
}

/** 
 * @brief CIE-LCH to CIE-LAB conversion
 * 
 * @param[in] in_img Image pointer { dbl_3b }
 *
 * @return Pointer to the LAB image or NULL
 *
 * @ref 1) Pratt W.K. (2007) "Digital Image Processing: PIKS Scientific Inside" 
 *         Wiley-Interscience
 *      2) Poynton C. (2006) "Frequently Asked Questions about Color" 
 *         http://www.poynton.com/PDFs/ColorFAQ.pdf
 *      3) Ford A. and Roberts A. (1998) "Colour Space Conversions"
 *         http://www.poynton.com/PDFs/coloureq.pdf
 *      4) http://www.easyrgb.com/math.php?MATH=M10#text10
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
lch_to_lab ( const Image * in_img )
{
 SET_FUNC_NAME ( "lch_to_lab" );
 int ik;
 int num_rows, num_cols;
 int num_elems;
 double *in_data;
 double *out_data;
 Image *out_img;

 if ( !is_dbl_3b_img ( in_img ) )
  {
   ERROR_RET ( "Not a 3-band double image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   out_data[ik] = in_data[ik];
   out_data[ik + 1] = cos ( in_data[ik + 2] ) * in_data[ik + 1];
   out_data[ik + 2] = sin ( in_data[ik + 2] ) * in_data[ik + 1];
  }

 return out_img;
}

/** 
 * @brief RGB to l1l2l3 conversion
 * 
 * @param[in] in_img Image pointer { rgb }
 * @param[in] undefined The value that represents an undefined output
 *
 * @return Pointer to the l1l2l3 image or NULL
 *
 * @note The output values are undefined when R = G = B.
 * @ref 1) Gevers T. and Smeulders A.W.M. (1999) "Color Based Object Recognition" 
 *         Pattern Recognition, 32(3): 453-463
 *         http://staff.science.uva.nl/~gevers/pub/GeversPR99.pdf
 *
 * @author M. Emre Celebi
 * @date 07.22.2007
 */

Image *
rgb_to_l1l2l3 ( const Image * in_img, double undefined )
{
 SET_FUNC_NAME ( "rgb_to_l1l2l3" );
 byte *in_data;
 int red, green, blue;
 int ik;
 int num_rows, num_cols;
 int num_elems;
 int term1, term2, term3;
 int sum_term;
 double norm_term;
 double *out_data;
 Image *out_img;

 if ( !is_rgb_img ( in_img ) )
  {
   ERROR_RET ( "Not a color image !", NULL );
  }

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 num_elems = 3 * num_rows * num_cols;

 in_data = get_img_data_1d ( in_img );

 /* Allocate output image */
 out_img = alloc_img ( PIX_DBL_3B, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_1d ( out_img );

 for ( ik = 0; ik < num_elems; ik += 3 )
  {
   red = in_data[ik];
   green = in_data[ik + 1];
   blue = in_data[ik + 2];

   term1 = ( red - green ) * ( red - green );
   term2 = ( red - blue ) * ( red - blue );
   term3 = ( green - blue ) * ( green - blue );
   sum_term = term1 + term2 + term3;

   if ( sum_term == 0 )		/* RED == GREEN == BLUE */
    {
     out_data[ik] = undefined;
     out_data[ik + 1] = undefined;
     out_data[ik + 2] = undefined;
    }
   else
    {
     norm_term = 1.0 / ( double ) sum_term;

     out_data[ik] = norm_term * term1;
     out_data[ik + 1] = norm_term * term2;
     out_data[ik + 2] = norm_term * term3;
    }
  }

 return out_img;
}

#undef ONE_OVER_3
#undef TWO_OVER_3
#undef FOUR_OVER_3
#undef TWO_PI_OVER_3
#undef FOUR_PI_OVER_3
