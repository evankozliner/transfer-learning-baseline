
/** 
 * @file threshold_savakis_opt.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Savakis's thresholding method
 *
 * @param[in] in_img Image pointer { grayscale }
 * @param[in] win_size Dimension of the thresholding window { positive-odd }
 * @param[in] global_thresholding_method Global thresholding method to be used
 *            
 * @return Pointer to the resulting binary image or NULL
 *
 * @ref 1) Savakis A.E. (1998) "Adaptive Document Image Thresholding Using Foreground 
 *         and Background Clustering" Proc. of the IEEE Int. Conf. on Image Processing,
 *         3: 785-789
 *         http://www.ce.rit.edu/~savakis/papers/ICIP98_savakis.pdf
 *      2) Duc D.A., Du T.L.H., and Duan T.D. (2004) "Optimizing Speed for Adaptive Local 
 *         Thresholding Algorithm Using Dynamic Programming" 2004 Int. Conf. on Electronics, 
 *         Information, and Communications (ICEIC�04), 1: 438-441
 *         http://www.fit.hcmuns.edu.vn/~daduc/files/iceic04.pdf
 *
 * @author M. Emre Celebi
 * @date 07.26.2007
 */

Image *
threshold_savakis_opt ( const Image * in_img, const int win_size,
			int ( *global_thresholding_method ) ( const Image * ) )
{
 SET_FUNC_NAME ( "threshold_savakis_opt" );
 byte **in_data;
 byte **out_data;
 int num_rows, num_cols;
 int half_win;
 int win_count;			/* number of pixels in the filtering window */
 int ir, ic;
 int r_begin, r_end;		/* vertical limits of the filtering operation */
 int c_begin, c_end;		/* horizontal limits of the filtering operation */
 int gray_val;
 int num_back;			/* number of background pixels in a particular window */
 int num_obj;			/* number of object pixels in a particular window */
 int sum_back;			/* sum of background pixels in a particular window */
 int sum_obj;			/* sum of object pixels in a particular window */
 int global_threshold;
 int local_threshold;
 int top, bottom, right, left;
 int **set_back;
 int **set_obj;
 int **card_back;
 int **card_obj;
 double mean_back;		/* mean of the background pixels in a particular window */
 double mean_obj;		/* mean of the object pixels in a particular window */
 Image *out_img;

 if ( !is_gray_img ( in_img ) )
  {
   ERROR_RET ( "Not a grayscale image !", NULL );
  }

 if ( !IS_POS_ODD ( win_size ) )
  {
   ERROR ( "Window size ( %d ) must be positive and odd !", win_size );
   return NULL;
  }

 half_win = win_size / 2;
 win_count = win_size * win_size;

 num_rows = get_num_rows ( in_img );
 num_cols = get_num_cols ( in_img );
 in_data = get_img_data_nd ( in_img );

 out_img = alloc_img ( PIX_BIN, num_rows, num_cols );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* Calculate the global threshold */
 global_threshold = global_thresholding_method ( in_img );

 set_back = alloc_nd ( sizeof ( int ), 2, num_rows, num_cols );
 card_back = alloc_nd ( sizeof ( int ), 2, num_rows, num_cols );
 set_obj = alloc_nd ( sizeof ( int ), 2, num_rows, num_cols );
 card_obj = alloc_nd ( sizeof ( int ), 2, num_rows, num_cols );

 if ( IS_NULL ( set_obj ) || IS_NULL ( card_obj ) || IS_NULL ( set_back ) ||
      IS_NULL ( card_back ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 for ( ir = 1; ir < num_rows; ir++ )
  {
   for ( ic = 1; ic < num_cols; ic++ )
    {
     gray_val = in_data[ir][ic];

     if ( gray_val <= global_threshold )
      {
       set_back[ir][ic] = set_back[ir][ic - 1] + set_back[ir - 1][ic]
	- set_back[ir - 1][ic - 1] + in_data[ir][ic];
       card_back[ir][ic] = card_back[ir][ic - 1] + card_back[ir - 1][ic]
	- card_back[ir - 1][ic - 1] + 1;
       set_obj[ir][ic] = set_obj[ir][ic - 1] + set_obj[ir - 1][ic]
	- set_obj[ir - 1][ic - 1];
       card_obj[ir][ic] = card_obj[ir][ic - 1] + card_obj[ir - 1][ic]
	- card_obj[ir - 1][ic - 1];
      }
     else
      {
       set_back[ir][ic] = set_back[ir][ic - 1] + set_back[ir - 1][ic]
	- set_back[ir - 1][ic - 1];
       card_back[ir][ic] = card_back[ir][ic - 1] + card_back[ir - 1][ic]
	- card_back[ir - 1][ic - 1];
       set_obj[ir][ic] = set_obj[ir][ic - 1] + set_obj[ir - 1][ic]
	- set_obj[ir - 1][ic - 1] + in_data[ir][ic];
       card_obj[ir][ic] = card_obj[ir][ic - 1] + card_obj[ir - 1][ic]
	- card_obj[ir - 1][ic - 1] + 1;
      }
    }
  }

 /* 
    Determine the limits of the filtering operation. Pixels
    in the output image outside these limits are set to 0.
  */
 r_begin = half_win + 1;
 r_end = num_rows - half_win;
 c_begin = half_win + 1;
 c_end = num_cols - half_win;

 for ( ir = r_begin; ir < r_end; ir++ )
  {
   for ( ic = c_begin; ic < c_end; ic++ )
    {
     left = ic - half_win;
     top = ir - half_win;
     right = ic + half_win;
     bottom = ir + half_win;

     sum_back = set_back[bottom][right] - set_back[bottom][left - 1]
      - set_back[top - 1][right] + set_back[top - 1][left - 1];
     num_back = card_back[bottom][right] - card_back[bottom][left - 1]
      - card_back[top - 1][right] + card_back[top - 1][left - 1];
     sum_obj = set_obj[bottom][right] - set_obj[bottom][left - 1]
      - set_obj[top - 1][right] + set_obj[top - 1][left - 1];
     num_obj = card_obj[bottom][right] - card_obj[bottom][left - 1]
      - card_obj[top - 1][right] + card_obj[top - 1][left - 1];

     /* Calculate cluster means */
     mean_back = ( num_back == 0 ? 0.0 : ( sum_back / ( double ) num_back ) );
     mean_obj = ( num_obj == 0 ? 0.0 : ( sum_obj / ( double ) num_obj ) );

     /* Calculate the local threshold */
     local_threshold = 0.5 * ( mean_back + mean_obj );

     /* Determine the output pixel value */
     out_data[ir][ic] =
      ( ( in_data[ir][ic] > local_threshold ) ? OBJECT : BACKGROUND );
    }
  }

 free_nd ( set_back, 2 );
 free_nd ( card_back, 2 );
 free_nd ( set_obj, 2 );
 free_nd ( card_obj, 2 );

 return out_img;
}
