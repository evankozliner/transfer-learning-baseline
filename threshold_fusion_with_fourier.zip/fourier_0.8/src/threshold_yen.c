
/** 
 * @file threshold_yen.c
 * Routines for thresholding (binarizing) a grayscale image
 */

#include <image.h>

/** 
 * @brief Implements Yen's thresholding method
 *
 * @param[in] img Image pointer { grayscale }
 *
 * @return Threshold value or INT_MIN 
 *
 * @ref 1) Yen J.C., Chang F.J., and Chang S. (1995) "A New Criterion 
 *      for Automatic Multilevel Thresholding" IEEE Trans. on Image 
 *      Processing, 4(3): 370-378
 *      2) Sezgin M. and Sankur B. (2004) "Survey over Image Thresholding 
 *      Techniques and Quantitative Performance Evaluation" Journal of 
 *      Electronic Imaging, 13(1): 146-165
 *      http://citeseer.ist.psu.edu/sezgin04survey.html
 *
 * @author M. Emre Celebi
 * @date 06.23.2007
 */

int
threshold_yen ( const Image * img )
{
 SET_FUNC_NAME ( "threshold_yen" );
 int ih, it;
 int threshold;
 double crit;
 double max_crit;
 double *data;			/* normalized histogram data */
 double *P1;			/* cumulative normalized histogram */
 double *P1_sq;			/* cumulative normalized histogram */
 double *P2_sq;			/* see below */
 Histo *norm_histo;		/* normalized histogram */

 if ( !is_gray_img ( img ) )
  {
   ERROR_RET ( "Not a grayscale image !", INT_MIN );
  }

 /* Calculate the normalized histogram */
 norm_histo = normalize_histo ( create_histo ( img ) );
 if ( IS_NULL ( norm_histo ) )
  {
   ERROR_RET ( "normalize_histo() failed !", INT_MIN );
  }

 data = get_histo_data ( norm_histo );

 /* Calculate the cumulative normalized histogram */
 P1 = accumulate_histo ( norm_histo );

 P1_sq = ( double * ) malloc ( NUM_GRAY * sizeof ( double ) );

 P1_sq[0] = data[0] * data[0];
 for ( ih = 0 + 1; ih < NUM_GRAY; ih++ )
  {
   P1_sq[ih] = P1_sq[ih - 1] + data[ih] * data[ih];
  }

 P2_sq = ( double * ) malloc ( NUM_GRAY * sizeof ( double ) );

 P2_sq[MAX_GRAY] = 0.0;
 for ( ih = MAX_GRAY - 1; ih >= 0; ih-- )
  {
   P2_sq[ih] = P2_sq[ih + 1] + data[ih + 1] * data[ih + 1];
  }

 /* Find the threshold that maximizes the criterion */
 threshold = INT_MIN;
 max_crit = DBL_MIN;
 for ( it = 0; it < NUM_GRAY; it++ )
  {
   crit =
    -1.0 * SAFE_LOG ( P1_sq[it] * P2_sq[it] ) +
    2 * SAFE_LOG ( P1[it] * ( 1.0 - P1[it] ) );
   if ( crit > max_crit )
    {
     max_crit = crit;
     threshold = it;
    }
  }

 free_histo ( norm_histo );
 free ( P1 );
 free ( P1_sq );
 free ( P2_sq );

 return threshold;
}
