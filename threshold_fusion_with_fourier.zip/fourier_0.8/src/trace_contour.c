
/** 
 * @file trace_contour.c
 * Routines for tracing the object contours in a binary image
 */

#include <image.h>

/** 
 * @brief Allocates a chain object
 *
 * @param[in] max_length Maximum # points on the chain { positive }
 *
 * @return Pointer to the allocated chain or NULL
 * 
 * @see #free_chain
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

Chain *
alloc_chain ( const int max_length )
{
 SET_FUNC_NAME ( "alloc_chain" );
 Chain *chain = NULL;

 if ( max_length <= 0 )
  {
   ERROR ( "Max length ( %d ) must be > 0 !", max_length );
   return NULL;
  }

 chain = MALLOC_STRUCT ( Chain );
 chain->length = INT_MIN;	/* Illegal value */

 /* Allocate storage for chain data */
 chain->dir = ( int * ) malloc ( max_length * sizeof ( int ) );
 chain->row = ( int * ) malloc ( max_length * sizeof ( int ) );
 chain->col = ( int * ) malloc ( max_length * sizeof ( int ) );

 if ( IS_NULL ( chain->dir ) || IS_NULL ( chain->row ) ||
      IS_NULL ( chain->col ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* The chain remains invalid until the contour is traced */
 chain->type = GEN_INVALID;

 return chain;
}

/** 
 * @brief Deallocates a chain object
 *
 * @param[in,out] chain Chain pointer
 *
 * @return none
 * 
 * @note nothing happens if the chain object is invalid
 * @see #alloc_chain
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

void
free_chain ( Chain * chain )
{
 if ( IS_VALID_OBJ ( chain ) )
  {
   free ( chain->dir );
   chain->dir = NULL;
   free ( chain->row );
   chain->row = NULL;
   free ( chain->col );
   chain->col = NULL;

   chain->length = INT_MIN;
   chain->type = GEN_INVALID;
  }
}

/** 
 * @brief Returns the length ( # points ) of a chain
 *
 * @param[in] chain Chain pointer
 *
 * @return Length value or INT_MIN
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

int
get_chain_len ( const Chain * chain )
{
 SET_FUNC_NAME ( "get_chain_len" );

 if ( !IS_VALID_OBJ ( chain ) )
  {
   ERROR_RET ( "Invalid chain object !", INT_MIN );
  }

 return chain->length;
}

/** 
 * @brief Returns the row pointer of a chain
 *
 * @param[in] chain Chain pointer
 *
 * @return Row pointer or NULL
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

int *
get_chain_rows ( const Chain * chain )
{
 SET_FUNC_NAME ( "get_chain_rows" );

 if ( !IS_VALID_OBJ ( chain ) )
  {
   ERROR_RET ( "Invalid chain object !", NULL );
  }

 return chain->row;
}

/** 
 * @brief Returns the column pointer of a chain
 *
 * @param[in] chain Chain pointer
 *
 * @return Column pointer or NULL
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

int *
get_chain_cols ( const Chain * chain )
{
 SET_FUNC_NAME ( "get_chain_cols" );

 if ( !IS_VALID_OBJ ( chain ) )
  {
   ERROR_RET ( "Invalid chain object !", NULL );
  }

 return chain->col;
}

/** 
 * @brief Returns the direction pointer of a chain
 *
 * @param[in] chain Chain pointer
 *
 * @return Direction pointer or NULL
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

int *
get_chain_dir ( const Chain * chain )
{
 SET_FUNC_NAME ( "get_chain_dir" );

 if ( !IS_VALID_OBJ ( chain ) )
  {
   ERROR_RET ( "Invalid chain object !", NULL );
  }

 return chain->dir;
}

/** 
 * @brief Allocates a chain list object
 *
 * @param[in] num_chains # chains in the list { positive }
 * @param[in] max_length Maximum # points on a chain { positive }
 * @param[in] num_rows # rows in the source image { positive }
 * @param[in] num_cols # columns in the source image { positive }
 *
 * @return Pointer to the allocated chain list or NULL
 * 
 * @see #free_chain_list
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

ChainList *
alloc_chain_list ( const int num_chains, const int max_length,
		   const int num_rows, const int num_cols )
{
 SET_FUNC_NAME ( "alloc_chain_list" );
 int ik;
 ChainList *chain_list = NULL;

 if ( num_chains <= 0 )
  {
   ERROR ( "Number of chains ( %d ) must be positive !", num_chains );
   return NULL;
  }

 if ( max_length <= 0 )
  {
   ERROR ( "Max length ( %d ) must be positive !", max_length );
   return NULL;
  }

 if ( num_rows <= 0 )
  {
   ERROR ( "Number of rows ( %d ) must be positive !", num_rows );
   return NULL;
  }

 if ( num_cols <= 0 )
  {
   ERROR ( "Number of cols ( %d ) must be positive !", num_cols );
   return NULL;
  }

 chain_list = MALLOC_STRUCT ( ChainList );
 chain_list->num_chains = num_chains;
 chain_list->max_length = max_length;
 chain_list->num_rows = num_rows;
 chain_list->num_cols = num_cols;
 /* The chain list remains invalid until the contours are traced */
 chain_list->type = GEN_INVALID;

 /* Allocate storage for chain data */
 chain_list->chain = ( Chain ** ) malloc ( num_chains * sizeof ( Chain * ) );
 if ( IS_NULL ( chain_list->chain ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 for ( ik = 0; ik < num_chains; ik++ )
  {
   chain_list->chain[ik] = alloc_chain ( max_length );
   if ( IS_NULL ( chain_list->chain[ik] ) )
    {
     ERROR_RET ( "Insufficient memory !", NULL );
    }
  }

 return chain_list;
}

/** 
 * @brief Deallocates a chain list object
 *
 * @param[in,out] chain_list Chain list pointer
 *
 * @return none
 * 
 * @note nothing happens if the chain list object is invalid
 * @see #alloc_chain_list
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

void
free_chain_list ( ChainList * chain_list )
{
 if ( IS_VALID_OBJ ( chain_list ) )
  {
   int ik;

   for ( ik = chain_list->num_chains - 1; ik >= 0; ik-- )
    {
     free_chain ( chain_list->chain[ik] );
     chain_list->chain[ik] = NULL;
    }

   chain_list->num_chains = INT_MIN;
   chain_list->max_length = INT_MIN;
   chain_list->num_rows = INT_MIN;
   chain_list->num_cols = INT_MIN;
   chain_list->type = GEN_INVALID;
  }
}

/** 
 * @brief Returns a particular chain from a list of chains
 *
 * @param[in] chain_list Chain list pointer
 * @param[in] index Index of the chain in the list
 *
 * @return Chain pointer or NULL
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

Chain *
get_chain ( const ChainList * chain_list, const int index )
{
 SET_FUNC_NAME ( "get_chain" );

 if ( !IS_VALID_OBJ ( chain_list ) )
  {
   ERROR_RET ( "Invalid chain list object !", NULL );
  }

 if ( chain_list->num_chains <= index )
  {
   ERROR ( "Chain index ( %d ) must be less than the number of chains\
 in the list ( %d ) !", index, chain_list->num_chains );
   return NULL;
  }

 return chain_list->chain[index];
}

/** 
 * @brief Returns the # chains in a chain list
 *
 * @param[in] chain_list Chain list pointer
 *
 * @return # chains or NULL
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

int
get_num_chains ( const ChainList * chain_list )
{
 SET_FUNC_NAME ( "get_num_chains" );

 if ( !IS_VALID_OBJ ( chain_list ) )
  {
   ERROR_RET ( "Invalid chain list object !", INT_MIN );
  }

 return chain_list->num_chains;
}

/** 
 * @brief Convert a chain list to a binary image
 *
 * @param[in] chain_list Chain list pointer
 *
 * @return Pointer to the binary image or NULL
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

Image *
chain_list_to_img ( const ChainList * chain_list )
{
 SET_FUNC_NAME ( "chain_list_to_img" );
 byte **out_data;
 int ic, ik;
 int num_chains;
 int length;
 int *chain_row;
 int *chain_col;
 Chain *chain;
 Image *out_img;

 if ( !IS_VALID_OBJ ( chain_list ) )
  {
   ERROR_RET ( "Invalid chain list object !", NULL );
  }

 num_chains = get_num_chains ( chain_list );

 out_img = alloc_img ( PIX_BIN, GET_NUM_ROWS ( chain_list ),
		       GET_NUM_COLS ( chain_list ) );
 if ( IS_NULL ( out_img ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 out_data = get_img_data_nd ( out_img );

 /* Write the elements of each chain to the output image */
 for ( ic = 0; ic < num_chains; ic++ )
  {
   chain = get_chain ( chain_list, ic );
   chain_row = get_chain_rows ( chain );
   chain_col = get_chain_cols ( chain );
   length = get_chain_len ( chain );

   for ( ik = 0; ik < length; ik++ )
    {
     out_data[chain_row[ik]][chain_col[ik]] = OBJECT;
    }
  }

 return out_img;
}

/** 
 * @brief Traces the 8-connected contour of an object in a label image 
 *
 * @param[in] lab_img Image pointer { label }
 * @param[in] label Label of the object { positive }
 * @param[in] max_length Maximum # points on the contour { positive }
 *
 * @return Pointer to the chain or NULL
 *
 * @ref 1) Freeman H. (1961) "On the Encoding of Arbitrary Geometric Configurations" 
 *         IRE Transactions on Electronic Computers, 10: 260-268
 *      2) Freeman H. (1974) "Computer Processing of Line-Drawing Images" 
 *         ACM Computing Surveys, 6(1): 57-97
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

Chain *
trace_contour ( const Image * lab_img, const int label, const int max_length )
{
 SET_FUNC_NAME ( "trace_contour" );
 static int row_offset[] = { 0, -1, -1, -1, 0, 1, 1, 1 };
 static int col_offset[] = { 1, 1, 0, -1, -1, -1, 0, 1 };
 static int dir_lut[] = { 5, 6, 7, 0, 1, 2, 3, 4 };
 int num_rows, num_cols;
 int ir, ic;
 int ik;
 int start_row, start_col;
 int cur_row, cur_col;
 int prev_dir, new_dir;
 int count;
 int *chain_dir;
 int *chain_row;
 int *chain_col;
 int **in_data;
 Bool pix_found;
 Chain *chain;

 if ( !is_label_img ( lab_img ) )
  {
   ERROR_RET ( "Not a label image !", NULL );
  }

 if ( label <= 0 )
  {
   ERROR ( "Label ( %d ) must be positive !", label );
   return NULL;
  }

 if ( max_length <= 0 )
  {
   ERROR ( "Max length ( %d ) must be positive !", max_length );
   return NULL;
  }

 num_rows = get_num_rows ( lab_img );
 num_cols = get_num_cols ( lab_img );
 in_data = get_img_data_nd ( lab_img );

 /* 
    Find the starting pixel by searching for the first 
    object pixel from left to right, top to bottom
  */
 pix_found = false;
 for ( ir = 0; ir < num_rows; ir++ )
  {
   for ( ic = 0; ic < num_cols; ic++ )
    {
     if ( in_data[ir][ic] == label )
      {
       start_row = ir;
       start_col = ic;
       pix_found = true;
       break;
      }
    }

   if ( pix_found )
    {
     break;
    }
  }

 if ( !pix_found )
  {
   ERROR ( "No object pixel with label ( %d ) found !", label );
   return NULL;
  }

 chain = alloc_chain ( max_length );
 if ( IS_NULL ( chain ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 chain->type = GEN_VALID;

 chain_dir = get_chain_dir ( chain );
 chain_row = get_chain_rows ( chain );
 chain_col = get_chain_cols ( chain );

 /* Save the starting point */
 chain_dir[0] = ( prev_dir = 4 );
 chain_row[0] = ( cur_row = start_row );
 chain_col[0] = ( cur_col = start_col );

 /* # points on the contour */
 count = 1;

 do
  {
   if ( max_length <= count )
    {
     WARNING ( "Max contour length ( %d ) reached.\
 Terminating the trace.", max_length );
     break;
    }

   pix_found = false;

   /* Check for the next pixel in the contour */
   for ( ik = prev_dir + 1; ik < prev_dir + 8; ik++ )
    {
     new_dir = ik % 8;
     cur_row += row_offset[new_dir];
     cur_col += col_offset[new_dir];

     /* 
        Make sure that the new coordinates are legal 
        and then check whether this is an object pixel 
      */
     if ( 0 <= cur_row && cur_row < num_rows &&
	  0 <= cur_col && cur_col < num_cols &&
	  in_data[cur_row][cur_col] == label )
      {
       /* Save the next pixel */
       chain_dir[count] = new_dir;
       chain_row[count] = cur_row;
       chain_col[count] = cur_col;
       count++;
       prev_dir = dir_lut[new_dir];
       /* Found the next pixel - terminate the search */
       pix_found = true;
       break;
      }
     else
      {
       /* Restore the last known legal coordinates */
       cur_row -= row_offset[new_dir];
       cur_col -= col_offset[new_dir];
      }
    }

   /* No more contour pixels - terminate tracing */
   if ( !pix_found )
    {
     break;
    }
  }
 while ( ( cur_row != start_row ) || ( cur_col != start_col ) );	/* Stop when the starting pixel is reached */

 chain->length = count;

 return chain;
}

/** 
 * @brief Traces the 8-connected contours of the objects in a label image 
 *
 * @param[in] lab_img Image pointer { label }
 * @param[in] max_length Maximum # points on a contour { positive }
 *
 * @return Pointer to the chain list or NULL
 *
 * @ref 1) Freeman H. (1961) "On the Encoding of Arbitrary Geometric Configurations" 
 *         IRE Transactions on Electronic Computers, 10: 260-268
 *      2) Freeman H. (1974) "Computer Processing of Line-Drawing Images" 
 *         ACM Computing Surveys, 6(1): 57-97
 *
 * @author M. Emre Celebi
 * @date 07.25.2007
 */

ChainList *
trace_contours ( const Image * lab_img, const int max_length )
{
 SET_FUNC_NAME ( "trace_contours" );
 int ik;
 int num_cc;
 ChainList *chain_list;

 if ( !is_label_img ( lab_img ) )
  {
   ERROR_RET ( "Not a label image !", NULL );
  }

 if ( max_length <= 0 )
  {
   ERROR ( "Max length ( %d ) must be positive !", max_length );
   return NULL;
  }

 num_cc = get_num_cc ( lab_img );

 chain_list = alloc_chain_list ( get_num_cc ( lab_img ), max_length,
				 get_num_rows ( lab_img ),
				 get_num_cols ( lab_img ) );
 if ( IS_NULL ( chain_list ) )
  {
   ERROR_RET ( "Insufficient memory !", NULL );
  }

 /* Trace the contour of each component */
 for ( ik = 0; ik < num_cc; ik++ )
  {
   /* 
      Note that the connected component labels range from 1 to 
      NUM_CC. So, we are not tracing the object with the label 0.
    */
   chain_list->chain[ik] = trace_contour ( lab_img, ik + 1, max_length );
  }

 chain_list->type = GEN_VALID;

 return chain_list;
}
